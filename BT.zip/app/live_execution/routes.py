from app.live_execution import run_live_execution
from app.parser.utils import parse_strategy_json
from flask import Blueprint, request
from app.commons.enums import *
import logging

logger = logging.getLogger(__name__)
live_execution_bp = Blueprint('live_execution', __name__, url_prefix='/live_execution')


@live_execution_bp.route('/start', methods=['POST'])
def start():
    """
    Start backtest for given strategy
    :param strategy: Strategy object
    :return: None
    """
    try:
        strategy_json = request.json.get("strategy")
        start_date = request.json.get("start_date")
        end_date = request.json.get("end_date")
        index_base_price = int(request.json.get("index_base_price"))
        fix_vix = int(request.json.get("fix_vix"))
        broker_details = request.json.get("broker_details")
        exchange = eval(request.json.get("exchange"))
        product_type = eval(request.json.get("product_type"))
        order_type = eval(request.json.get("order_type"))
        feed_source = eval(request.json.get("feed_source"))
        strategy = parse_strategy_json(strategy_json)
        run_live_execution(
            strategy,
            start_date,
            end_date,
            index_base_price,
            fix_vix,
            broker_details,
            exchange,
            product_type,
            order_type,
            feed_source
        )
        return "success", 200
    except KeyError as e:
        return str(e), 400
    except Exception as e:
        logger.exception(e)
        return str(e), 500
