from app.commons.modules import (
    Dict,
    List,
    logging,
    requests,
    socketio,
    os,
    json,
    sys,
    datetime
)
from app.commons.models import Contract
from app.commons.enums import NSEINDEX, OPTIONTYPE, EXCHANGE, ENUMELEMENT, ORDERTYPE, PRODUCTTYPE, SIDE, ORDERSTATUS
from app.commons.utils import int_date, int_time, rupee_to_paise
from app.api_providers.utils import from_exchange_timestamp
from app.commons.models import OHLC
from app.commons.models import Order
from app.config import Config

logger = logging.getLogger(__name__)

contracts: Dict[str, Dict[str, Dict[int, Dict[int, int]]]] = {
    NSEINDEX.NIFTY.name: {OPTIONTYPE.CALL.name: {}, OPTIONTYPE.PUT.name: {}, OPTIONTYPE.FUT.name: {}},
    NSEINDEX.BANKNIFTY.name: {OPTIONTYPE.CALL.name: {}, OPTIONTYPE.PUT.name: {}, OPTIONTYPE.FUT.name: {}},
    NSEINDEX.FINNIFTY.name: {OPTIONTYPE.CALL.name: {}, OPTIONTYPE.PUT.name: {}, OPTIONTYPE.FUT.name: {}},
}

contracts_by_token: Dict[int, Contract] = {}
live_dict: Dict[int, OHLC] = {}
indexes: Dict[str, int] = {}
WEEKLY_EXPIRY = "WEEKLY_EXPIRY"
NEXT_WEEKLY_EXPIRY = "NEXT_WEEKLY_EXPIRY"
MONTHLY_EXPIRY = "MONTHLY_EXPIRY"
expiries: Dict[ENUMELEMENT, Dict[str, int]] = {
    NSEINDEX.NIFTY: {WEEKLY_EXPIRY: 999999, NEXT_WEEKLY_EXPIRY: 999999, MONTHLY_EXPIRY: 999999},
    NSEINDEX.BANKNIFTY: {WEEKLY_EXPIRY: 999999, NEXT_WEEKLY_EXPIRY: 999999, MONTHLY_EXPIRY: 999999},
    NSEINDEX.FINNIFTY: {WEEKLY_EXPIRY: 999999, NEXT_WEEKLY_EXPIRY: 999999, MONTHLY_EXPIRY: 999999},
}
    


def download_contract_data():
    master_file_url = "https://ttblaze.iifl.com/apimarketdata/instruments/master"
    headers = {"Content-Type": "application/json"}
    payload = {"exchangeSegmentList": ["NSEFO"]}
    response = requests.post(master_file_url, headers=headers, json=payload)
    master_filepath = os.path.join(Config.TMP_DIR, "master.json")

    if response.status_code == 200:
        master_data: str = response.json()["result"]
        with open(master_filepath, "wt") as f:
            json.dump(master_data, f)
    else:
        key = input(
            "Error while downloading master file. Press Y to load from local file, any other key to exit"
        )
        if key.upper() == "Y":
            with open(master_filepath, "rt") as f:
                master_data: str = json.load(f)
        else:
            sys.exit(1)
    master_data: List[str] = [x.strip().split("|") for x in master_data.strip().split("\n")]
    return master_data

def get_token(index: ENUMELEMENT, option_type: ENUMELEMENT, expiry: int, strike: int):
    if not expiry:
        return index.value
    if option_type == OPTIONTYPE.FUT:
        if expiry not in contracts[index.name][option_type.name]:
            raise Exception(f"Invalid expiry {expiry} for index {index.name}")
        return contracts[index.name][option_type.name][expiry]
    expiry = int(expiry)
    strike = float(strike)
    if expiry not in contracts[index.name][option_type.name]:
        raise Exception(f"Invalid expiry {expiry} for index {index.name}")
    if strike not in contracts[index.name][option_type.name][expiry]:
        raise Exception(f"Invalid strike {strike} for index {index.name}")
    return contracts[index.name][option_type.name][expiry][strike]

def parse_contract_data(master_data):
    today = datetime.now()
    int_today = int(today.strftime("%y%m%d"))
    EXPIRY_INDEX = 16
    STRIKE_INDEX = 17
    TOKEN_INDEX = 1

    UNDERLYING_NAME_INDEX = 3
    UNDERLYING_INDEX_NAME_INDEX = 15

    CONTRACT_TYPE_INDEX = 5
    future_key = "FUTIDX"
    option_key = "OPTIDX"

    OPTION_TYPE_INDEX = 18
    call_key = 3
    put_key = 4

    for row in master_data:
        name = row[UNDERLYING_NAME_INDEX]
        if name in NSEINDEX.choices():
            expiry = int(row[EXPIRY_INDEX].split("T")[0].replace("-", ""))
            row[EXPIRY_INDEX] = expiry
            series = row[CONTRACT_TYPE_INDEX]
            if series == future_key and row[UNDERLYING_INDEX_NAME_INDEX] != "":
                expiry = int(row[EXPIRY_INDEX] % 1000000)
                if expiry < int_today:
                    continue
                if expiry < expiries[NSEINDEX.to_enum(name)][MONTHLY_EXPIRY]:
                    expiries[NSEINDEX.to_enum(name)][MONTHLY_EXPIRY] = expiry
                    
                token = int(row[TOKEN_INDEX])
                contract = Contract(EXCHANGE.NSE, NSEINDEX.to_enum(name), expiry, strike_price=0, option_type=OPTIONTYPE.FUT)
                contracts[name][OPTIONTYPE.FUT.name][expiry] = token
                contracts_by_token[int(row[TOKEN_INDEX])] = contract
                
            elif series == option_key:
                option_type = int(row[OPTION_TYPE_INDEX])
                if option_type == call_key:
                    expiry = int(row[EXPIRY_INDEX] % 1000000)
                    if expiry < int_today:
                        continue
                    if expiry < expiries[NSEINDEX.to_enum(name)][WEEKLY_EXPIRY]:
                        expiries[NSEINDEX.to_enum(name)][NEXT_WEEKLY_EXPIRY] = expiries[NSEINDEX.to_enum(name)][WEEKLY_EXPIRY]
                        expiries[NSEINDEX.to_enum(name)][WEEKLY_EXPIRY] = expiry
                        
                    strike = float(row[STRIKE_INDEX])
                    if expiry not in contracts[name][OPTIONTYPE.CALL.name]:
                        contracts[name][OPTIONTYPE.CALL.name][expiry] = {}
                    token = int(row[TOKEN_INDEX])
                    contract = Contract(EXCHANGE.NSE, NSEINDEX.to_enum(name), expiry, strike, OPTIONTYPE.CALL)
                    contracts[name][OPTIONTYPE.CALL.name][expiry][strike] = token
                    contracts_by_token[int(row[TOKEN_INDEX])] = contract

                elif option_type == put_key:
                    expiry = int(row[EXPIRY_INDEX] % 1000000)
                    if expiry < int_today:
                        continue
                    strike = float(row[STRIKE_INDEX])
                    if expiry not in contracts[name][OPTIONTYPE.PUT.name]:
                        contracts[name][OPTIONTYPE.PUT.name][expiry] = {}
                    token = int(row[TOKEN_INDEX])
                    contract = Contract(EXCHANGE.NSE, NSEINDEX.to_enum(name), expiry, strike, OPTIONTYPE.PUT)
                    contracts[name][OPTIONTYPE.PUT.name][expiry][strike] = token
                    contracts_by_token[int(row[TOKEN_INDEX])] = contract
    logger.info("Contracts loaded successfully")
    
def get_current_week_expiry(index: ENUMELEMENT):
    return expiries[index][WEEKLY_EXPIRY]

def get_next_week_expiry(index: ENUMELEMENT):
    return expiries[index][NEXT_WEEKLY_EXPIRY]

def get_monthly_expiry(index: ENUMELEMENT):
    return expiries[index][MONTHLY_EXPIRY]

def get_previous_day_vix_value():
    get_quote(Config.FEED_ACCESS_TOKEN, NSEINDEX.NIFTY.value)

def get_previous_day_closing_price(index: ENUMELEMENT):
    pass


def subscribe_to_instruments(tokens: str, message_code: int = 1501, exchange_segment: int = 1):
    url = Config.FEED_BASE_URL + "/marketdata/instruments/subscription"
    headers = {"Content-Type": "application/json", "authorization": Config.FEED_ACCESS_TOKEN}
    # option subscription
    payload = {"instruments": [], "xtsMessageCode": message_code}
    for token in tokens:
        payload["instruments"].append(
            {"exchangeSegment": exchange_segment, "exchangeInstrumentID": int(token)}
        )

    payload = json.dumps(payload)
    try:
        response = requests.post(url, data=payload, headers=headers)
        response.raise_for_status()
    except Exception as ex:
        print(ex)


def parse_1501(data: Dict[str, str]):
    data = json.loads(data)
    token = int(data["ExchangeInstrumentID"])
    if "Touchline" not in data:
        touchline = data
    else:
        touchline = data["Touchline"]
    dt = from_exchange_timestamp(int(touchline["LastUpdateTime"])) 
    date = int_date(dt)
    time = int_time(dt)
    open = high = low = close = rupee_to_paise(touchline["LastTradedPrice"]*100)
    ohlc = OHLC(date, time, open, high, low, close)
    return token, ohlc


def parse_1502(data: Dict[str, str]):
    data = json.loads(data)
    token = int(data["ExchangeInstrumentID"])
    if "Touchline" not in data:
        touchline = data
    else:
        touchline = data["Touchline"]
    dt = from_exchange_timestamp(int(touchline["LastUpdateTime"])) 
    date = int_date(dt)
    time = int_time(dt)
    open = high = low = close =  rupee_to_paise(touchline["LastTradedPrice"])
    ohlc = OHLC(date, time, open, high, low, close)
    return token, ohlc


def get_quote(token: int):
    url = Config.FEED_BASE_URL + "/marketdata/instruments/quotes"
    payload = {
        "instruments": [{"exchangeSegment": 2, "exchangeInstrumentID": token}],
        "xtsMessageCode": 1502,
        "publishFormat": "JSON",
    }
    headers = {"Content-Type": "application/json", "authorization": Config.FEED_ACCESS_TOKEN}
    response = requests.post(url, json=payload, headers=headers)
    if response.status_code == 200:
        quotes = response.json()["result"]["listQuotes"]
        if len(quotes) > 0:
            token, ohlc = parse_1502(response.json()["result"]["listQuotes"][0])
            live_dict[token] = ohlc
            return ohlc
        else:
            response.raise_for_status()
    else:
        raise Exception(f"not able to get quote for token {token}")
    
def get_day_ohlc(access_token: str, token: int, start_date: int, end_date: int):
    url = Config.FEED_BASE_URL + "/marketdata/instruments/ohlc"
    params = {
        "exchangeSegment": 2,
        "exchangeInstrumentID": token,
        "startTime": datetime.strptime(str(start_date), "%y%m%d").strftime("%b %d %Y ") + "000000",
        "endTime": datetime.strptime(str(end_date), "%y%m%d").strftime("%b %d %Y ") + "000000",
        "compressionValue": 1,
        "compressionType": "D"
    }
    headers = {"Content-Type": "application/json", "authorization": access_token}
    response = requests.get(url, headers=headers, params=params)
    if response.status_code == 200:
        quotes = response.json()["result"]["dataReponse"].split(",")
        if len(quotes) > 0:
            for quote in quotes:
                quote = quote.split("|")
                dt = from_exchange_timestamp(int(quote[0]))
                date = int_date(dt)
                time = int_time(dt)
                open = high = low = close = rupee_to_paise(quote[4])
                ohlc = OHLC(date, time, open, high, low, close)
                return ohlc
        else:
            response.raise_for_status()
    else:
        raise Exception(f"not able to get quote for token {token}")

def on_connect():
    logger.info("connected")
    tokens_to_subscribe = []
    for token in NSEINDEX.values():
        tokens_to_subscribe.append(token)
    for index in NSEINDEX.choices():
        tokens_to_subscribe.append(get_token(NSEINDEX.to_enum(index), OPTIONTYPE.FUT, get_monthly_expiry(NSEINDEX.to_enum(index)), 0))

    subscribe_to_instruments(tokens_to_subscribe)

def on_message(data):
    # logger.info(f"on_message {data}")
    pass


def on_disconnect():
    logger.info("price feed disconnected")


def on_message1502_json_full(data):
    token, ohlc = parse_1502(data)
    live_dict[token] = ohlc


def on_message1501_json_full(data):
    token, ohlc = parse_1501(data)
    live_dict[token] = ohlc


def login_to_marketdata_api():
    url = Config.FEED_BASE_URL + "/marketdata/auth/login"
    payload = {"appKey": Config.FEED_API_KEY, "secretKey": Config.FEED_SECRET_KEY, "source": "WEBAPI"}

    response = requests.post(url, json=payload)

    if response.status_code == 200 and response.json()["type"] == "success":
        return response.json()["result"]["token"]
    else:
        raise Exception(response.json()["description"])

def initialize_feed():
    master_data = download_contract_data()
    parse_contract_data(master_data)
    Config.FEED_ACCESS_TOKEN = login_to_marketdata_api()
    if Config.FEED_ACCESS_TOKEN:
        logger.info("price feed login successful")
    socket = socketio.Client(logger=False, engineio_logger=False)

    socket.on("connect", on_connect)
    socket.on("message", on_message)

    socket.on("1502-json-full", on_message1502_json_full)
    socket.on("1501-json-full", on_message1501_json_full)
    socket.on("disconnect", on_disconnect)

    socket_url = (
        Config.FEED_BASE_URL
        + "/?token="
        + Config.FEED_ACCESS_TOKEN
        + "&userID="
        + Config.FEED_CLIENT_ID
        + "&publishFormat=JSON&broadcastMode=Full"
    )

    socket.connect(socket_url, {}, "websocket", None, "/marketdata/socket.io")
    socket.wait()

order_types_map = {
    ORDERTYPE.MARKET: "MARKET",
    ORDERTYPE.LIMIT: "LIMIT",
    ORDERTYPE.STOPLOSS: "STOPLOSS",
}

broker_to_local_order_types_map = {
    "Market": ORDERTYPE.MARKET,
    "Limit": ORDERTYPE.LIMIT,
    "StopLoss": ORDERTYPE.STOPLOSS,
}

product_types_map = {
    PRODUCTTYPE.MIS: "MIS",
    PRODUCTTYPE.NRML: "NRML",
}

exchange_map = {
    EXCHANGE.NSE: "NSEFO",
    EXCHANGE.BSE: "BSEFO",
    EXCHANGE.NFO: "NSEFO",
    EXCHANGE.BFO: "BSEFO"
}

side_map = {
    SIDE.BUY: "BUY",
    SIDE.SELL: "SELL"
}

order_status_map = {
    ORDERSTATUS.SENT: "SENT",
    ORDERSTATUS.PENDING: "PENDING",
    ORDERSTATUS.WORKING: "WORKING",
    ORDERSTATUS.CANCELLED: "CANCELLED",
    ORDERSTATUS.REJECTED: "REJECTED",
    ORDERSTATUS.COMPLETE: "Filled"
}

broker_to_local_order_status_map = {
    "Filled": ORDERSTATUS.COMPLETE,
    "Rejected": ORDERSTATUS.REJECTED,
    "Cancelled": ORDERSTATUS.CANCELLED,
}



def login(base_url: str, api_key: str, api_secret: str):
    url = base_url + "/interactive/user/session"
    headers = {"Content-Type": "application/json"}
    payload = {
        "secretKey": api_secret,
        "appKey": api_key,
        "source": "WebAPI"
    }
    
    response = requests.post(url, json=payload, headers=headers)
    response_json = response.json()
    if response.status_code == 200 and response_json["type"] == "success":
        return response_json["result"]["token"]
    else:
        raise Exception(response_json["description"])


def place_order(base_url: str, client_id: str, access_token: str, order: Order):
    token = get_token(order.contract.symbol, order.contract.option_type, order.contract.expiry_date, order.contract.strike_price)
    url = base_url + "/interactive/orders?clientID=" + client_id
    headers = {"Content-Type": "application/json", "authorization": access_token}
    payload = {
        "exchangeSegment": exchange_map[order.contract.exchange],
        "exchangeInstrumentID": token,
        "productType": product_types_map[order.product_type],
        "orderType": order_types_map[order.order_type],
        "orderSide": side_map[order.side],
        "timeInForce": "DAY",
        "disclosedQuantity": 0,
        "orderQuantity": order.quantity,
        "limitPrice": order.limit_price,
        "stopPrice": order.trigger_price,
        "orderUniqueIdentifier": order.tag,
        "clientID": client_id,
    }
    
    response = requests.post(url, json=payload, headers=headers)
    response_json = response.json()
    if response.status_code == 200 and response_json["type"] == "success":
        response_json["result"]["AppOrderID"]
        print(f"place order response {response_json}")
        logger.info(f"place order response {response_json}")
        return order.broker_order_id
    else:
        raise Exception(response_json["description"])


def modify_order(base_url: str, client_id: str, access_token: str, order: Order):
    url = base_url + "/interactive/orders?clientID=" + client_id
    headers = {"Content-Type": "application/json", "authorization": access_token}
    payload = {
        "appOrderID": order.broker_order_id,
        "modifiedProductType": product_types_map[order.product_type],
        "modifiedOrderType": order_types_map[order.order_type],
        "modifiedOrderQuantity": order.quantity,
        "modifiedDisclosedQuantity": 0,
        "modifiedLimitPrice": order.limit_price,
        "modifiedStopPrice": order.trigger_price,
        "modifiedTimeInForce": "DAY",
        "clientID": client_id,
    }
    
    response = requests.put(url, json=payload, headers=headers)
    response_json = response.json()
    if response.status_code == 200 and response_json["type"] == "success":
        logger.info(f"modify order response {response_json}")
    else:
        raise Exception(response_json["description"])


def cancel_order(base_url: str, client_id: str, access_token: str, order: Order):
    url = base_url + "/interactive/orders?clientID=" + client_id + "&appOrderID=" + order.broker_order_id
    headers = {"Content-Type": "application/json", "authorization": access_token}
    
    response = requests.delete(url, headers=headers)
    response_json = response.json()
    if response.status_code == 200 and response_json["type"] == "success":
        logger.info(f"cancel order response {response_json}")
    else:
        raise Exception(response_json["description"])


def get_order_status():
    pass


def get_order_book(base_url: str, client_id: str, access_token: str):
    url = base_url + "/interactive/orders?clientID=" + "AJAY2" ## This is for prop api
    headers = {"Content-Type": "application/json", "authorization": access_token}
    
    response = requests.get(url, headers=headers)
    response_json = response.json()
    if response.status_code == 200 and response_json["type"] == "success":
        return response_json["result"]
    else:
        raise Exception(response_json["description"])
    
