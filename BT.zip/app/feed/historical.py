from app.commons.enums import ENUMELEMENT, OPTIONTYPE, NSEINDEX
from app.database.utils import get_ohlc, get_index_ohlc, get_future_ohlc
from app.commons.models import OHLC
from app.commons.constants import MARKET_START_TIME, MARKET_END_TIME
from app.config import Config

def get_candles(
    index: ENUMELEMENT,
    length: int,
    interval: int,
    current_date: int,
    previous_date: int,
    trading_timestamp: int,
    expiry: str = None,
    strike: int = None,
    option_type: ENUMELEMENT = None,
    today_data: bool = False):
    candles = []
    exchange = NSEINDEX.get_exchange(index.name)
    if today_data:
        start_time = MARKET_START_TIME[exchange]
    else:
        start_time = trading_timestamp - ((length+1) * interval)
    if (not today_data) and (start_time < MARKET_START_TIME[exchange]):
        previous_day_start_time = MARKET_END_TIME[exchange] - (MARKET_START_TIME[exchange] - start_time)
        while previous_day_start_time < MARKET_END_TIME[exchange]:
            quote = get_quote(index, previous_date, expiry, strike, option_type, start_time=previous_day_start_time, end_time=previous_day_start_time+interval-Config.BT_FREQUENCY)
            if quote:
                candles.append(quote)
            previous_day_start_time += interval
        
        start_time = MARKET_START_TIME[exchange]
        while start_time < trading_timestamp:
            quote = get_quote(index, current_date, expiry, strike, option_type, start_time=start_time, end_time=start_time+interval-Config.BT_FREQUENCY)
            if quote:
                candles.append(quote)
            start_time += interval
    else:
        while start_time < trading_timestamp:
            quote = get_quote(index, current_date, expiry, strike, option_type, start_time=start_time, end_time=start_time+interval-Config.BT_FREQUENCY)
            if quote:
                candles.append(quote)
            start_time += interval
    
        
    return candles
    
    

def get_quote(
    index: ENUMELEMENT,
    date: int,
    expiry: str = None,
    strike: int = None,
    option_type: ENUMELEMENT = None,
    for_entry: bool = False,
    start_time: int = None,
    end_time: int = None,
    is_hedge: bool = False
) -> OHLC:
    """
    Get quote for a particular index, date, time, expiry, strike and option type

    Parameters:
        index (str): index name
        date (int): date in YYMMDD format
        time (int): time in HHMM format
        expiry (str): expiry date in YYMMDD format
        strike (int): strike price
        option_type (str): option type (CE/PE)
    Returns:
        dict: quote for a particular index, date, time, expiry, strike and option type
    """
    if not expiry:
        return get_index_ohlc(index, date, start_time, end_time)
    if option_type == OPTIONTYPE.FUT:
        return get_future_ohlc(index, date, start_time, end_time)
    else:
        return get_ohlc(index, date, expiry, strike, option_type, for_entry, start_time, end_time, is_hedge = is_hedge)
