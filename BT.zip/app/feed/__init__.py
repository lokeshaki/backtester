from app.commons.enums import ENUMELEMENT, FEEDSOURCE
from app.commons.models import OHLC
from app.feed import symphony as symphony
from app.feed import historical as historical

def get_quote(
    feed_source: ENUMELEMENT,
    index: ENUMELEMENT,
    date: int,
    start_time: int,
    end_time: int,
    expiry: str = None,
    strike: int = None,
    option_type: ENUMELEMENT = None,
    for_entry: bool = False,
    is_hedge: bool = False
) -> OHLC:
    if feed_source == FEEDSOURCE.SYMPHONY:
        # TODO add start_time and end_time
        return symphony.get_quote(index, date, expiry, strike, option_type, for_entry)
    elif feed_source == FEEDSOURCE.HISTORICAL:
        return historical.get_quote(index, date, expiry, strike, option_type, for_entry, start_time, end_time, is_hedge)
    

def get_candles(
    index: ENUMELEMENT,
    length: int,
    interval: int,
    current_date: int,
    previous_date: int,
    trading_timestamp: int,
    expiry: int,
    strike: int,
    option_type: ENUMELEMENT = None,
    is_live: bool = False,
    today_data: bool = False
):
    if is_live:
        return symphony.get_candles(index, length, interval, current_date, previous_date, trading_timestamp)
    else:
        return historical.get_candles(index, length, interval, current_date, previous_date, trading_timestamp, expiry, strike, option_type, today_data)