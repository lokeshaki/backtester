from app.commons.modules import threading, logging
from app.commons.models import OHLC
from app.commons.enums import NSEINDEX, ENUMELEMENT
from app.api_providers.symphony import initialize_feed, live_dict, get_quote as get_ohlc, get_token, initialize_feed, subscribe_to_instruments

logger = logging.getLogger(__name__)

def start_feed():
    threading.Thread(target=initialize_feed).start()

    price_received_for = []
    while True:
        for token in NSEINDEX.values():
            if token in live_dict:
                price_received_for.append(token)
                
        if len(price_received_for) == len(NSEINDEX.values()):
            break

    logger.info("price feed started")
            
def get_quote(
    index: ENUMELEMENT,
    date: int,
    time: int,
    expiry: str = None,
    strike: int = None,
    option_type: ENUMELEMENT = None,
    for_entry: bool = False
) -> OHLC:
    """
    Get quote for a particular index, date, time, expiry, strike and option type

    Parameters:
        index (str): index name
        date (int): date in YYMMDD format
        time (int): time in HHMM format
        expiry (str): expiry date in YYMMDD format
        strike (int): strike price
        option_type (str): option type (CE/PE)
    Returns:
        dict: quote for a particular index, date, time, expiry, strike and option type
    """
    token = get_token(index, option_type, expiry, strike)
    if token in live_dict:
        return live_dict[token]
    else:
        subscribe_to_instruments([token], 1502, 2)
        return get_ohlc(token)