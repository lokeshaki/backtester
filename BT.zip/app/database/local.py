from app.commons.modules import Dict, Set, logging, mysql, datetime, timedelta
from app.database.constants import *
from app.commons.constants import MCX_SYMBOLS, US_SYMBOLS
from app.config import Config
from app.commons.models import OHLC
import gc
from app.commons.modules import sys

logger = logging.getLogger(__name__)

VIX_DATA: Dict[int, int] = {}
INDEX_DATA: Dict[str, Dict[int, Dict[int, OHLC]]] = {}
CALLS_DATA: Dict[str, Dict[int, Dict[int, Dict[int, Dict[int, OHLC]]]]] = {}
PUTS_DATA: Dict[str, Dict[int, Dict[int, Dict[int, Dict[int, OHLC]]]]] = {}
FUTURE_DATA: Dict[str, Dict[int, Dict[int, OHLC]]] = {}
EXPIRIES_ON_DATE: Dict[str, Dict[int, Set[int]]] = {}
MCX_DATES: set = set([])
NSE_HOLDIDAYS: list[int] = []
MCX_HALF_TRADING_DAYS: list[int] = []
US_DATES: set = set([])

def generate_trading_dates(start_date: int):
    holidays = NSE_HOLDIDAYS.copy()
    avaliable_dates_for_trading = []
    current_date = start_date
    items_added = 0
    while True:
        current_datetime = datetime.strptime(str(current_date), "%y%m%d") + timedelta(days=1)
        current_date = int(current_datetime.strftime("%y%m%d"))
        if current_datetime.weekday() in [5,6] or current_datetime in holidays:
            continue
        avaliable_dates_for_trading.append(current_date)
        items_added += 1
        if items_added == 30:
            break
    return avaliable_dates_for_trading

def get_available_trading_dates(index):

    available_dates = sorted(set(CALLS_DATA[index.name]) & set(PUTS_DATA[index.name]))
    if len(available_dates) == 0:
        return []
    
    available_dates.extend(generate_trading_dates(available_dates[-1]))

    return available_dates

def load():
    try:

        if Config.BT_FREQUENCY not in [1, 60]:
            logger.info("Cann't run BT as BT_FREQUENCY is wrong. Valid options: 1 or 60")
            exit()

        logger.info(f"Special Dates: {Config.EXCEPTION_DATES}")
        logger.info("Connecting to mysql database")
        logger.info(
            f"MYSQL_HOST: {Config.MYSQL_HOST}, MYSQL_USER: {Config.MYSQL_USER}, MYSQL_PASSWORD: {Config.MYSQL_PASSWORD}, MYSQL_DATABASE: {Config.MYSQL_DATABASE}"
        )
        mydb = mysql.connect(
            host=Config.MYSQL_HOST,
            user=Config.MYSQL_USER,
            password=Config.MYSQL_PASSWORD,
            database=Config.MYSQL_DATABASE,
        )
        logger.info("Connected to mysql database")

        mycursor = mydb.cursor()

        if Config.MYSQL_DATABASE != "ushistoricaldb":

            ## Loading NSE HOLIDAYS
            try:
                mycursor.execute("SELECT * FROM holiday ORDER BY date")
                myresult = mycursor.fetchall()
                [NSE_HOLDIDAYS.append(x[0]) for x in myresult]
                del myresult
            except mysql.Error as err:
                logger.error("Error while loading holidays from mysql database")
            
            ## Loading MCX HALF TRADING DAYS
            try:
                mycursor.execute("SELECT * FROM half_trading_day_mcx ORDER BY date")
                myresult = mycursor.fetchall()
                [MCX_HALF_TRADING_DAYS.append(x[0]) for x in myresult]
                del myresult
            except mysql.Error as err:
                logger.error("Error while loading half_trading_day_mcx from mysql database")

            ## Loading India Vix Data
            logger.info("Loading VIX_DATA from mysql database")
            table_name = "india_vix"
            try:
                mycursor.execute(
                    "SELECT date, close FROM "
                    + table_name
                    + f" where date >= {Config.DATA_LOAD_FROM} and date <= {Config.DATA_LOAD_TILL} ORDER BY date DESC"
                )
            except mysql.Error as err:
                logger.error("Error while loading VIX_DATA from mysql database")
            myresult = mycursor.fetchall()
            for x in myresult:
                VIX_DATA[x[DATE_COLUMN]] = x[TIME_COLUMN]
            del myresult
            logger.info("Size of VIX_DATA: %s", sys.getsizeof(VIX_DATA))
            logger.info("Loaded VIX_DATA from mysql database")

        if Config.BT_FREQUENCY == 1:

            logger.info("Connecting to mysql tick database")
            logger.info(
                f"MYSQL_HOST: {Config.MYSQL_HOST}, MYSQL_USER: {Config.MYSQL_USER}, MYSQL_PASSWORD: {Config.MYSQL_PASSWORD}, MYSQL_DATABASE: {Config.MYSQL_TICK_DATABASE}"
            )
            mydb = mysql.connect(
                host=Config.MYSQL_HOST,
                user=Config.MYSQL_USER,
                password=Config.MYSQL_PASSWORD,
                database=Config.MYSQL_TICK_DATABASE,
            )
            logger.info("Connected to mysql tick database")

            mycursor = mydb.cursor()

        gc.collect()
        ## Loading Index Data
        logger.info(Config.LOAD_INDEXES)
        for index in Config.LOAD_INDEXES:
            logger.info("Loading INDEX_DATA for %s from mysql database", index)
            table_name = index.lower() + "_cash"
            try:
                mycursor.execute(
                    "SELECT date, time, symbol, open, high, low, close FROM "
                    + table_name
                    + f" where date >= {Config.DATA_LOAD_FROM} and date <= {Config.DATA_LOAD_TILL} ORDER BY date DESC"
                )
            except mysql.Error as err:
                logger.error(
                    "Error while loading INDEX_DATA for %s from mysql database, %s", index, err
                )
                continue
            myresult = mycursor.fetchall()
            INDEX_DATA[index] = {}
            for x in myresult:
                if x[DATE_COLUMN] not in INDEX_DATA[index]:
                    INDEX_DATA[index][x[DATE_COLUMN]] = {
                        x[TIME_COLUMN]: OHLC(
                            x[DATE_COLUMN],
                            x[TIME_COLUMN],
                            x[STRIKE_COLUMN],
                            x[EXPIRY_COLUMN],
                            x[OPEN_COLUMN],
                            x[HIGH_COLUMN],
                        )
                    }
                    if (index in US_SYMBOLS) and (x[DATE_COLUMN] not in US_DATES):
                        US_DATES.add(x[DATE_COLUMN])
                else:
                    INDEX_DATA[index][x[DATE_COLUMN]][x[TIME_COLUMN]] = OHLC(
                        x[DATE_COLUMN],
                        x[TIME_COLUMN],
                        x[STRIKE_COLUMN],
                        x[EXPIRY_COLUMN],
                        x[OPEN_COLUMN],
                        x[HIGH_COLUMN],
                    )
            del myresult
            logger.info(
                "Size of INDEX_DATA for %s: %s", index, sys.getsizeof(INDEX_DATA[index])
            )
            logger.info("Loaded INDEX_DATA for %s from mysql database", index)

        gc.collect()
        ## Loading Call Data
        for index in Config.LOAD_INDEXES:
            logger.info("Loading CALLS_DATA for %s from mysql database", index)
            table_name = index.lower() + "_call"
            try:
                mycursor.execute(
                    "SELECT date, time, symbol, strike, expiry, open, high, low, close, volume, coi FROM "
                    + table_name
                    + f" where date >= {Config.DATA_LOAD_FROM} and date <= {Config.DATA_LOAD_TILL}  ORDER BY date DESC"
                )
            except mysql.Error as err:
                logger.error(
                    "Error while loading CALLS_DATA for %s from mysql database, %s", index, err
                )
                continue
            myresult = mycursor.fetchall()
            CALLS_DATA[index] = {}
            EXPIRIES_ON_DATE[index] = {}
            for x in myresult:
                if x[DATE_COLUMN] not in CALLS_DATA[index]:
                    CALLS_DATA[index][x[DATE_COLUMN]] = {
                        x[TIME_COLUMN]: {
                            x[EXPIRY_COLUMN]: {
                                x[STRIKE_COLUMN]: OHLC(
                                    x[DATE_COLUMN],
                                    x[TIME_COLUMN],
                                    x[OPEN_COLUMN],
                                    x[HIGH_COLUMN],
                                    x[LOW_COLUMN],
                                    x[CLOSE_COLUMN],
                                    x[9],
                                    x[10],
                                )
                            }
                        }
                    }
                else:
                    if x[TIME_COLUMN] not in CALLS_DATA[index][x[DATE_COLUMN]]:
                        CALLS_DATA[index][x[DATE_COLUMN]][x[TIME_COLUMN]] = {
                            x[EXPIRY_COLUMN]: {
                                x[STRIKE_COLUMN]: OHLC(
                                    x[DATE_COLUMN],
                                    x[TIME_COLUMN],
                                    x[OPEN_COLUMN],
                                    x[HIGH_COLUMN],
                                    x[LOW_COLUMN],
                                    x[CLOSE_COLUMN],
                                    x[9],
                                    x[10],
                                )
                            }
                        }
                    else:
                        if (
                            x[EXPIRY_COLUMN]
                            not in CALLS_DATA[index][x[DATE_COLUMN]][x[TIME_COLUMN]]
                        ):
                            CALLS_DATA[index][x[DATE_COLUMN]][x[TIME_COLUMN]][
                                x[EXPIRY_COLUMN]
                            ] = {
                                x[STRIKE_COLUMN]: OHLC(
                                    x[DATE_COLUMN],
                                    x[TIME_COLUMN],
                                    x[OPEN_COLUMN],
                                    x[HIGH_COLUMN],
                                    x[LOW_COLUMN],
                                    x[CLOSE_COLUMN],
                                    x[9],
                                    x[10],
                                )
                            }
                        else:
                            CALLS_DATA[index][x[DATE_COLUMN]][x[TIME_COLUMN]][
                                x[EXPIRY_COLUMN]
                            ][x[STRIKE_COLUMN]] = OHLC(
                                x[DATE_COLUMN],
                                x[TIME_COLUMN],
                                x[OPEN_COLUMN],
                                x[HIGH_COLUMN],
                                x[LOW_COLUMN],
                                x[CLOSE_COLUMN],
                                x[9],
                                x[10],
                            )

                if x[DATE_COLUMN] not in EXPIRIES_ON_DATE[index]:
                    EXPIRIES_ON_DATE[index][x[DATE_COLUMN]] = set([x[EXPIRY_COLUMN]])
                else:
                    EXPIRIES_ON_DATE[index][x[DATE_COLUMN]].add(x[EXPIRY_COLUMN])
            del myresult
            logger.info(
                "Size of CALLS_DATA for %s: %s", index, sys.getsizeof(CALLS_DATA[index])
            )
            logger.info("Loaded CALLS_DATA for %s from mysql database", index)

        gc.collect()
        ## Loading Put Data
        for index in Config.LOAD_INDEXES:
            logger.info("Loading PUTS_DATA for %s from mysql database", index)
            table_name = index.lower() + "_put"
            try:
                mycursor.execute(
                    "SELECT date, time, symbol, strike, expiry, open, high, low, close, volume, coi FROM "
                    + table_name
                    + f" where date >= {Config.DATA_LOAD_FROM} and date <= {Config.DATA_LOAD_TILL} ORDER BY date DESC"
                )
            except mysql.Error as err:
                logger.error(
                    "Error while loading PUTS_DATA for %s from mysql database", index
                )
                continue
            myresult = mycursor.fetchall()
            PUTS_DATA[index] = {}
            for x in myresult:
                if x[DATE_COLUMN] not in PUTS_DATA[index]:
                    PUTS_DATA[index][x[DATE_COLUMN]] = {
                        x[TIME_COLUMN]: {
                            x[EXPIRY_COLUMN]: {
                                x[STRIKE_COLUMN]: OHLC(
                                    x[DATE_COLUMN],
                                    x[TIME_COLUMN],
                                    x[OPEN_COLUMN],
                                    x[HIGH_COLUMN],
                                    x[LOW_COLUMN],
                                    x[CLOSE_COLUMN],
                                    x[9],
                                    x[10],
                                )
                            }
                        }
                    }
                else:
                    if x[TIME_COLUMN] not in PUTS_DATA[index][x[DATE_COLUMN]]:
                        PUTS_DATA[index][x[DATE_COLUMN]][x[TIME_COLUMN]] = {
                            x[EXPIRY_COLUMN]: {
                                x[STRIKE_COLUMN]: OHLC(
                                    x[DATE_COLUMN],
                                    x[TIME_COLUMN],
                                    x[OPEN_COLUMN],
                                    x[HIGH_COLUMN],
                                    x[LOW_COLUMN],
                                    x[CLOSE_COLUMN],
                                    x[9],
                                    x[10],
                                )
                            }
                        }
                    else:
                        if (
                            x[EXPIRY_COLUMN]
                            not in PUTS_DATA[index][x[DATE_COLUMN]][x[TIME_COLUMN]]
                        ):
                            PUTS_DATA[index][x[DATE_COLUMN]][x[TIME_COLUMN]][
                                x[EXPIRY_COLUMN]
                            ] = {
                                x[STRIKE_COLUMN]: OHLC(
                                    x[DATE_COLUMN],
                                    x[TIME_COLUMN],
                                    x[OPEN_COLUMN],
                                    x[HIGH_COLUMN],
                                    x[LOW_COLUMN],
                                    x[CLOSE_COLUMN],
                                    x[9],
                                    x[10],
                                )
                            }
                        else:
                            PUTS_DATA[index][x[DATE_COLUMN]][x[TIME_COLUMN]][
                                x[EXPIRY_COLUMN]
                            ][x[STRIKE_COLUMN]] = OHLC(
                                x[DATE_COLUMN],
                                x[TIME_COLUMN],
                                x[OPEN_COLUMN],
                                x[HIGH_COLUMN],
                                x[LOW_COLUMN],
                                x[CLOSE_COLUMN],
                                x[9],
                                x[10],
                            )
                if x[DATE_COLUMN] not in EXPIRIES_ON_DATE[index]:
                    EXPIRIES_ON_DATE[index][x[DATE_COLUMN]] = set([x[EXPIRY_COLUMN]])
                else:
                    EXPIRIES_ON_DATE[index][x[DATE_COLUMN]].add(x[EXPIRY_COLUMN])
            del myresult
            logger.info(
                "Size of PUTS_DATA for %s: %s", index, sys.getsizeof(PUTS_DATA[index])
            )
            logger.info("Loaded PUTS_DATA for %s from mysql database", index)
        gc.collect()

        if Config.MYSQL_DATABASE != "ushistoricaldb":
        
            for index in Config.LOAD_INDEXES:
                logger.info("Loading FUTURE_DATA for %s from mysql database", index)
                table_name = index.lower() + "_future"
                try:
                    mycursor.execute(
                        "SELECT date, time, symbol, open, high, low, close FROM "
                        + table_name
                        + f" where date >= {Config.DATA_LOAD_FROM} and date <= {Config.DATA_LOAD_TILL} ORDER BY date DESC"
                    )
                except mysql.Error as err:
                    logger.error(
                        "Error while loading FUTURE_DATA for %s from mysql database", index
                    )
                    continue
                myresult = mycursor.fetchall()
                FUTURE_DATA[index] = {}
                for x in myresult:

                    if (index in MCX_SYMBOLS) and (x[DATE_COLUMN] not in MCX_DATES):
                        MCX_DATES.add(x[DATE_COLUMN])
                    
                    if x[DATE_COLUMN] not in FUTURE_DATA[index]:
                        FUTURE_DATA[index][x[DATE_COLUMN]] = {
                            x[TIME_COLUMN]: OHLC(
                                x[DATE_COLUMN],
                                x[TIME_COLUMN],
                                x[STRIKE_COLUMN],
                                x[EXPIRY_COLUMN],
                                x[OPEN_COLUMN],
                                x[HIGH_COLUMN],
                            )
                        }
                    else:
                        FUTURE_DATA[index][x[DATE_COLUMN]][x[TIME_COLUMN]] = OHLC(
                            x[DATE_COLUMN],
                            x[TIME_COLUMN],
                            x[STRIKE_COLUMN],
                            x[EXPIRY_COLUMN],
                            x[OPEN_COLUMN],
                            x[HIGH_COLUMN],
                        )
                del myresult
                logger.info(
                    "Size of FUTURE_DATA for %s: %s",
                    index,
                    sys.getsizeof(FUTURE_DATA[index]),
                )
                logger.info("Loaded FUTURE_DATA for %s from mysql database", index)
        gc.collect()

        # Load MCX Expiry Data
        if Config.MYSQL_DATABASE != "ushistoricaldb":
            for index in Config.LOAD_INDEXES:
                if index in MCX_SYMBOLS:
                    logger.info("Loading MCX expiry data for %s from mysql database", index)
                    table_name = index.lower() + "_expiry"
                    try:
                        mycursor.execute(
                            "SELECT date, expiry1, expiry2, expiry3, expiry4 FROM "
                            + table_name
                            + f" where date >= {Config.DATA_LOAD_FROM} and date <= {Config.DATA_LOAD_TILL} ORDER BY date DESC"
                        )
                        myresult = mycursor.fetchall()
                        
                        # Initialize EXPIRIES_ON_DATE for MCX instruments
                        if index not in EXPIRIES_ON_DATE:
                            EXPIRIES_ON_DATE[index] = {}
                        
                        for x in myresult:
                            date = x[0]  # date column
                            expiries = []
                            
                            # Add non-null expiry dates
                            for i in range(1, 5):  # expiry1, expiry2, expiry3, expiry4
                                if x[i] is not None:
                                    expiries.append(x[i])
                            
                            if expiries:
                                EXPIRIES_ON_DATE[index][date] = set(sorted(expiries))
                        
                        del myresult
                        logger.info("Loaded MCX expiry data for %s from mysql database", index)
                        
                    except mysql.Error as err:
                        logger.error("Error while loading MCX expiry data for %s: %s", index, err)
                        continue

        gc.collect()
    except Exception as e:
        import traceback

        traceback.print_exc()
        logger.critical(f"Error in data loading: {e}")
