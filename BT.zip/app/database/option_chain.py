from app.commons.modules import requests, re, datetime
from app.commons.enums import ENUMELEMENT, NSEINDEX
from app.commons.models import OHLC
from app.api_providers.symphony import get_monthly_expiry


CALL_OPTION_CHAIN_DATA = {}
PUT_OPTION_CHAIN_DATA = {}

match_regex = re.compile("(NIFTY|BANKNIFTY|FINNIFTY)(\d{2})(\w{1,3})(\d{2})(\d{0,10})(.{2})")


def update_otion_chain(index: ENUMELEMENT, option_type: ENUMELEMENT, expiry: int):
    expiry = datetime.strptime(str(expiry), "%y%m%d").strftime("%Y-%m-%d")
    url = (
        "https://nw.nuvamawealth.com"
        + "/edelmw-content/content/options/optionchaindetails"
        + f"/OPTIDX"
        + f"/{index.name}/"
        + expiry
    )
    headers = {
        "authority": "nw.nuvamawealth.com",
        "origin": "https://www.nuvamawealth.com",
        "referer": "https://www.nuvamawealth.com/",
        "source": "EDEL",
        # "appidkey": "",
        "user-agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_0) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.5 Safari/605.1.15",
        "content-type": "application/json",
        "appidkey": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhcHAiOjAsImZmIjoiVyIsImJkIjoid2ViLXBjIiwibmJmIjoxNjkwNTQxNjQ3LCJzcmMiOiJlbXRtdyIsImF2IjoiMi4wLjMiLCJhcHBpZCI6IjFmZWZjY2Y2YmQzYzllNjFkMWNlYTFlMDY2ZWJlMDg1IiwiaXNzIjoiZW10IiwiZXhwIjoxNjkwNTY5MDAwLCJpYXQiOjE2OTA1NDE5NDd9.Cl5oqCYl4Yx4fiC_oWSsDzIe-8vgkPqWqYAP5XuLtps"
    }
    
    response = requests.get(url, headers=headers)
    
    now = datetime.now()
    date = now.strftime("%Y%m%d")
    time = now.strftime("%H%M%S")
    CALL_OPTION_CHAIN_DATA[index.name] = {}
    PUT_OPTION_CHAIN_DATA[index.name] = {}
    if response.status_code == 200:
        data = response.json()
        data = data["data"]["opChn"]
        for quote in data:
            ceqt = quote["ceQt"]
            peqt = quote["peQt"]
            ce_trading_symbol = ceqt["trdSym"]
            matches = match_regex.findall(ce_trading_symbol)[0]
            symbol = matches[0]
            expiry_year = matches[1]
            expiry_month = matches[2]
            expiry_day = matches[3]
            strike = float(matches[4])
            monthly_expiry = get_monthly_expiry(NSEINDEX.to_enum(symbol))
            if expiry_month == "O":
                expiry_month = "10"
            elif expiry_month == "N":
                expiry_month = "11"
            elif expiry_month == "D":
                expiry_month = "12"
            elif expiry_month == "OCT":
                expiry_month = "10"
                expiry_day = str(monthly_expiry)[-2:]
                strike = float(str(matches[3]) + str(matches[4]))
            elif expiry_month == "NOV":
                expiry_month = "11"
                expiry_day = str(monthly_expiry)[-2:]
                strike = float(str(matches[3]) + str(matches[4]))
            elif expiry_month == "DEC":
                expiry_month = "12"
                expiry_day = str(monthly_expiry)[-2:0]
                strike = float(str(matches[3]) + str(matches[4]))
            expiry = int(f"{expiry_year}{expiry_month}{expiry_day}")
            option_type = matches[5]
            ce_ltp = int(float(ceqt["ltp"])*100)
            
                
            if (expiry not in CALL_OPTION_CHAIN_DATA[symbol]):
                CALL_OPTION_CHAIN_DATA[symbol][expiry] = {
                    strike: OHLC(
                        date,
                        time,
                        ce_ltp,
                        ce_ltp,
                        ce_ltp,
                        ce_ltp
                    )
                }
            else:
                CALL_OPTION_CHAIN_DATA[symbol][expiry][strike] = OHLC(
                    date,
                    time,
                    ce_ltp,
                    ce_ltp,
                    ce_ltp,
                    ce_ltp
                )
            
            
            pe_trading_symbol = peqt["trdSym"]
            matches = match_regex.findall(pe_trading_symbol)[0]
            symbol = matches[0]
            expiry_year = matches[1]
            expiry_month = matches[2]
            expiry_day = matches[3]
            strike = float(matches[4])
            if expiry_month in "O":
                expiry_month = "10"
            elif expiry_month == "N":
                expiry_month = "11"
            elif expiry_month == "D":
                expiry_month = "12"
            elif expiry_month == "OCT":
                expiry_month = "10"
                expiry_day = str(monthly_expiry)[-2:]
                strike = float(str(matches[3]) + str(matches[4]))
            elif expiry_month == "NOV":
                expiry_month = "11"
                expiry_day = str(monthly_expiry)[-2:]
                strike = float(str(matches[3]) + str(matches[4]))
            elif expiry_month == "DEC":
                expiry_month = "12"
                expiry_day = str(monthly_expiry)[-2:0]
                strike = float(str(matches[3]) + str(matches[4]))
            
            expiry = int(f"{expiry_year}{expiry_month}{expiry_day}")
            option_type = matches[5]
            pe_ltp = int(float(peqt["ltp"])*100)
            
            
            
            if (expiry not in PUT_OPTION_CHAIN_DATA[index.name]):
                PUT_OPTION_CHAIN_DATA[index.name][expiry] = {
                    strike: OHLC(
                        date,
                        time,
                        pe_ltp,
                        pe_ltp,
                        pe_ltp,
                        pe_ltp
                    )
                }
            else:
                PUT_OPTION_CHAIN_DATA[index.name][expiry][strike] = OHLC(
                    date,
                    time,
                    pe_ltp,
                    pe_ltp,
                    pe_ltp,
                    pe_ltp
                )
            
