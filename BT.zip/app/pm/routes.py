from app.backtester import run_vwap_backtest, run_backtest
from app.parser.utils import parse_portfolio_json
from app.pm import run_portfolio
from flask import Blueprint, request
from app.commons.enums import *
import logging

logger = logging.getLogger(__name__)
backtest_bp = Blueprint('backtest', __name__, url_prefix='/backtest')


@backtest_bp.route('/start', methods=['POST'])
def start():
    """
    Start backtest for given strategy
    :param strategy: Strategy object
    :return: None
    """
    try:
        portfolio_json = request.json.get("portfolio")
        start_date = request.json.get("start_date")
        end_date = request.json.get("end_date")
        fix_vix = int(request.json.get("fix_vix"))
        broker_details = request.json.get("broker_details")
        exchange = eval(request.json.get("exchange"))
        product_type = eval(request.json.get("product_type"))
        order_type = eval(request.json.get("order_type"))
        check_interval = request.json.get("check_interval")
        feed_source = eval(request.json.get("feed_source"))
        portfolio = parse_portfolio_json(portfolio_json)
        backtest_result = run_portfolio(portfolio, start_date, end_date, fix_vix, broker_details, exchange, product_type, order_type, check_interval, feed_source)
        result = backtest_result
        return result, 200
    except KeyError as e:
        return str(e), 400
    except Exception as e:
        logger.exception(e)
        return str(e), 500
