from app.backtester.models import BacktestResult, ResultTrade
from app.evaluator.utils import calculate_current_pnl
from app.commons.enums import NUMBERTYPE
from app.commons.utils import generate_id, round_to, get_strike_diff_for_index
from app.commons.modules import datetime, os, timedelta
from app.commons.models import Order
from app.config import Config
from typing import Dict, List
from time import time

def generate_backtest_result(start_time, orders: List[Order], strategy_profits, strategy_losses) -> float:
    """
    Calculate the profit of a backtest result

    Parameters:
        backtest_result (BacktestResult): backtest result to calculate profit for

    Returns:
        float: profit
    """
    pnl = 0
    max_drawdown = 0
    total_profit_trades = 0
    total_loss_trades = 0
    current_win_streak = 0
    current_loss_streak = 0
    max_win_streak = 0
    max_loss_streak = 0
    winning_trades = 0
    lossing_trades = 0
    total_number_of_trades = 0
    net_quantity = 0
    open_order = None
    open_orders: Dict[str,Order] = {}
    if Config.WRITE_TRADES_TO_FILE:
        pnl_file = open(
            os.path.join(
                os.path.dirname(os.path.abspath(__file__)), "pnl.csv"
            ),
            "w",
        )
        pnl_file.write(
            "strategy_entry_number,leg_id,entry_number,stop_loss_entry_number,take_profit_entry_number,symbol,expiry_date,strike_price,option_type,order_side,order_quantity,entry_time,entry_price,exit_time,exit_price,pnl,reason,max_profit,max_loss\n"
        )
    trades_for_final_response = []
    for order in orders:
        order_found_in_open_orders = False
        for open_order_key in list(open_orders.keys()):
            open_order = open_orders[open_order_key]
            if open_order.strategy_name == order.strategy_name and open_order.leg_id == order.leg_id and open_order.contract == order.contract and open_order.side != order.side:
                order_found_in_open_orders = True
                current_pnl = (
                    calculate_current_pnl(
                        order.average_price,
                        open_order.average_price,
                        open_order.side,
                        NUMBERTYPE.POINT,
                    )
                    * order.quantity
                )
                entry_date = datetime.strptime(str(open_order.creation_time.date), "%y%m%d")
                entry_time = entry_date + timedelta(seconds=open_order.creation_time.time)
                exit_date = datetime.strptime(str(order.creation_time.date), "%y%m%d")
                exit_time = exit_date + timedelta(seconds=order.creation_time.time)
                if Config.WRITE_TRADES_TO_FILE:
                    pnl_file.write(
                        f"{order.strategy_entry_number},{open_order.leg_id},{open_order.entry_number},{order.contract.symbol},{order.contract.expiry_date},{order.contract.strike_price},{order.contract.option_type},{open_order.side.name},{open_order.quantity},{entry_time},{open_order.average_price},{exit_time},{order.average_price},{current_pnl},{order.reason},{open_order.max_profit*open_order.quantity},{open_order.max_loss*open_order.quantity}\n"
                    )
                
                trades_for_final_response.append(ResultTrade(
                    open_order.strategy_entry_number,
                    open_order.strategy_name,
                    open_order.leg_id,
                    open_order.entry_number,
                    open_order.stop_loss_entry_number,
                    open_order.take_profit_entry_number,
                    order.contract.symbol,
                    order.contract.expiry_date,
                    order.contract.strike_price,
                    order.contract.option_type,
                    open_order.side,
                    open_order.quantity,
                    entry_time,
                    open_order.average_price,
                    exit_time,
                    order.average_price,
                    current_pnl,
                    order.reason,
                    open_order.max_profit*open_order.quantity,
                    open_order.max_loss*open_order.quantity,
                    open_order.index_price,
                    order.index_price
                ))
                if current_pnl > 0:
                    winning_trades += 1
                    total_profit_trades += 1
                    current_win_streak += 1
                    if current_loss_streak > max_loss_streak:
                        max_loss_streak = current_loss_streak
                    current_loss_streak = 0
                else:
                    lossing_trades += 1
                    total_loss_trades += 1
                    current_loss_streak += 1
                    if current_win_streak > max_win_streak:
                        max_win_streak = current_win_streak
                    current_win_streak = 0
                total_number_of_trades += 1
                pnl += current_pnl
                if pnl < max_drawdown:
                    max_drawdown = pnl
                net_quantity += order.quantity * order.side.value
                open_orders.pop(open_order_key)
                
        if order_found_in_open_orders:
            continue
        open_orders[f"{order.strategy_name}_{order.leg_id}"] = order

    win_percentage = (
        winning_trades / total_number_of_trades if total_profit_trades else 0
    )
    loss_percentage = (
        lossing_trades / total_number_of_trades if total_loss_trades else 0
    )
    id = generate_id()
    time_taken = time() - start_time
    backtest_result = BacktestResult(
        id,
        pnl,
        max_drawdown,
        win_percentage,
        loss_percentage,
        max_win_streak,
        max_loss_streak,
        total_number_of_trades,
        time_taken,
        trades_for_final_response,
        strategy_profits,
        strategy_losses
    )
    return backtest_result


