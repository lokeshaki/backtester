from typing import Dict
from app.commons.enums import ENUMELEMENT, BROKER
from app.commons.models import Order
from app.broker import paper as paper_broker
from app.broker import jainampro as jainampro_broker


def broker_login(**kwargs) -> Dict:
    """_summary_

    Args:
        broker (ENUMELEMENT): _description_

    Returns:
        Dict: _description_
    """
    broker = eval(kwargs.get('broker'))
    if broker == BROKER.PAPER:
        return paper_broker.login(**kwargs)
    elif broker == BROKER.JAINAMPRO:
        return jainampro_broker.login(**kwargs)
    

def place_order(broker: ENUMELEMENT, client_id: str, order: Order, order_price: float=None) -> str:
    """
    Place an order with the broker
    
    Parameters:
        broker (ENUMELEMENT): broker to use
        order (Order): order to place
    
    Returns:
        str: order id
    """
    if broker == BROKER.PAPER:
        return paper_broker.place_order(order, order_price)
    elif broker == BROKER.JAINAMPRO:
        return jainampro_broker.place_order(client_id, order)


def modify_order(broker: ENUMELEMENT, client_id: str, order_id: str, order: Order) -> str:
    """
    Modify an order with the broker
    
    Parameters:
        broker (ENUMELEMENT): broker to use
        order_id (str): order id
        order (Order): order to modify
    
    Returns:
        str: order id
    """
    if broker == BROKER.PAPER:
        return paper_broker.modify_order(order_id, order)
    elif broker == BROKER.JAINAMPRO:
        return jainampro_broker.modify_order(client_id, order)
    

def cancel_order(broker: ENUMELEMENT, client_id: str, order_id: str) -> str:
    """
    Cancel an order with the broker
    
    Parameters:
        broker (ENUMELEMENT): broker to use
        order_id (str): order id
    
    Returns:
        str: order id
    """
    if broker == BROKER.PAPER:
        return paper_broker.cancel_order(order_id)
    elif broker == BROKER.JAINAMPRO:
        return jainampro_broker.cancel_order(order_id)