from time import sleep
from typing import Dict

from app.commons.models import Order, Trade
from app.commons.enums import ORDERSTATUS, ORDERTYPE
from app.commons.utils import generate_id
from app.config import Config

from app.broker.utils import write_to_trade_file
from app.feed.historical import get_quote


OPEN_ORDERS: Dict[str, Order] = {}
CLOSED_ORDERS: Dict[str, Order] = {}

def login(**kwargs) -> Dict:
    ## TODO: Implement login
    pass

def place_order(order: Order, order_price: float=None) -> str:
    if order.order_type == ORDERTYPE.LIMIT:
        raise NotImplementedError("Limit orders not implemented yet")
    id = generate_id()
    if order_price in [None, 0]:
        quote = get_quote(order.contract.symbol, order.creation_time.date, order.contract.expiry_date, order.contract.strike_price, order.contract.option_type, False, order.creation_time.time, order.creation_time.time, True)
        order_price = quote.open/100.0
    trade = Trade(order.contract, order.side, order.quantity, order_price, order.creation_time)
    order.average_price = order_price
    order.filled_quantity = order.quantity
    if Config.WRITE_TRADES_TO_FILE:
        write_to_trade_file(trade, order.reason)
    order.status = ORDERSTATUS.COMPLETE
    OPEN_ORDERS[id] = order
    
    return id


def modify_order(id: str, order: Order):
    if order.order_type == ORDERTYPE.LIMIT:
        raise NotImplementedError("Limit orders not implemented yet")
    OPEN_ORDERS[id] = order
    
def cancel_order(id: str):
    if id not in OPEN_ORDERS:
        raise ValueError("Order not found")
    order: Order = OPEN_ORDERS[id]
    order.status = ORDERSTATUS.CANCELLED
    CLOSED_ORDERS[id] = order
    del OPEN_ORDERS[id]


def get_order_history(id: str):
    if id in OPEN_ORDERS:
        return OPEN_ORDERS[id]
    elif id in CLOSED_ORDERS:
        return CLOSED_ORDERS[id]
    else:
        raise ValueError("Order not found")

        

                    
                    
                    
    
