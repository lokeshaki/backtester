from app.commons.enums import ENUMELEMENT, ORDERSTATUS
from app.commons.modules import List, uuid, random


class Contract:
    def __init__(
        self,
        exchange: ENUMELEMENT,
        symbol: ENUMELEMENT,
        expiry_date: int,
        strike_price: float,
        option_type: ENUMELEMENT,
    ):
        self.exchange = exchange
        self.symbol = symbol
        self.expiry_date = expiry_date
        self.strike_price = strike_price
        self.option_type = option_type
        
        self.ltp = None
        
    def __repr__(self):
        return "<Contract %s %s %s %s %s>" % (
            self.exchange,
            self.symbol,
            self.expiry_date,
            self.strike_price,
            self.option_type,
        )

    def __eq__(self, other):
        return (
            self.exchange == other.exchange
            and self.symbol == other.symbol
            and self.expiry_date == other.expiry_date
            and self.strike_price == other.strike_price
            and self.option_type == other.option_type
        )
    
    def to_json(self):
        return {
            "exchange": self.exchange.name,
            "symbol": self.symbol.name,
            "expiry_date": self.expiry_date,
            "strike_price": self.strike_price,
            "option_type": self.option_type.name,
        }

class TimeStamp:
    def __init__(self, date: int, time: int):
        self.date = date
        self.time = time

    def __repr__(self):
        return "<TimeStamp %s %s>" % (self.date, self.time)

    def __eq__(self, other):
        return self.date == other.date and self.time == other.time
    

class OHLC:
    def __init__(
        self,
        date: int,
        time: int,
        open: float,
        high: float,
        low: float,
        close: float,
        volume: float = 0,
        coi: float = 0,
    ):
        self.date = date
        self.time = time
        self.open = open
        self.high = high
        self.low = low
        self.close = close
        self.volume = volume
        self.coi = coi

    def __repr__(self):
        return "<OHLC %s %s %s %s %s %s %s %s>" % (
            self.date,
            self.time,
            self.open,
            self.high,
            self.low,
            self.close,
            self.volume,
            self.coi
        )

    def __eq__(self, other):
        return (
            self.date == other.date
            and self.time == other.time
            and self.open == other.open
            and self.high == other.high
            and self.low == other.low
            and self.close == other.close
            and self.coi == other.coi
        )
        
    def to_json(self):
        return {
            "date": self.date,
            "time": self.time,
            "open": self.open,
            "high": self.high,
            "low": self.low,
            "close": self.close,
            "volume": self.volume,
            "coi": self.coi,
        }
   
class Order:
    def __init__(
        self,
        stg_entry_number: int,
        strategy_name: str,
        leg_id: str,
        entry_number: int,
        stop_loss_entry_number: int,
        take_profit_entry_number: int,
        contract: Contract,
        product_type: ENUMELEMENT,
        order_type: ENUMELEMENT,
        side: ENUMELEMENT,
        limit_price: float,
        trigger_price: float,
        quantity: int,
        creation_time: TimeStamp,
        index_price: float,
        reason: str = None,
    ):
        self.strategy_entry_number = stg_entry_number
        self.strategy_name = strategy_name
        self.leg_id = leg_id
        self.entry_number = entry_number
        self.stop_loss_entry_number = stop_loss_entry_number
        self.take_profit_entry_number = take_profit_entry_number
        self.contract = contract
        self.product_type = product_type
        self.order_type = order_type
        self.side = side
        self.limit_price = limit_price
        self.trigger_price = trigger_price
        self.quantity = quantity
        self.creation_time = creation_time
        self.status = ORDERSTATUS.CREATED
        self.index_price = index_price
        self.reason = reason

        self.trades: List[Trade] = []

        self.broker_order_id = None
        self.average_price = 0
        self.filled_quantity = 0
        self.max_profit = 0
        self.max_loss = 0
        self.daily_order_count = 0
        
        self.tag = F"TM-{random.randint(100000, 999999)}"

    def __repr__(self):
        return "<Order %s %s %s %s %s %s %s %s %s %s %s %s %s %s>" % (
            self.strategy_entry_number,
            self.leg_id,
            self.entry_number,
            self.stop_loss_entry_number,
            self.take_profit_entry_number,
            self.contract,
            self.product_type,
            self.order_type,
            self.side,
            self.limit_price,
            self.trigger_price,
            self.quantity,
            self.creation_time,
            self.tag
        )

    def __eq__(self, other):
        return (
            self.strategy_entry_number == other.strategy_entry_number
            and self.leg_id
            and self.entry_number == other.entry_number
            and self.stop_loss_entry_number == other.stop_loss_entry_number
            and self.take_profit_entry_number == other.take_profit_entry_number
            and self.contract == other.contract
            and self.product_type == other.product_type
            and self.order_type == other.order_type
            and self.side == other.side
            and self.limit_price == other.limit_price
            and self.trigger_price == other.trigger_price
            and self.quantity == other.quantity
            and self.creation_time == other.creation_time
            and self.tag == other.tag
        )
    
    def to_json(self):
        return {
            "strategy_entry_number": self.strategy_entry_number,
            "strategy_id": self.strategy_name,
            "leg_id": self.leg_id,
            "entry_number": self.entry_number,
            "stop_loss_entry_number": self.stop_loss_entry_number,
            "take_profit_entry_number": self.take_profit_entry_number,
            "date": str(self.creation_time.date),
            "time": str(self.creation_time.time),
            "symbol": str(self.contract.symbol),
            "expiry": str(self.contract.expiry_date),
            "strike": str(self.contract.strike_price),
            "instrument_type": str(self.contract.option_type),
            "side": self.side.value,
            "filled_quantity": self.filled_quantity,
            "average_price": self.average_price,
            "reason": self.reason,

            "contract": self.contract.to_json(),
            "product_type": self.product_type.name,
            "order_type": self.order_type.name,
            "limit_price": self.limit_price,
            "trigger_price": self.trigger_price,
            "quantity": self.quantity,
            "creation_time": self.creation_time.__dict__,
            "status": self.status.value,
            "broker_order_id": self.broker_order_id,
            "tag": self.tag
        }

    
class Trade:
    def __init__(
        self,
        contract: Contract,
        side: ENUMELEMENT,
        average_price: float,
        filled_quantity: int,
        timestamp: TimeStamp,
    ):
        self.contract = contract
        self.side = side
        self.average_price = average_price
        self.filled_quantity = filled_quantity
        self.timestamp = timestamp

    def __repr__(self):
        return "<Trade %s %s %s %s %s>" % (
            self.contract,
            self.side,
            self.average_price,
            self.filled_quantity,
            self.timestamp,
        )

    def __eq__(self, other):
        return (
            self.contract == other.contract
            and self.side == other.side
            and self.average_price == other.average_price
            and self.filled_quantity == other.filled_quantity
            and self.timestamp == other.timestamp
        )