from app.commons.modules import (
    uuid,
    datetime,
    timezone,
    List,
    norm,
    brentq,
    log,
    sqrt,
    exp
)
from app.commons.constants import (
    DATE_FORMAT,
    DATETIME_FORMAT,
    TIMEZONE,
    IV_LOWER_BOUND,
)
from app.commons.enums import NSEINDEX, SIDE, OPTIONTYPE

NORM_CDF = norm.cdf
NORM_PDF = norm.pdf

def sign(value: float):
    if value >= 0:
        return 1
    else:
        return -1

def get_strike_diff_for_index(index: str):
    if index in [
        NSEINDEX.NIFTY,
        NSEINDEX.FINNIFTY,
        NSEINDEX.CRUDEOILM,
        NSEINDEX.CRUDEOIL,
    ]:
        return 50
    elif index in [
        NSEINDEX.BANKNIFTY,
        NSEINDEX.BANKEX,
        NSEINDEX.SENSEX,
        NSEINDEX.GOLDM,
        NSEINDEX.GOLD,
    ]:
        return 100
    elif index == NSEINDEX.MIDCPNIFTY:
        return 25
    elif index in [NSEINDEX.NATGASMINI, NSEINDEX.NATURALGAS, NSEINDEX.COPPER]:
        return 5
    elif index in [NSEINDEX.SILVERM, NSEINDEX.SILVER]:
        return 250
    elif index == NSEINDEX.ZINC:
        return 2.5
    elif index in [NSEINDEX.QQQ, NSEINDEX.SPY]:
        return 1
    elif index == NSEINDEX.SPX:
        return 5

    raise Exception(f"Invalid index {index}")


def round_to(n, precision):
    correction = 0.5 if n >= 0 else -0.5
    return int(n / (precision) + correction) * precision


def today():
    return datetime.now(timezone(TIMEZONE)).date()


def now():
    return datetime.now()


def int_date(dt: datetime) -> int:
    return int(dt.strftime(DATE_FORMAT))


def int_time(dt: datetime) -> int:
    return (dt - datetime(dt.year, dt.month, dt.day)).seconds


def datetime_to_string(datetime: datetime):
    return datetime.strftime(DATETIME_FORMAT)


def generate_id():
    return str(uuid.uuid4())


def reverse_side(side: SIDE):
    if side == SIDE.BUY:
        return SIDE.SELL
    elif side == SIDE.SELL:
        return SIDE.BUY
    else:
        raise Exception(f"Invalid side {side}")


def date_1980():
    return datetime(1980, 1, 1)


def rupee_to_paise(rs: float):
    return rs * 100


def paise_to_rupee(paise: float):
    return paise / 100


def impl_vol_with_brent(option_type: str, ltp: float, fut_price: float, strike: float, t):
    try:
        ImplVol = brentq(
            lambda sigma: ltp - (bs_call_pricing(sigma, fut_price, strike, t) if option_type == OPTIONTYPE.CALL else bs_put_pricing(sigma, fut_price, strike, t)) ,
            0,
            10,
        )
        return (
            ImplVol if ImplVol > IV_LOWER_BOUND else IV_LOWER_BOUND  # noqa: E501
        )  # noqa: E501
    except Exception as ex:
        return IV_LOWER_BOUND


def bs_call_pricing(sigma: float, fut_price: float, strike: float, t):
    return NORM_CDF(bs_d1(sigma, fut_price, strike, t)) * fut_price - NORM_CDF(bs_d2(sigma, fut_price, strike, t)) * strike * exp(-0 * t)


def bs_put_pricing(sigma: float, fut_price: float, strike: float, t):
    return NORM_CDF(-bs_d2(sigma, fut_price, strike, t)) * strike * exp(-0 * t) - NORM_CDF(-bs_d1(sigma, fut_price, strike, t)) * fut_price


def bs_d1(sigma: float, fut_price: float, strike: float, t):
    if sigma > IV_LOWER_BOUND:
        return (log(fut_price / strike) + (0 + sigma**2 / 2) * t) / (sigma * sqrt(t))
    return float('inf') if fut_price > strike else -float('inf')


def bs_d2(sigma: float, fut_price: float, strike: float, t):
    return bs_d1(sigma, fut_price, strike, t) - (sigma * sqrt(t))


def delta_call(sigma: float, fut_price: float, strike: float, t):
    return NORM_CDF(bs_d1(sigma, fut_price, strike, t))


def get_deltas(
    fut_price: float,
    ltp: float,
    strike_price: float,
    option_type: str,
    day_to_expiry: int
):
    fut_price /= 100
    ltp /= 100
    iv = round(impl_vol_with_brent(option_type, ltp, fut_price, strike_price, day_to_expiry), 6)
    call_delta = round(delta_call(iv, fut_price, strike_price, day_to_expiry), 2)
    put_delta = round(call_delta - 1, 2)
    return call_delta, put_delta


class MessageThrottler:

    def __init__(self, max_events=10, interval=1):
        """Throttler class - Implements restriction on number of events per time interval
        The unit for interval is seconds, so the default values become 10 events per 1 second
        """

        self.event_queue: List = list()
        self.max_events = max_events
        self.interval = interval

    def push(self, event) -> bool:
        if len(self.event_queue) < self.max_events:
            self.event_queue.append(event)
            return True
        else:
            assert len(self.event_queue) == self.max_events
            first_item = self.event_queue[0]
            elapsed_time = event - first_item
            if elapsed_time >= self.interval:
                self.event_queue.pop(0)
                self.event_queue.append(event)
                return True
            else:
                return False

    def check_only(self, event) -> bool:
        if len(self.event_queue) < self.max_events:
            return True
        else:
            assert len(self.event_queue) == self.max_events
            first_item = self.event_queue[0]
            curr_time = event
            elapsed_time = curr_time - first_item
            if elapsed_time >= self.interval:
                return True
            else:
                return False

    # Only call this after calling check_only
    def force_push(self, event) -> None:
        self.event_queue.append(event)
        if len(self.event_queue) > self.max_events:
            self.event_queue.pop(0)
        assert len(self.event_queue) <= self.max_events
