from datetime import datetime as datetime
from datetime import date as date
from datetime import time as time
from datetime import timezone as timezone
from datetime import timedelta as timedelta
from decimal import Decimal as Decimal
from copy import deepcopy as deepcopy
import requests as requests
import socketio as socketio
import os as os
import sys as sys
import re as re
import json as json
import numpy as numpy  # Added numpy import
import threading as threading
import uuid as uuid
import multiprocessing as multiprocessing
from multiprocessing.managers import SyncManager as SyncManager
from time import sleep as sleep
import math as math
from scipy.stats import norm as norm
import pandas_ta as ta
import pandas as pd
import pandas_ta as ta
from scipy.optimize import brentq as brentq
import scipy as scipy
import torch
from torch import exp as exp, log as log, sqrt as sqrt

import logging as logging

import uuid as uuid
import random as random

import mysql.connector as mysql

from typing import List as List
from typing import Dict as Dict
from typing import Set as Set
from typing import Tuple as Tuple

# Configure PyTorch to use GPU if available
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
torch.set_default_device(device)
