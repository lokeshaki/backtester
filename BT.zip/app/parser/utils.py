from app.commons.modules import Dict
from app.parser.models import StrikeSelection, StopLoss, TakeProfit, ProfitMove, StopLossMove, TrailingStopLoss, TrailingStopLoss, WaitIn, Reentry, ReentryParams, ExitPriceConfig, Hedge, Box, BoxDiff, TakeProfitParams, StopLossParams, Rsi, LockAndTrail, VwapLeg, VwapStrategy, Leg, Strategy, EmaIndicator, RsiIndicator, StIndicator, VwapIndicator, VolEmaIndicator, VolSmaIndicator, ORB, Portfolio, OICheck
from app.commons.enums import *
from app.commons.constants import MAX_INT
from app.config import Config

class Stack:
    def __init__(self):
        self.items = []

    def push(self, item):
        self.items.append(item)

    def pop(self):
        if not self.is_empty():
            return self.items.pop()

    def is_empty(self):
        return len(self.items) == 0

    def peek(self):
        if not self.is_empty():
            return self.items[-1]
        

def parse_indicators(indicators: Dict):
    stack = []
    expression = []
    max_len = 1
    for key in indicators:
        if "in" in key:
            indicator_json = indicators[key]
            name = indicator_json["name"]
            indicator = None
            if name == "vwap":
                indicator = VwapIndicator(indicator_json["condition"])
            elif name == "ema":
                emi_len = indicator_json["length"]
                indicator = EmaIndicator(emi_len, indicator_json["condition"])
                if emi_len > max_len:
                    max_len = emi_len
            elif name == "rsi":
                rsi_len = indicator_json["length"]
                indicator = RsiIndicator(rsi_len, indicator_json["condition"])
                if rsi_len > max_len:
                    max_len = rsi_len
            elif name == "st":
                st_len = indicator_json["length"]
                indicator = StIndicator(st_len, indicator_json["multiplier"], indicator_json["condition"])
                if st_len > max_len:
                    max_len = st_len
            elif name == "vol_ema":
                st_len = indicator_json["length"]
                indicator = VolEmaIndicator(st_len, indicator_json["condition"])
                if st_len > max_len:
                    max_len = st_len
            elif name == "vol_sma":
                st_len = indicator_json["length"]
                indicator = VolSmaIndicator(st_len, indicator_json["condition"])
                if st_len > max_len:
                    max_len = st_len
                
            expression.append(indicator)
            if len(stack) != 0:
                operator = stack.pop(-1)
                expression.append(operator)
        elif "op" in key:
            stack.append(indicators[key])
            
    return expression, max_len

def parse_rsi_json(rsi_json: Dict) -> Rsi:
    if rsi_json is None:
        return None
    return Rsi(
        rsi_json["length"],
        rsi_json["interval"],
        rsi_json["overbought_level"],
        rsi_json["oversold_level"],
        eval(str(rsi_json["direction"])))
    

def parse_strike_selection_json(strike_selection_json: Dict) -> StrikeSelection:
    return StrikeSelection(
        eval(str(strike_selection_json["type"])),
        strike_selection_json["value"],
    )

def parse_stop_loss_params_json(stop_loss_params_json: Dict) -> StopLoss:
    return StopLossParams(
        stop_loss_params_json["check_frequency"]
    )

def parse_stop_loss_json(stop_loss_json: Dict) -> StopLoss:
    if stop_loss_json is None:
        return StopLoss(NUMBERTYPE.POINT, MAX_INT, StopLossParams(0))
    value = eval(str(stop_loss_json["value"]))
    if value == 0:
        value = MAX_INT
    return StopLoss(
        eval(str(stop_loss_json["type"])), value,
        parse_stop_loss_params_json(stop_loss_json["params"])
    )

def parse_take_profit_params_json(take_profit_params_json: Dict) -> TakeProfit:
    return TakeProfitParams(
        take_profit_params_json["check_frequency"]
    )

def parse_take_profit_json(take_profit_json: Dict) -> TakeProfit:
    if take_profit_json is None:
        return TakeProfit(NUMBERTYPE.POINT, MAX_INT, TakeProfitParams(0))
    value = eval(str(take_profit_json["value"]))
    if value == 0:
        value = MAX_INT
    return TakeProfit(
        eval(str(take_profit_json["type"])), value, parse_take_profit_params_json(take_profit_json["params"])
    )


def parse_profit_move_json(profit_move_json: Dict) -> ProfitMove:
    value = eval(str(profit_move_json["value"]))
    if value == 0:
        value = MAX_INT
    return ProfitMove(
        eval(str(profit_move_json["type"])), value
    )


def parse_stop_loss_move_json(stop_loss_move_json: Dict) -> StopLossMove:
    return StopLossMove(
        eval(str(stop_loss_move_json["type"])), eval(str(stop_loss_move_json["value"]))
    )


def parse_trailing_stop_loss_json(trailing_stop_loss_json: Dict) -> TrailingStopLoss:
    return TrailingStopLoss(
        parse_profit_move_json(trailing_stop_loss_json["profit_move"]),
        parse_stop_loss_move_json(trailing_stop_loss_json["stop_loss_move"])
    )
    
def parse_waitin_json(waitin_json: Dict) -> WaitIn:
    value = eval(str(waitin_json["value"]))
    return WaitIn(
        eval(str(waitin_json["type"])), value,
        eval(waitin_json.get("should_trail", "None"))
    )
    
def parse_reentry_value_json(reentry_params_json: Dict) -> ReentryParams:
    return ReentryParams(
        eval(str(reentry_params_json["count"])), eval(str(reentry_params_json["cutoff_time"])),
        reentry_params_json["check_frequency"], reentry_params_json["cool_off_time"]
    )
    
def parse_reentry_json(reentry_json: Dict) -> Reentry:
    if reentry_json is None:
        return Reentry(REENTRYTYPE.AS_ORIGINAL, ReentryParams(0, 0, Config.BT_FREQUENCY, 0))
    return Reentry(
        eval(str(reentry_json["type"])), parse_reentry_value_json(reentry_json["value"])
    )
    
def parse_lock_and_trail(lock_and_trail_json: Dict) -> LockAndTrail:
    if lock_and_trail_json is None:
        return None
    else:
        return LockAndTrail(eval(lock_and_trail_json.get("Type", "LOCKTYPE.REGULAR")), lock_and_trail_json.get("lock_time", 0), lock=lock_and_trail_json["lock"], trail=lock_and_trail_json["trail"], next_check_time=lock_and_trail_json.get("next_check_time", MAX_INT), final_trail_time=lock_and_trail_json.get("final_trail_time", MAX_INT), final_trail=lock_and_trail_json.get("final_trail", MAX_INT))
    
    
def parse_orb(orb_json: Dict):
    if orb_json is None:
        return None
    else:
        return ORB(orb_json["wait_start"], orb_json["wait_till"], eval(orb_json["entry_on"]), orb_json.get("new_selection"))


def parse_oi_check(oi_check_json: Dict):
    if oi_check_json is None:
        return None
    else:
        return OICheck(oi_check_json["check_interval"], oi_check_json["value"], eval(oi_check_json["recontracterized"]))
def parse_hedge_json(leg_id: str, hedge_json: Dict) -> Hedge:
    if hedge_json is None:
        return None
    return Hedge(
        leg_id + "_hedge",
        eval(hedge_json["option_type"]),
        eval(hedge_json["side"]),
        eval(hedge_json["expiry_type"]),
        parse_strike_selection_json(hedge_json["strike_selection"]),
        eval(hedge_json["next_expiry_select"])
    )
    
def parse_leg_json(leg_json: Dict) -> Leg:
    return Leg(
        str(leg_json["id"]),
        eval(leg_json["option_type"]),
        eval(leg_json["side"]),
        eval(leg_json["expiry_type"]),
        parse_strike_selection_json(leg_json["strike_selection"]),
        parse_stop_loss_json(leg_json["stop_loss"]),
        parse_take_profit_json(leg_json["take_profit"]),
        parse_trailing_stop_loss_json(leg_json["trailing_stop_loss"]),
        parse_waitin_json(leg_json["waitin"]),
        leg_json["quantity"],
        parse_reentry_json(leg_json["take_profit_reentry"]),
        parse_reentry_json(leg_json["stop_loss_reentry"]),
        parse_reentry_json(leg_json["triggered_reentry"]),
        leg_json["multiplier"],
        eval(leg_json["recost_cascade"]),
        eval(leg_json["recost_entry_on_crossover"]),
        parse_orb(leg_json.get("orb")),
        parse_oi_check(leg_json.get("oi_check")),
        parse_hedge_json(str(leg_json["id"]), leg_json.get("hedge")),
        eval(leg_json["hedge_pnl_effect"]),
        eval(leg_json["next_expiry_select"]),
        eval(leg_json.get("is_idle")),
        leg_json.get("on_entry"),
        leg_json.get("on_exit"),
    )

def parse_vwap_leg_json(leg_json: Dict) -> VwapLeg:
    return VwapLeg(
        str(leg_json["id"]),
        eval(leg_json["option_type"]),
        eval(leg_json["side"]),
        eval(leg_json["expiry_type"]),
        parse_strike_selection_json(leg_json["strike_selection"]),
        parse_stop_loss_json(leg_json["stop_loss"]),
        parse_take_profit_json(leg_json["take_profit"]),
        parse_trailing_stop_loss_json(leg_json["trailing_stop_loss"]),
        leg_json["quantity"],
        leg_json["multiplier"],
        parse_hedge_json(str(leg_json["id"]), leg_json.get("hedge")),
        eval(leg_json["hedge_pnl_effect"]),
        eval(leg_json["refresh_contract_on_reentry"]),
        eval(leg_json["next_expiry_select"])
    )

def parse_exit_price_json(exit_price_json: Dict) -> ExitPriceConfig:
    return ExitPriceConfig(
        exit_price_json["take_profit_based_on"],
        exit_price_json["stop_loss_based_on"],
        exit_price_json["trade_file_exit_price_on_take_profit"],
        exit_price_json["trade_file_exit_price_on_stop_loss"],
        exit_price_json["trade_file_exit_price_on_trigger"],
    )
    
def parse_box_diff_json(box_diff_json: Dict) -> BoxDiff:
    return BoxDiff(
        eval(box_diff_json["type"]),
        box_diff_json["value"],
    )
    
    
def parse_box_json(box_json: Dict) -> Box:
    if box_json is None:
        return None
    return Box(
        parse_box_diff_json(box_json["diff"]),
        int(box_json["duration"],),
        eval(box_json["force_entry"]),
        eval(box_json["force_entry_type"]),
        eval(box_json["contractrize_only_once"]),
    )
    
    
def parse_vwap_strategy_json(strategy_json: Dict) -> VwapStrategy:
    entry_indicators, max_len1 = parse_indicators(strategy_json.get("entry_indicators"))
    exit_indicators, max_len2 = parse_indicators(strategy_json.get("exit_indicators"))
    max_len = max([ max_len1, max_len2])
    return VwapStrategy(
        strategy_json["name"],
        str(strategy_json["evaluator"]),
        eval(str(strategy_json["index"])),
        eval(str(strategy_json["underlying"])) if Config.BT_FREQUENCY == 60 else eval("UNDERLYINGTYPE.FUTURE"),
        strategy_json.get("entry_date", None),
        strategy_json["entry_time"],
        strategy_json.get("exit_date", None),
        strategy_json["exit_time"],
        parse_stop_loss_json(strategy_json["stop_loss"]),
        parse_take_profit_json(strategy_json["take_profit"]),
        parse_reentry_json(strategy_json.get("take_profit_reentry")),
        parse_reentry_json(strategy_json.get("stop_loss_reentry")),
        parse_reentry_json(strategy_json.get("indicator_based_reentry")),
        strategy_json["place_order_after"],
        parse_exit_price_json(strategy_json["exit_price"]),
        str(strategy_json["pnl_calculation_from"]),
        entry_indicators,
        exit_indicators,
        strategy_json.get("checking_interval"),
        max_len,
        [parse_vwap_leg_json(leg_json) for leg_json in strategy_json["legs"]],
        strategy_json.get("dte", None),
        parse_lock_and_trail(strategy_json.get("lock_and_trail")),
        parse_trailing_stop_loss_json(strategy_json.get("trailing_stop_loss")),
        int(strategy_json.get("index_base_price")),
        int(strategy_json.get("multiplier")),
        tv_expiry_day_exit_time=strategy_json.get("tv_expiry_day_exit_time"),
        indicator_candle_based_on=strategy_json.get("indicator_candle_based_on"),
        rr = eval(strategy_json.get("rr", "(-9999999, 9999999)")),
        stoploss_buffer=strategy_json.get("stoploss_buffer", 0),
        entry_buffer=strategy_json.get("entry_buffer", 0),
        acceptable_weekdays=strategy_json.get("acceptable_weekdays",[])
    )


def parse_strategy_json(strategy_json: Dict) -> Strategy:
    return Strategy(
        strategy_json["name"],
        str(strategy_json["evaluator"]),
        eval(str(strategy_json["index"])),
        eval(str(strategy_json["underlying"])) if Config.BT_FREQUENCY == 60 else eval("UNDERLYINGTYPE.FUTURE"),
        strategy_json.get("entry_date", None),
        strategy_json["entry_time"],
        strategy_json.get("exit_date", None),
        strategy_json["exit_time"],
        parse_stop_loss_json(strategy_json["stop_loss"]),
        parse_take_profit_json(strategy_json["take_profit"]),
        parse_stop_loss_json(strategy_json.get("box_stop_loss")),
        parse_take_profit_json(strategy_json.get("box_take_profit")),
        parse_reentry_json(strategy_json.get("take_profit_reentry")),
        parse_reentry_json(strategy_json.get("stop_loss_reentry")),
        parse_reentry_json(strategy_json.get("box_stop_loss_reentry")),
        parse_reentry_json(strategy_json.get("box_take_profit_reentry")),
        parse_reentry_json(strategy_json.get("squareoff_reentry")),
        parse_reentry_json(strategy_json.get("rsi_reentry")),
        strategy_json["place_order_after"],
        parse_exit_price_json(strategy_json["exit_price"]),
        str(strategy_json["pnl_calculation_from"]),
        parse_box_json(strategy_json.get("box")),
        parse_rsi_json(strategy_json.get("entry_rsi")),
        parse_rsi_json(strategy_json.get("exit_rsi")),
        [parse_leg_json(leg_json) for leg_json in strategy_json["legs"]],
        eval(strategy_json.get("squareoff_all_legs", "False")),
        strategy_json.get("dte", None),
        parse_lock_and_trail(strategy_json.get("lock_and_trail")),
        parse_trailing_stop_loss_json(strategy_json.get("trailing_stop_loss")),
        eval(strategy_json.get("move_sl_to_cost", "False")),
        int(strategy_json.get("index_base_price")),
        int(strategy_json.get("multiplier")),
        strategy_json.get("tv_expiry_day_exit_time"),
        strategy_json.get("acceptable_weekdays",[]),
        strategy_json.get("concurrent_legs", MAX_INT),
    )
        

def parse_portfolio_json(portfolio_json: Dict) -> Portfolio:
    strategies = []
    for strategy_json in portfolio_json["strategies"]:
        type = strategy_json["evaluator"]
        if type in ["Vwap", "Heikin", "five_ema"]:
            if (Config.BT_FREQUENCY != 60):
                continue
            strategy = parse_vwap_strategy_json(strategy_json)
        else:
            strategy = parse_strategy_json(strategy_json)
        strategies.append(strategy)
    return Portfolio(
        portfolio_json["id"],
        strategies,
        parse_stop_loss_json(portfolio_json["stop_loss"]),
        parse_take_profit_json(portfolio_json["take_profit"]),
        parse_lock_and_trail(portfolio_json.get("lock_and_trail")),
        parse_trailing_stop_loss_json(portfolio_json.get("trailing_stop_loss")),
    )