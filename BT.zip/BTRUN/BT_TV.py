############################################################################## importing libraries
from datetime import datetime
from Util import Util
import pandas as pd
import traceback
import logging
import pyttsx3
import config
import sys
import os

pd.set_option('mode.chained_assignment', None)

STRATEGYWISE_RESULTS = True # if True, strategy wise transaction and result sheet will be generated


if __name__ == "__main__":

    logging.info(f"Started ({config.VERSION_NO['TV']})")
    filesToCopy = []

    try:

        Util.runNeccesaryFunctionsBeforeStartingBT()

        folderPath = "Trades"
        os.makedirs(folderPath, exist_ok=True)

        filepath = os.path.join(config.INPUT_FILE_FOLDER, config.TV_FILE_PATH)    
        if not os.path.exists(filepath):
            logging.info("Unable to find input file.")
            sys.exit()
        
        tvSettingDf = pd.read_excel(filepath, sheet_name="Setting")
        for __boolCol in ['IntradaySqOffApplicable', 'Enabled', 'DoRollover', 'TvExitApplicable']:
            tvSettingDf[__boolCol] = tvSettingDf[__boolCol].str.upper().str.strip() == "YES"
        tvSettingDf = tvSettingDf[tvSettingDf['Enabled']]
        if tvSettingDf.empty:
            logging.info("No valid setting found.")
            sys.exit()
        
        for __emptycol in ['LongPortfolioFilePath', 'ShortPortfolioFilePath', 'ManualPortfolioFilePath']:
            tvSettingDf[__emptycol] = tvSettingDf[__emptycol].fillna("")
        
        mainParaColumnName = tvSettingDf.columns.to_list()
            
        for __, tvsettingdict in tvSettingDf.iterrows():

            if not os.path.exists(tvsettingdict['SignalFilePath']):
                logging.info(f"TV signal file not exists. File location: {tvsettingdict['SignalFilePath']}")
                continue

            btResultFile = datetime.now().strftime("%d%m%Y %H%M%S") + ".xlsx"
            btResultFile = os.path.join(folderPath, f"{tvsettingdict['Name']} {btResultFile}")

            __reqInfo = Util.writeParametersToTvOutputFile(tvMainPara=tvsettingdict, mainParaColumnName=mainParaColumnName, outputExcelFilePath=btResultFile, tvSignalsDf=pd.read_excel(tvsettingdict['SignalFilePath'], sheet_name="List of trades"))
            __indexRunning = set([__jj for __portfoliotype in __reqInfo for __jj in __reqInfo[__portfoliotype]['index']])

            if not tvsettingdict['TvExitApplicable']:

                if tvsettingdict['DoRollover']:
                    logging.error("Cann't run backtest when TvExitApplicable is no and DoRollover is yes and.")
                    continue

                elif not tvsettingdict['IntradaySqOffApplicable']:
                    logging.error("Cann't run backtest when TvExitApplicable is no and IntradaySqOffApplicable is no.")
                    continue

                elif tvsettingdict['ManualTradeEntryTime'] != 0:
                    logging.error("Cann't run backtest when TvExitApplicable is no and ManualTradeEntryTime is given.")
                    continue

            if (tvsettingdict['FirstTradeEntryTime'] != 0) and (tvsettingdict['ManualTradeEntryTime'] != 0):
                logging.error("Cann't run backtest when both FirstTradeEntryTime & ManualTradeEntryTime is required.")
                continue

            if tvsettingdict['DoRollover'] and (len(__indexRunning) != 1):
                logging.error(f"Cann't run backtest when DoRollover is yes and multiple indice(s) are given i.e. {__indexRunning}.")
                continue

            if tvsettingdict['DoRollover'] and tvsettingdict['IntradaySqOffApplicable']:
                logging.error("Cann't run backtest when both DoRollover and IntradaySqOffApplicable are yes. Please re-check parameters again.")
                continue
            
            tvSignalDict = Util.getTVIntraSignals(
                rolloverIndex=list(__indexRunning)[0] if tvsettingdict['DoRollover'] else "",  uPara=tvsettingdict, 
                signalDf=Util.getTVSignalsInDf(signalfilepath=tvsettingdict['SignalFilePath'], signals=[])
            )
            if len(tvSignalDict) == 0:
                continue

            transactionDict = {}
            dailyMaxProfitLossDict = {"strategy_profits": {}, "strategy_losses": {}}

            btstart = datetime.now() 
            logging.info(f"{btstart}, Backtester Started")

            for __signalType in tvSignalDict:
                for __signal in tvSignalDict[__signalType]:

                    excelFilePath = tvsettingdict[f'{__signalType.title()}PortfolioFilePath']
                    if excelFilePath == "":
                        continue
                    
                    portfolioForBt, __ = Util.getPortfolioJson(excelFilePath=excelFilePath, tvSignalInfoo=__signal, strategyNamePrefix=__signalType)

                    for __pNo in portfolioForBt:

                        __btResp = Util.getBacktestResults(btPara=portfolioForBt[__pNo])
                        if (not __btResp) or (not __btResp['strategies']['orders']):
                            continue

                        if __signalType not in transactionDict:
                            transactionDict[__signalType] = {}

                        if __pNo not in transactionDict[__signalType]:
                            transactionDict[__signalType][__pNo] = []
                        
                        transactionDict[__signalType][__pNo] += __btResp['strategies']['orders']

                        for __tradingdate in __btResp['strategies']['strategy_profits']:
                            
                            if __tradingdate not in dailyMaxProfitLossDict['strategy_profits']:
                                dailyMaxProfitLossDict['strategy_profits'][__tradingdate] = {}
                            
                            if __tradingdate not in dailyMaxProfitLossDict['strategy_losses']:
                                dailyMaxProfitLossDict['strategy_losses'][__tradingdate] = {}

                            for __tradingtime in __btResp['strategies']['strategy_profits'][__tradingdate]:

                                if __tradingtime not in dailyMaxProfitLossDict['strategy_profits'][__tradingdate]:
                                    dailyMaxProfitLossDict['strategy_profits'][__tradingdate][__tradingtime] = __btResp['strategies']['strategy_profits'][__tradingdate][__tradingtime]
                                else:
                                    dailyMaxProfitLossDict['strategy_profits'][__tradingdate][__tradingtime] += __btResp['strategies']['strategy_profits'][__tradingdate][__tradingtime]
                                
                            for __tradingtime in __btResp['strategies']['strategy_losses'][__tradingdate]:
                                
                                if __tradingtime not in dailyMaxProfitLossDict['strategy_losses'][__tradingdate]:
                                    dailyMaxProfitLossDict['strategy_losses'][__tradingdate][__tradingtime] = __btResp['strategies']['strategy_losses'][__tradingdate][__tradingtime]
                                else:
                                    dailyMaxProfitLossDict['strategy_losses'][__tradingdate][__tradingtime] += __btResp['strategies']['strategy_losses'][__tradingdate][__tradingtime]

            portfolioPnLDf, finalStatsDf = pd.DataFrame(), pd.DataFrame()
            stgywiseTransactionDf, stgyDayWiseStats, stgyMonthWiseStats, stgyMarginPercentageWiseStats, marginReqByEachStgy = {"portfolio": pd.DataFrame()}, {}, {}, {}, {}
            
            for __signalType in transactionDict:
                for __pNoo in transactionDict[__signalType]:
                    
                    parsedOrderDf, stgyMarginn, __ = Util.parseBacktestingResponse(
                        btResponse={"orders": transactionDict[__signalType][__pNoo], "strategy_profits": {}, "strategy_losses": {}}, 
                        slippagePercent=portfolioForBt[__pNoo]['slippage_percent']
                    )
                    if parsedOrderDf.empty:
                        continue

                    marginReqByEachStgy.update(stgyMarginn)

                    parsedOrderDf = parsedOrderDf.sort_values(by=['entry_datetime'])
                    parsedOrderDf = parsedOrderDf.reset_index(drop=True)

                    for strategyName in sorted(parsedOrderDf['strategy'].unique()):

                        strategyOrderDf = parsedOrderDf[parsedOrderDf['strategy'] == strategyName]

                        stgyPnL = strategyOrderDf[['entry_datetime', 'netPnlAfterExpenses']].copy()
                        stgyPnL['entry_datetime'] = stgyPnL['entry_datetime'].dt.date
                        stgyPnL = stgyPnL.groupby(by=['entry_datetime'], as_index=False).sum()
                        stgyPnL = stgyPnL.rename(columns={"entry_datetime": "entryDate", 'netPnlAfterExpenses': "bookedPnL"})

                        portfolioPnLDf = pd.concat([stgyPnL, portfolioPnLDf])
                        portfolioPnLDf = portfolioPnLDf.reset_index(drop=True)

                        statsdf = Util.getBacktestStats(tradesDf=stgyPnL, initialCapital=marginReqByEachStgy.get(strategyName, 0))
                        statsdf = pd.DataFrame.from_dict(statsdf, orient="index").reset_index().rename(columns={"index": "Particulars", 0: strategyName})

                        if finalStatsDf.empty:
                            finalStatsDf = statsdf.copy()
                        else:
                            finalStatsDf = pd.merge(left=finalStatsDf, right=statsdf, left_on="Particulars", right_on="Particulars")
                        
                        stgywiseTransactionDf[strategyName] = strategyOrderDf.copy()
                        
                        oldTrans = stgywiseTransactionDf['portfolio'].copy()
                        oldTrans = pd.concat([oldTrans, strategyOrderDf])
                        oldTrans = oldTrans.reset_index(drop=True)

                        stgywiseTransactionDf['portfolio'] = oldTrans.copy()

                        if STRATEGYWISE_RESULTS:
                            stgyDayWiseStats[strategyName] = Util.getDayWiseStats(tradesDf=stgyPnL)
                            stgyMonthWiseStats[strategyName] = Util.getMonthWiseStats(tradesDf=stgyPnL)

                            marginn = marginReqByEachStgy.get(strategyName, 0)

                            marginWiseDf = stgyPnL[["entryDate", "bookedPnL"]]
                            if marginn != 0:
                                marginWiseDf['bookedPnL'] = marginWiseDf['bookedPnL'] / marginn
                                marginWiseDf['bookedPnL'] *= 100
                            else:
                                marginWiseDf['bookedPnL'] = 0

                            stgyMarginPercentageWiseStats[strategyName] = Util.getMonthWiseStats(tradesDf=marginWiseDf)

            ############################################################################################################################################ for portfolio stats
            if not portfolioPnLDf.empty:

                portfolioPnLDf = portfolioPnLDf.groupby(by=['entryDate'], as_index=False).sum()

                statsdf = Util.getBacktestStats(tradesDf=portfolioPnLDf, initialCapital=sum(list(marginReqByEachStgy.values())))
                statsdf = pd.DataFrame.from_dict(statsdf, orient="index").reset_index().rename(columns={"index": "Particulars", 0: "Combined"})

                portfolioPl = stgywiseTransactionDf['portfolio'][['entry_datetime', 'netPnlAfterExpenses']].copy()
                portfolioPl['entry_datetime'] = portfolioPl['entry_datetime'].dt.date
                portfolioPl = portfolioPl.groupby(by=['entry_datetime'], as_index=False).sum()
                portfolioPl = portfolioPl.rename(columns={"entry_datetime": "entryDate", 'netPnlAfterExpenses': "bookedPnL"})

                stgyDayWiseStats['portfolio'] = Util.getDayWiseStats(tradesDf=portfolioPl)
                stgyMonthWiseStats['portfolio'] = Util.getMonthWiseStats(tradesDf=portfolioPl)

                marginn = sum(list(marginReqByEachStgy.values()))
                marginWiseDf = portfolioPl[["entryDate", "bookedPnL"]]
                if marginn != 0:
                    marginWiseDf['bookedPnL'] = marginWiseDf['bookedPnL'] / marginn
                    marginWiseDf['bookedPnL'] *= 100
                else:
                    marginWiseDf['bookedPnL'] = 0

                stgyMarginPercentageWiseStats['portfolio'] = Util.getMonthWiseStats(tradesDf=marginWiseDf)

            if not finalStatsDf.empty:
                finalStatsDf = pd.merge(left=statsdf, right=finalStatsDf, left_on="Particulars", right_on="Particulars")
                        
            dailyMaxProfitLossDf = Util.convertTickPnlDictToDaywiseDf(toConvert=dailyMaxProfitLossDict)
            Util.prepareOutputFile(
                btResultFile=btResultFile, btStatsTableData=finalStatsDf, stgywiseTransactionDf=stgywiseTransactionDf, stgyDayWiseStats=stgyDayWiseStats, 
                stgyMonthWiseStats=stgyMonthWiseStats, stgyMarginPercentageWiseStats=stgyMarginPercentageWiseStats, onlyStgyResults=STRATEGYWISE_RESULTS, 
                excelFileExists=True, dailyMaxProfitLossDf=dailyMaxProfitLossDf
            )

            filesToCopy.append(btResultFile)

            btend = datetime.now()
            duro = round((btend-btstart).total_seconds(), 2)
            
            logging.info(f"Completed backtesting : Overall duration {duro} seconds")
        
    except Exception:
        logging.error(traceback.format_exc())
    
    logging.info("Started merging code.")
    Util.copyFilesIntoMergeFolder(filePath=filesToCopy)
    logging.info("Process completed of merging code.")
    
    try:
        TEXT_TO_SPEECH_OBJ = pyttsx3.init()
        TEXT_TO_SPEECH_OBJ.setProperty('rate', 200)
        TEXT_TO_SPEECH_OBJ.runAndWait()
        TEXT_TO_SPEECH_OBJ.say("TV Backtest completed")
        TEXT_TO_SPEECH_OBJ.runAndWait()
    except Exception:
        logging.error(traceback.format_exc())

    logging.info("Stopped")