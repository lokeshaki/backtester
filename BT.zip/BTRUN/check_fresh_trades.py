import os
import datetime

print("🔍 CHECKING TRADE FILES")
print("=" * 50)

if os.path.exists('Trades'):
    files = os.listdir('Trades')
    xlsx_files = [f for f in files if f.endswith('.xlsx')]
    
    print(f"📁 Total files: {len(files)}")
    print(f"📊 Excel files: {len(xlsx_files)}")
    
    if xlsx_files:
        print("\n📋 Trade files:")
        for f in xlsx_files:
            file_path = f'Trades/{f}'
            mod_time = datetime.datetime.fromtimestamp(os.path.getmtime(file_path))
            size = os.path.getsize(file_path)
            print(f"  📄 {f}")
            print(f"      ⏰ Modified: {mod_time}")
            print(f"      📏 Size: {size} bytes")
            print()
    else:
        print("❌ No Excel files found in Trades directory")
else:
    print("❌ Trades directory does not exist")

print("\n🎯 RECOMMENDATION:")
print("If no recent files, try running the backtest again or check logs for errors.") 