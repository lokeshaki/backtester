############################################################################## importing libraries
from datetime import datetime
from Util import Util
import pandas as pd
import traceback
import logging
import pyttsx3
import config
import json
import os

# Configure logging to display to console
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),  # This ensures output goes to console
        logging.FileHandler('Logs/portfolio_backtest.log')  # Also log to file
    ]
)

pd.set_option('mode.chained_assignment', None)

STRATEGYWISE_RESULTS = True # if True, strategy wise transaction and result sheet will be generated

def print_progress(message):
    """Print progress message to both console and log"""
    print(f"[{datetime.now().strftime('%H:%M:%S')}] {message}")
    logging.info(message)

if __name__ == "__main__":

    print("="*80)
    print("🚀 PORTFOLIO BACKTEST STARTING")
    print("="*80)
    
    logging.info(f"Started ({config.VERSION_NO['PORTFOLIO']})")
    print_progress(f"Portfolio Backtest Version: {config.VERSION_NO['PORTFOLIO']}")
    
    filesToCopy = []

    try:
        print_progress("🔧 Running necessary setup functions...")
        Util.runNeccesaryFunctionsBeforeStartingBT()

        folderPath = "Trades"
        os.makedirs(folderPath, exist_ok=True)
        print_progress(f"📁 Created trades folder: {folderPath}")
        
        print_progress("📊 Loading portfolio configuration...")
        portfolioForBt, portfolioSettingDf = Util.getPortfolioJson(excelFilePath=os.path.join(config.INPUT_FILE_FOLDER, config.PORTFOLIO_FILE_PATH))
        print_progress(f"✅ Loaded {len(portfolioForBt)} portfolio(s) for backtesting")
        
        for pNo in portfolioForBt:
            print(f"\n{'='*60}")
            print(f"📈 PROCESSING PORTFOLIO {pNo}: {portfolioForBt[pNo]['portfolio']['name']}")
            print(f"{'='*60}")

            btstart = datetime.now() 
            logging.info(f"{btstart}, Backtester Started")
            print_progress(f"⏰ Backtest started at: {btstart.strftime('%Y-%m-%d %H:%M:%S')}")

            btResultFile = datetime.now().strftime("%d%m%Y %H%M%S") + ".xlsx"
            btResultFile = os.path.join(folderPath, f"{portfolioForBt[pNo]['portfolio']['name']} {btResultFile}")
            print_progress(f"📄 Output file: {btResultFile}")

            print_progress("💾 Saving portfolio parameters to btpara.json...")
            with open("btpara.json", "+w") as ff:
                ff.write(json.dumps(portfolioForBt[pNo], indent=4))
                
            print_progress("🌐 Sending backtest request to backend...")
            print("   Backend URL:", config.BT_URII['tick'] if portfolioForBt[pNo]['istickbt'] else config.BT_URII['minute'])
            
            btResp = Util.getBacktestResults(btPara=portfolioForBt[pNo])
            
            if len(btResp) == 0:
                print_progress("❌ No response from backend - skipping portfolio")
                continue
                
            if len(btResp.get('strategies', {}).get('orders', [])) == 0:
                print_progress("⚠️ No trades generated - skipping portfolio")
                continue

            orders_count = len(btResp['strategies']['orders'])
            print_progress(f"✅ Backend returned {orders_count} orders")

            print_progress("🧮 Processing backtest response...")
            parsedOrderDf, marginReqByEachStgy, maxProfitLossDf = Util.parseBacktestingResponse(btResponse=btResp['strategies'], slippagePercent=portfolioForBt[pNo]['slippage_percent'])
            
            if parsedOrderDf.empty:
                print_progress("⚠️ No valid orders after parsing - skipping portfolio")
                continue

            print_progress(f"📊 Processing {len(parsedOrderDf)} trades across {len(parsedOrderDf['strategy'].unique())} strategies")

            print_progress("📋 Creating Excel output file...")
            excelObjj = pd.ExcelWriter(btResultFile, engine='openpyxl', mode="w")
            with excelObjj as writer:
                portfolioSettingDf[pNo]["PortfolioParameter"].to_excel(writer, sheet_name="PortfolioParameter", index=False)
                portfolioSettingDf[pNo]["GeneralParameter"].to_excel(writer, sheet_name="GeneralParameter", index=False)
                portfolioSettingDf[pNo]["LegParameter"].to_excel(writer, sheet_name="LegParameter", index=False)
            
            portfolioPnLDf, finalStatsDf = pd.DataFrame(), pd.DataFrame()
            stgywiseTransactionDf, stgyDayWiseStats, stgyMonthWiseStats, stgyMarginPercentageWiseStats = {"portfolio": pd.DataFrame()}, {}, {}, {}

            parsedOrderDf = parsedOrderDf.sort_values(by=['entry_datetime'])
            parsedOrderDf = parsedOrderDf.reset_index(drop=True)

            unique_strategies = sorted(parsedOrderDf['strategy'].unique())
            print_progress(f"📈 Processing {len(unique_strategies)} strategies: {', '.join(unique_strategies)}")

            for i, strategyName in enumerate(unique_strategies, 1):
                print_progress(f"   [{i}/{len(unique_strategies)}] Processing strategy: {strategyName}")

                strategyOrderDf = parsedOrderDf[parsedOrderDf['strategy'] == strategyName]
                print(f"      - {len(strategyOrderDf)} trades")

                stgyPnL = strategyOrderDf[['entry_datetime', 'netPnlAfterExpenses']].copy()
                stgyPnL['entry_datetime'] = stgyPnL['entry_datetime'].dt.date
                stgyPnL = stgyPnL.groupby(by=['entry_datetime'], as_index=False).sum()
                stgyPnL = stgyPnL.rename(columns={"entry_datetime": "entryDate", 'netPnlAfterExpenses': "bookedPnL"})

                portfolioPnLDf = pd.concat([stgyPnL, portfolioPnLDf])
                portfolioPnLDf = portfolioPnLDf.reset_index(drop=True)

                statsdf = Util.getBacktestStats(tradesDf=stgyPnL, initialCapital=marginReqByEachStgy.get(strategyName, 0))
                statsdf = pd.DataFrame.from_dict(statsdf, orient="index").reset_index().rename(columns={"index": "Particulars", 0: strategyName})

                if finalStatsDf.empty:
                    finalStatsDf = statsdf.copy()
                else:
                    finalStatsDf = pd.merge(left=finalStatsDf, right=statsdf, left_on="Particulars", right_on="Particulars")
                
                stgywiseTransactionDf[strategyName] = strategyOrderDf.copy()
                
                oldTrans = stgywiseTransactionDf['portfolio'].copy()
                oldTrans = pd.concat([oldTrans, strategyOrderDf])
                oldTrans = oldTrans.reset_index(drop=True)

                stgywiseTransactionDf['portfolio'] = oldTrans.copy()

                if STRATEGYWISE_RESULTS:
                    stgyDayWiseStats[strategyName] = Util.getDayWiseStats(tradesDf=stgyPnL)
                    stgyMonthWiseStats[strategyName] = Util.getMonthWiseStats(tradesDf=stgyPnL)

                    marginn = marginReqByEachStgy.get(strategyName, 0)

                    marginWiseDf = stgyPnL[["entryDate", "bookedPnL"]]
                    if marginn != 0:
                        marginWiseDf['bookedPnL'] = marginWiseDf['bookedPnL'] / marginn
                        marginWiseDf['bookedPnL'] *= 100
                    else:
                        marginWiseDf['bookedPnL'] = 0

                    stgyMarginPercentageWiseStats[strategyName] = Util.getMonthWiseStats(tradesDf=marginWiseDf)

            ############################################################################################################################################ for portfolio stats
            print_progress("📊 Calculating portfolio statistics...")
            if not portfolioPnLDf.empty:

                portfolioPnLDf = portfolioPnLDf.groupby(by=['entryDate'], as_index=False).sum()

                statsdf = Util.getBacktestStats(tradesDf=portfolioPnLDf, initialCapital=sum(list(marginReqByEachStgy.values())))
                statsdf = pd.DataFrame.from_dict(statsdf, orient="index").reset_index().rename(columns={"index": "Particulars", 0: "Combined"})

                portfolioPl = stgywiseTransactionDf['portfolio'][['entry_datetime', 'netPnlAfterExpenses']].copy()
                portfolioPl['entry_datetime'] = portfolioPl['entry_datetime'].dt.date
                portfolioPl = portfolioPl.groupby(by=['entry_datetime'], as_index=False).sum()
                portfolioPl = portfolioPl.rename(columns={"entry_datetime": "entryDate", 'netPnlAfterExpenses': "bookedPnL"})

                stgyDayWiseStats['portfolio'] = Util.getDayWiseStats(tradesDf=portfolioPl)
                stgyMonthWiseStats['portfolio'] = Util.getMonthWiseStats(tradesDf=portfolioPl)

                marginn = sum(list(marginReqByEachStgy.values()))
                marginWiseDf = portfolioPl[["entryDate", "bookedPnL"]]
                if marginn != 0:
                    marginWiseDf['bookedPnL'] = marginWiseDf['bookedPnL'] / marginn
                    marginWiseDf['bookedPnL'] *= 100
                else:
                    marginWiseDf['bookedPnL'] = 0

                stgyMarginPercentageWiseStats['portfolio'] = Util.getMonthWiseStats(tradesDf=marginWiseDf)

            if not finalStatsDf.empty:
                print_progress("💾 Generating output Excel file...")

                finalStatsDf = pd.merge(left=statsdf, right=finalStatsDf, left_on="Particulars", right_on="Particulars")
                
                Util.prepareOutputFile(
                    btResultFile=btResultFile, btStatsTableData=finalStatsDf, stgywiseTransactionDf=stgywiseTransactionDf, stgyDayWiseStats=stgyDayWiseStats, 
                    stgyMonthWiseStats=stgyMonthWiseStats, stgyMarginPercentageWiseStats=stgyMarginPercentageWiseStats, onlyStgyResults=STRATEGYWISE_RESULTS, 
                    excelFileExists=True, dailyMaxProfitLossDf=maxProfitLossDf
                )
                print_progress(f"✅ Excel file created: {btResultFile}")
            
            else:
                print_progress("⚠️ Empty result - no statistics to generate")
                logging.info("Empty result.")

            btend = datetime.now()
            duro = round((btend-btstart).total_seconds(), 2)

            filesToCopy.append(btResultFile)
            
            print_progress(f"⏱️ Portfolio backtest completed in {duro} seconds")
            logging.info(f"Completed backtesting : Overall duration {duro} seconds")
        
    except Exception as e:
        print_progress(f"❌ ERROR: {str(e)}")
        logging.error(traceback.format_exc())
        print("\n" + "="*80)
        print("FULL ERROR DETAILS:")
        print("="*80)
        traceback.print_exc()
    
    print_progress("🔄 Starting file merging process...")
    logging.info("Started merging code.")
    Util.copyFilesIntoMergeFolder(filePath=filesToCopy)
    logging.info("Process completed of merging code.")
    print_progress("✅ File merging completed")
    
    # Auto-open generated files
    if filesToCopy:
        print_progress("📂 Opening generated trade files...")
        for file_path in filesToCopy:
            try:
                if os.path.exists(file_path):
                    os.startfile(file_path)  # Windows-specific file opening
                    print_progress(f"   📄 Opened: {os.path.basename(file_path)}")
                else:
                    print_progress(f"   ⚠️ File not found: {file_path}")
            except Exception as e:
                print_progress(f"   ❌ Failed to open {os.path.basename(file_path)}: {str(e)}")
    else:
        print_progress("📂 No files to open")
    
    try:
        print_progress("🔊 Starting text-to-speech notification...")
        TEXT_TO_SPEECH_OBJ = pyttsx3.init()
        TEXT_TO_SPEECH_OBJ.setProperty('rate', 200)
        TEXT_TO_SPEECH_OBJ.runAndWait()
        TEXT_TO_SPEECH_OBJ.say("Backtest completed")
        TEXT_TO_SPEECH_OBJ.runAndWait()
    except Exception:
        logging.error(traceback.format_exc())

    print("="*80)
    print("🏁 PORTFOLIO BACKTEST COMPLETED")
    print(f"📁 Results saved in: {filesToCopy}")
    print("="*80)
    logging.info("Stopped")
