TAXES = 0
LOT_SIZE = {}
VALID_TRADING_WEEKDAYS = [
    'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'
]
VALID_MONTHS = [
    'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'
]
TRAIL_COST_RE_ENTRY = False
FIXED_VALUE_FOR_DYNAMIC_FACTOR = {}

# BT_URII = {
#     "tick": "http://127.0.0.1:5000/backtest/start", # nse bse
#     "tick": "http://127.0.0.1:5000/backtest/start", # mcx
#     "minute": "http://127.0.0.1:5000/backtest/start"
# }

BT_URII = {
    "tick": "http://localhost:5000/backtest/start", # nse bse
    # "tick": "http://192.168.173.122:5000/backtest/start", # mcx
    "minute": "http://localhost:5000/backtest/start"
}
VERSION_NO = {
    "TV": "29 Mar 25 (1.0.0)", 
    "PORTFOLIO": "15 Feb 25 (1.0.0)", 
    "FRONTEND": "22 Jan 25 (1.0.0)", 
    "FRONTENDTV": "22 Jan 25 (1.0.0)"
}

INPUT_FILE_FOLDER = "INPUT SHEETS"
PORTFOLIO_FILE_PATH = "INPUT PORTFOLIO CRUDEOIL.xlsx"
TV_FILE_PATH = "INPUT TV.xlsx"
LOG_FILE_FOLDER = "Logs"