import unittest
from app.database.utils import get_available_expiry_dates, get_current_week_expiry_date, get_next_week_expiry_date, get_ohlc, get_closest_strike_price, get_available_trading_dates
from app.commons.models import OHLC
from app.database.local import load
from app.commons.enums import OPTIONTYPE, NSEINDEX


class TestDatabaseUtils(unittest.TestCase):
    def setUp(self):
        load()
        
    def test_get_available_trading_dates(self):
        start_date = 200106
        end_date = 200106
        expiry_dates = get_available_trading_dates(start_date, end_date)

        self.assertEqual(expiry_dates, [200109, 200116, 200123, 200130, 200206, 200227, 200326])
        
    def test_get_available_expiry_dates(self):
        index = NSEINDEX.BANKNIFTY
        date = 200106
        expiry_dates = get_available_expiry_dates(index, date)

        self.assertEqual(expiry_dates, [200109, 200116, 200123, 200130, 200206, 200227, 200326])
        
    def test_current_week_expiry_date(self):
        index = NSEINDEX.BANKNIFTY
        date = 200106
        expiry_date = get_current_week_expiry_date(index, date)

        self.assertEqual(expiry_date, 200109)
        
    def test_next_week_expiry_date(self):
        index = NSEINDEX.BANKNIFTY
        date = 200106
        expiry_date = get_next_week_expiry_date(index, date)
        
        self.assertEqual(expiry_date, 200116)
        
    def test_get_ohlc(self):
        symbol = NSEINDEX.BANKNIFTY
        date = 200101
        time = 33300
        expiry_date = 200102
        strike_price = 30000
        option_type = OPTIONTYPE.CALL
        
        ohlc = get_ohlc(symbol, date, time, expiry_date, strike_price, option_type)
        
        self.assertEqual(ohlc, OHLC(date, time, "BANKNIFTY2010230000CE", 2179.10009765625, 2198.89990234375, 2179.10009765625, 2198.89990234375, 41, 1220))

    def test_get_closest_strike_price(self):
        symbol = NSEINDEX.BANKNIFTY
        date = 200101
        time = 33300
        expiry_date = 200102
        price = 100
        option_type = OPTIONTYPE.CALL
        
        closest_strike_price = get_closest_strike_price(symbol, date, time, expiry_date, price, option_type)
        
        self.assertEqual(closest_strike_price, 32400)