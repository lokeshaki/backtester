import unittest
from app.commons.enums import NUMBERTYPE, SIDE, STRIKESELECTIONTYPE, STRATEGYTYPE, OPTIONTYPE, NSEINDEX
from app.parser.models import (
    StrikeSelection,
    StopLoss,
    TakeProfit,
    ProfitMove,
    StopLossMove,
    TrailingStopLoss,
    Leg,
    Strategy
)


class TestEvaluatorModels(unittest.TestCase):
    def test_stop_loss_percentage_type(self):
        stop_loss = StopLoss(NUMBERTYPE.PERCENTAGE, 0.1)
        self.assertEqual(stop_loss.type, NUMBERTYPE.PERCENTAGE)
        self.assertEqual(stop_loss.value, 0.1)

    def test_stop_loss_point_type(self):
        stop_loss = StopLoss(NUMBERTYPE.POINT, 10)
        self.assertEqual(stop_loss.type, NUMBERTYPE.POINT)
        self.assertEqual(stop_loss.value, 10)

    def test_take_profit_percentage_type(self):
        take_profit = TakeProfit(NUMBERTYPE.PERCENTAGE, 0.1)
        self.assertEqual(take_profit.type, NUMBERTYPE.PERCENTAGE)
        self.assertEqual(take_profit.value, 0.1)

    def test_take_profit_point_type(self):
        take_profit = TakeProfit(NUMBERTYPE.POINT, 10)
        self.assertEqual(take_profit.type, NUMBERTYPE.POINT)
        self.assertEqual(take_profit.value, 10)

    def test_stop_loss_move_percentage_type(self):
        stop_loss_move = StopLossMove(NUMBERTYPE.PERCENTAGE, 0.1)
        self.assertEqual(stop_loss_move.type, NUMBERTYPE.PERCENTAGE)
        self.assertEqual(stop_loss_move.value, 0.1)

    def test_stop_loss_move_point_type(self):
        stop_loss_move = StopLossMove(NUMBERTYPE.POINT, 10)
        self.assertEqual(stop_loss_move.type, NUMBERTYPE.POINT)
        self.assertEqual(stop_loss_move.value, 10)

    def test_profit_move_percentage_type(self):
        profit_move = ProfitMove(NUMBERTYPE.PERCENTAGE, 0.1)
        self.assertEqual(profit_move.type, NUMBERTYPE.PERCENTAGE)
        self.assertEqual(profit_move.value, 0.1)

    def test_profit_move_point_type(self):
        profit_move = ProfitMove(NUMBERTYPE.POINT, 10)
        self.assertEqual(profit_move.type, NUMBERTYPE.POINT)
        self.assertEqual(profit_move.value, 10)

    def test_trailing_stop_loss(self):
        trailing_stop_loss = TrailingStopLoss(
            ProfitMove(NUMBERTYPE.PERCENTAGE, 0.1),
            StopLossMove(NUMBERTYPE.PERCENTAGE, 0.1),
        )
        self.assertEqual(trailing_stop_loss.profit_move.type, NUMBERTYPE.PERCENTAGE)
        self.assertEqual(trailing_stop_loss.profit_move.value, 0.1)
        self.assertEqual(trailing_stop_loss.stop_loss_move.type, NUMBERTYPE.PERCENTAGE)
        self.assertEqual(trailing_stop_loss.stop_loss_move.value, 0.1)

    def test_leg(self):
        leg = Leg(
            OPTIONTYPE.CALL,
            SIDE.BUY,
            StrikeSelection(STRIKESELECTIONTYPE.BY_PREMIUM, 100),
            StopLoss(NUMBERTYPE.PERCENTAGE, 0.1),
            TakeProfit(NUMBERTYPE.PERCENTAGE, 0.1),
            TrailingStopLoss(
                ProfitMove(NUMBERTYPE.PERCENTAGE, 0.1),
                StopLossMove(NUMBERTYPE.PERCENTAGE, 0.1),
            ),
            1,
            1,
        )
        self.assertEqual(leg.option_type, OPTIONTYPE.CALL)
        self.assertEqual(leg.side, SIDE.BUY)
        self.assertEqual(leg.strike_selection.type, STRIKESELECTIONTYPE.BY_PREMIUM)
        self.assertEqual(leg.stop_loss.type, NUMBERTYPE.PERCENTAGE)
        self.assertEqual(leg.stop_loss.value, 0.1)
        self.assertEqual(leg.take_profit.type, NUMBERTYPE.PERCENTAGE)
        self.assertEqual(leg.take_profit.value, 0.1)
        self.assertEqual(leg.trailing_stop_loss.profit_move.type, NUMBERTYPE.PERCENTAGE)
        self.assertEqual(leg.trailing_stop_loss.profit_move.value, 0.1)
        self.assertEqual(leg.trailing_stop_loss.stop_loss_move.type, NUMBERTYPE.PERCENTAGE)
        self.assertEqual(leg.trailing_stop_loss.stop_loss_move.value, 0.1)
        self.assertEqual(leg.quantity, 1)
        self.assertEqual(leg.multiplier, 1)
        
        
    def test_strategy(self):
        strategy = Strategy(
            "test",
            STRATEGYTYPE.INTRADAY,
            NSEINDEX.BANKNIFTY,
            910,
            1530,
            [
                Leg(
                    OPTIONTYPE.CALL,
                    SIDE.BUY,
                    StrikeSelection(STRIKESELECTIONTYPE.BY_PREMIUM, 100),
                    StopLoss(NUMBERTYPE.PERCENTAGE, 0.1),
                    TakeProfit(NUMBERTYPE.PERCENTAGE, 0.1),
                    TrailingStopLoss(
                        ProfitMove(NUMBERTYPE.PERCENTAGE, 0.1),
                        StopLossMove(NUMBERTYPE.PERCENTAGE, 0.1),
                    ),
                    1,
                    1,
                )
            ],
        )
        self.assertEqual(strategy.name, "test")
        self.assertEqual(strategy.type, STRATEGYTYPE.INTRADAY)
        self.assertEqual(strategy.index, NSEINDEX.BANKNIFTY)
        self.assertEqual(strategy.entry_time, 910)
        self.assertEqual(strategy.exit_time, 1530)
        self.assertEqual(strategy.legs[0].option_type, OPTIONTYPE.CALL)
        self.assertEqual(strategy.legs[0].side, SIDE.BUY)
        self.assertEqual(strategy.legs[0].strike_selection.type, STRIKESELECTIONTYPE.BY_PREMIUM)
        self.assertEqual(strategy.legs[0].stop_loss.type, NUMBERTYPE.PERCENTAGE)
        self.assertEqual(strategy.legs[0].stop_loss.value, 0.1)
        self.assertEqual(strategy.legs[0].take_profit.type, NUMBERTYPE.PERCENTAGE)
        self.assertEqual(strategy.legs[0].take_profit.value, 0.1)
        self.assertEqual(strategy.legs[0].trailing_stop_loss.profit_move.type, NUMBERTYPE.PERCENTAGE)
        self.assertEqual(strategy.legs[0].trailing_stop_loss.profit_move.value, 0.1)
        self.assertEqual(strategy.legs[0].trailing_stop_loss.stop_loss_move.type, NUMBERTYPE.PERCENTAGE)
        self.assertEqual(strategy.legs[0].trailing_stop_loss.stop_loss_move.value, 0.1)
        self.assertEqual(strategy.legs[0].quantity, 1)
        self.assertEqual(strategy.legs[0].multiplier, 1)
        self.assertEqual(len(strategy.legs), 1)
            
        
        

    