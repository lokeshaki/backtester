from app.commons.enums import ENUMELEMENT
from app.commons.modules import os, datetime, timedelta
from app.commons.models import Contract, TimeStamp
from app.commons.models import Trade, Order


def create_order(
    contract: Contract,
    product_type: ENUMELEMENT,
    order_type: ENUMELEMENT,
    side: ENUMELEMENT,
    limit_price: float,
    trigger_price: float,
    quantity: int,
    creation_time: TimeStamp,
):
    
    """
    Creates an order object
    
    Parameters:
        exchange (ENUMELEMENT): which exchange to trade on
        product_type (ENUMELEMENT): product type ( PRODUCTTYPE.MIS, PRODUCTTYPE.NRML )
        order_type (ENUMELEMENT): order type ( ORDERTYPE.LIMIT, ORDERTYPE.MARKET )
        side (ENUMELEMENT): side ( SIDE.BUY, SIDE.SELL )
        symbol (str): index ( NSEINDEX.NIFTY, NSEINDEX.BANKNIFTY)
        expiry (int): contract expiry if applicable
        strike (float): contract strike if applicable
        option_type (ENUMELEMENT): contract option type if applicable
        limit_price (float): limit price if order type is limit
        trigger_price (float): trigger price if order type is SL or SL-M
        quantity (int): quantity
        creation_time (TimeStamp): strategy layer order creation time
    
    Returns:
        Order: Order object
    """
    order = Order(
        contract,
        product_type,
        order_type,
        side,
        limit_price,
        trigger_price,
        quantity,
        creation_time
    )
    
    return order


def write_to_trade_file(trade: Trade, reason: str):
    """
    Writes trade to trades.txt file

    Parameters:
        trade (Trade): Trade object
    """
    ## Adding header if file does not exist
    if not os.path.exists("trades.txt"):
        with open("trades.txt", "w+") as f:
            f.write(",".join(["Datetime", "Exchange", "Symbol", "Expiry", "Strike", "Option Type", "Side", "Filled Qty", "Average Trade Price", "Reason"]) + "\n")
    with open("trades.txt", "a+") as f:
        formated_date = datetime.strptime(str(trade.timestamp.date), "%y%m%d")
        formated_time = formated_date + timedelta(seconds=trade.timestamp.time)
        f.write(",".join([ str(formated_time), str(trade.contract.exchange), str(trade.contract.symbol), str(trade.contract.expiry_date), str(trade.contract.strike_price), str(trade.contract.option_type), str(trade.side), str(trade.average_price), str(trade.filled_quantity), reason]) + "\n")