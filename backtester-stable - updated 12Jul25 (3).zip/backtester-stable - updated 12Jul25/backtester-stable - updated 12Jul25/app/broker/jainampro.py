from app.commons.modules import sleep, List, Dict, multiprocessing
from app.commons.utils import MessageThrottler
from app.commons.enums import ORDERTYPE
from app.config import Config
from app.commons.models import Order
import app.api_providers.symphony as symphony

# BASE_URL = "http://ctrade.jainam.in:3000"
BASE_URL = "http://122.160.137.209:13000"
PLACE_ORDER_URL_LIMIT = 10
GET_ORDER_URL_LIMIT = 3
GET_ORDER_BOOK_URL_LIMIT = 1
PLACE_ORDER_THROTTLER = "PLACE_ORDER_THROTTLER"
GET_ORDER_THROTTLER = "GET_ORDER_THROTTLER"

order_book: Dict[str, Order] = {}
place_order_queue: multiprocessing.Queue = multiprocessing.Queue()
modify_order_queue: multiprocessing.Queue = multiprocessing.Queue()
cancel_order_queue: multiprocessing.Queue = multiprocessing.Queue()
users_message_throttler: Dict[str, MessageThrottler] = {}
clients: Dict[str, str] = {}


def login(client_id: str, api_key: str, api_secret: str, **kwargs):
    if client_id not in clients:
        clients[client_id] = symphony.login(BASE_URL, api_key, api_secret)
        users_message_throttler[client_id] = {PLACE_ORDER_THROTTLER: MessageThrottler(PLACE_ORDER_URL_LIMIT, 1)}
        users_message_throttler[client_id] = {GET_ORDER_THROTTLER: MessageThrottler(GET_ORDER_URL_LIMIT, 1)}
    

def place_order(client_id: str, order: Order):
    try:
        order_book[order.tag] = order
        if client_id in clients:
            access_token = clients[client_id]
        else:
            raise Exception(f"Client {client_id} not logged in")
        return symphony.place_order(BASE_URL, client_id, access_token, order)
    except Exception as e:
        place_order_queue.put(order)


def modify_order(client_id: str, order: Order):
    try:
        if client_id in clients:
            access_token = clients[client_id]
        else:
            raise Exception(f"Client {client_id} not logged in")
        symphony.modify_order(BASE_URL, client_id, access_token, order)
    except Exception as e:
        modify_order_queue.put(order)


def cancel_order(client_id: str, order: Order):
    try:
        if client_id in clients:
            access_token = clients[client_id]
        else:
            raise Exception(f"Client {client_id} not logged in")
        symphony.cancel_order(BASE_URL, client_id, access_token, order)
    except Exception as e:
        cancel_order_queue.put(order)
    
    
def parse_order_book(orders: List[Dict]) -> List[Order]:
    for order in orders:
        broker_order_id = order['AppOrderID']
        order_tag = order['OrderUniqueIdentifier']
        order_status = order['OrderStatus']
        filled_quantity = order['CumulativeQuantity']
        average_price = float(order['OrderAverageTradedPrice']) if order['OrderAverageTradedPrice'] != "" else 0
        order_quantity = order['OrderQuantity']
        order_limit_price = order['OrderPrice']
        order_type = symphony.broker_to_local_order_types_map.get(order['OrderType'], ORDERTYPE.UNKNOWN)
        if order_tag in order_book:
            local_order = order_book[order_tag]
            local_order.filled_quantity = filled_quantity
            local_order.average_price = average_price
            local_order.status = symphony.broker_to_local_order_status_map.get(order_status, local_order.status)
            if order_limit_price != local_order.limit_price or order_type != local_order.order_type:
                modify_order_queue.put(local_order)
            if order_quantity != local_order.quantity:
                raise Exception(f"Order {broker_order_id} modified externally")
        else:
            pass


def run():
    while True:
        for client_id in clients:
            orders = symphony.get_order_book(BASE_URL, client_id, clients[client_id])
            parse_order_book(orders)
        sleep(Config.BROKER_LOOP_DELAY)