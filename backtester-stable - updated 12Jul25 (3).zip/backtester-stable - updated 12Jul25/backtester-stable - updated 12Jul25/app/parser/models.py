from app.commons.modules import List, pd, ta, datetime, timedelta
from app.commons.enums import (
    ENUMELEMENT,
    STRIKESELECTIONTYPE,
    LEGSTATUS,
    STRATEGYSTATUS,
    NUMBERTYPE
)
from app.commons.models import Order, Contract
from app.commons.constants import MAX_INT, MIN_INT
from abc import abstractmethod
from app.config import Config


class Indicator:
    @abstractmethod
    def eval(self, **kwargs):
        pass


class RsiIndicator(Indicator):
    def __init__(self, length: int, condition: str):
        self.length = length
        self.condition = condition
    
    def eval(self, combined_candles):
        rsi = None
        if len(combined_candles) == 0:
            return False
        candles_close = {"close": [candle.close/100.0 for candle in combined_candles]}
        df =  pd.DataFrame(candles_close)
        ta_rsi = ta.rsi(df["close"], self.length)
        if (ta_rsi is not None) and (not ta_rsi.empty):
            rsi = ta_rsi.iloc[-1]
        close = df["close"].iloc[-1]
        if rsi and eval(self.condition):
            return True
        else:
            return False
        
    def __repr__(self):
        return "<RSI %s %s>" % (self.length, self.condition) 
    
class StIndicator(Indicator):
    def __init__(self, length: int, multiplier: float, condition: str):
        self.length = length
        self.multiplier = multiplier
        self.condition = condition
        
    def eval(self, combined_candles):
        st = None
        if len(combined_candles) == 0:
            return False
        candles_close = {"close": [candle.close/100.0 for candle in combined_candles]}
        df =  pd.DataFrame(candles_close)
        ta_st = ta.supertrend(df["close"], df["close"], df["close"], self.length, self.multiplier)
        if (ta_st is not None) and (not ta_st.empty):
            st = ta_st.iloc[-1, 0]
        close = df["close"].iloc[-1]
        if st and eval(self.condition):
            return True
        else:
            return False
        
    def __repr__(self):
        return "<ST %s>" % (self.length, self.condition) 

class VolEmaIndicator(Indicator):  
    def __init__(self, length: int, condition: str):
        self.length = length
        self.condition = condition
        
    def eval(self, combined_candles):
        vol_ema = None
        if len(combined_candles) == 0:
            return False
        candles_close = {"volume": [candle.volume for candle in combined_candles]}
        df =  pd.DataFrame(candles_close)
        ta_volema = ta.ema(df["volume"], self.length)
        if (ta_volema is not None) and (not ta_volema.empty):
            vol_ema = ta_volema.iloc[-1]
        volume = df["volume"].iloc[-1]
        if vol_ema and eval(self.condition):
            return True
        else:
            return False
        
    def __repr__(self):
        return "<VOLEMA %s %s>" % (self.length, self.condition) 
    
class VolSmaIndicator(Indicator):  
    def __init__(self, length: int, condition: str):
        self.length = length
        self.condition = condition
        
    def eval(self, combined_candles):
        vol_sma = None
        if len(combined_candles) == 0:
            return False
        candles_close = {"volume": [candle.volume for candle in combined_candles]}
        df =  pd.DataFrame(candles_close)
        ta_volsma = ta.sma(df["volume"], self.length)
        if (ta_volsma is not None) and (not ta_volsma.empty):
            vol_sma = ta_volsma.iloc[-1]
        volume = df["volume"].iloc[-1]
        if vol_sma and eval(self.condition):
            return True
        else:
            return False
        
    def __repr__(self):
        return "<VOLSMA %s %s>" % (self.length, self.condition)  

class EmaIndicator(Indicator):  
    def __init__(self, length: int, condition: str):
        self.length = length
        self.condition = condition
        
    def eval(self, combined_candles):
        ema = None
        if len(combined_candles) == 0:
            return False
        
        candles = [candle.to_json() for candle in combined_candles]
        df = pd.DataFrame(candles)
        ta_ema = ta.ema(df["close"], self.length)
        if (ta_ema is not None) and (not ta_ema.empty):
            ema = ta_ema.iloc[-1]
        close = df["close"].iloc[-1]
        low = df["low"].iloc[-1]
        if ema and eval(self.condition):
            return True
        else:
            return False
        
    def __repr__(self):
        return "<EMA %s %s>" % (self.length, self.condition)
        
class VwapIndicator(Indicator):  
    def __init__(self, condition: str):
        self.condition = condition
        
    def to_timeindex(self, row):
        return datetime.strptime(str(int(row.date)), "%y%m%d") + timedelta(seconds=int(row.time))
        
    def eval(self, combined_candles):
        vwap = 0
        if len(combined_candles) == 0:
            return False
        candles = [candle.to_json() for candle in combined_candles]
        df =  pd.DataFrame(candles)
        df = df[df["date"] == max(df["date"])]
        df["timestamp"] = df.apply(self.to_timeindex, axis=1)
        df = df.set_index("timestamp")
        
        if df.shape[0] == 0:
            return None
        ta_vwap = ta.vwap(df["close"]/100, df["close"]/100, df["close"]/100, df["volume"])
        close = df["close"].iloc[-1] / 100
        if (ta_vwap is not None) and (not ta_vwap.empty):
            vwap  = ta_vwap.iloc[-1]
        if vwap and eval(self.condition):
            return True
        else:
            return False
    
    def __repr__(self):
        return "<VWAP %s>" % ( self.condition)
        
class Rsi:
    def __init__(self, length: int, interval: int, overbought_level: float, oversold_level: float, direction: str):
        self.length = length
        self.interval = interval
        
        self.overbought_level = overbought_level
        self.oversold_level = oversold_level
        self.direction = direction

    def __repr__(self):
        return "<Rsi %s %s %s>" % (self.length, self.interval, self.value)
    
    def __eq__(self, other):
        if other is None:
            return False
        return self.length == other.length and self.interval == other.interval and self.value == other.value
    
    def to_json(self):
        return {"length": self.length, "interval": self.interval, "value": self.value}


class StrikeSelection:
    def __init__(self, type: ENUMELEMENT, value: str):
        self.type = type
        if type not in [STRIKESELECTIONTYPE.BY_DYNAMIC_FACTOR, STRIKESELECTIONTYPE.BY_MATCH_PREMIUM]:
            self.value = float(value)
        else:
            self.value = value

    def __repr__(self):
        return "<StrikeSelection %s %s>" % (self.type, self.value)

    def __eq__(self, other):
        return self.type == other.type and self.value == other.value

    def to_json(self):
        return {"type": self.type.name, "value": self.value}

class StopLossParams:
    def __init__(self, check_frequency: int):
        self.check_frequency = check_frequency
        
    def __repr__(self):
        return "<StopLossParams %s>" % (self.check_frequency)
    
    def __eq__(self, other):
        return self.check_frequency == other.check_frequency
    
    def to_json(self):
        return {"check_frequency": self.check_frequency}
    

class StopLoss:
    def __init__(self, type: ENUMELEMENT, value: float, params: StopLossParams = None):
        self.type = type
        self.value = value
        self.params = params

    def __repr__(self):
        return "<StopLoss %s %s>" % (self.type, self.value)

    def __eq__(self, other):
        return self.type == other.type and self.value == other.value

    def to_json(self):
        return {"type": self.type.name, "value": self.value}


class TakeProfitParams:
    def __init__(self, check_frequency: int):
        self.check_frequency = check_frequency
        
    def __repr__(self):
        return "<TakeProfitParams %s>" % (self.check_frequency)
    
    def __eq__(self, other):
        return self.check_frequency == other.check_frequency
    
    def to_json(self):
        return {"check_frequency": self.check_frequency}


class TakeProfit:
    def __init__(self, type: ENUMELEMENT, value: float, params: TakeProfitParams = None):
        self.type = type
        self.value = value
        self.params = params

    def __repr__(self):
        return "<TakeProfit %s %s>" % (self.type, self.value)

    def __eq__(self, other):
        return self.type == other.type and self.value == other.value

    def to_json(self):
        return {"type": self.type.name, "value": self.value}


class ProfitMove:
    def __init__(self, type: ENUMELEMENT, value: float):
        self.type = type
        self.value = value

    def __repr__(self):
        return "<ProfitMove %s %s>" % (self.type, self.value)

    def __eq__(self, other):
        return self.type == other.type and self.value == other.value

    def to_json(self):
        return {"type": self.type.name, "value": self.value}


class StopLossMove:
    def __init__(self, type: ENUMELEMENT, value: float):
        self.type = type
        self.value = value

    def __repr__(self):
        return "<StopLossMove %s %s>" % (self.type, self.value)

    def __eq__(self, other):
        return self.type == other.type and self.value == other.value

    def to_json(self):
        return {"type": self.type.name, "value": self.value}


class TrailingStopLoss:
    def __init__(self, profit_move: ProfitMove, stop_loss_move: StopLossMove):
        self.profit_move = profit_move
        self.stop_loss_move = stop_loss_move

    def __repr__(self):
        return "<TrailingStopLoss %s %s>" % (self.profit_move, self.stop_loss_move)

    def __eq__(self, other):
        return (
            self.profit_move == other.profit_move
            and self.stop_loss_move == other.stop_loss_move
        )

    def to_json(self):
        return {
            "profit_move": self.profit_move.to_json(),
            "stop_loss_move": self.stop_loss_move.to_json(),
        }


class WaitIn:
    def __init__(self, type: ENUMELEMENT, value: float, should_trail: bool=False):
        self.type = type
        self.value = value
        self.should_trail = should_trail
        

    def __repr__(self):
        return "<WaitAndTrade %s %s>" % (self.type, self.value)

    def __eq__(self, other):
        return self.type == other.type and self.value == other.value

    def to_json(self):
        return {"type": self.type.name, "value": self.value}
    

class ReentryParams:
    def __init__(self, count: int, cutoff_time: int, check_frequency: int, cool_off_time: int):
        self.count = count
        self.cutoff_time = cutoff_time
        self.check_frequency = check_frequency
        self.cool_off_time = cool_off_time
    
    def __repr__(self):
        return "<ReentryParams %s %s %s %s>" % (self.count, self.cutoff_time, self.check_frequency, self.cool_off_time)
    
    def __eq__(self, other):
        return self.count == other.count and self.cutoff_time == other.cutoff_time and self.check_frequency == other.check_frequency and self.cool_off_time == other.cool_off_time
    
    def to_json(self):
        return {"count": self.count, "cutoff_time": self.cutoff_time, "check_frequency": self.check_frequency, "cool_down_time": self.cool_off_time}

class Reentry:
    def __init__(self, type: ENUMELEMENT, value: ReentryParams):
        self.type = type
        self.value = value
        
    def __repr__(self):
        return "<Reentry %s %s>" % (self.type, self.value)

    def __eq__(self, other):
        return True
    
    def to_json(self):
        return {"type": self.type.name, "value": self.value.to_json()}
    

class LockAndTrail:
    def __init__(self, type: ENUMELEMENT, lock_time: int, lock: float, trail: float, next_check_time: int, final_trail_time: int=MAX_INT, final_trail: float=MIN_INT):
        self.type = type
        self.lock_time = lock_time
        self.lock = lock
        self.trail = trail
        self.next_check_time = next_check_time
        self.final_trail_time = final_trail_time
        self.final_trail = final_trail
        
    def __repr__(self) -> str:
        return "<LockAndTrail %s %s>" % (self.lock, self.trail)
    
    def __eq__(self, other) -> str:
        return self.lock == other.lock and self.trail == other.trail
    
    def to_json(self):
        return {"lock": self.lock, "trail": self.trail}


class ExitPriceConfig:
    def __init__(self, take_profit_based_on: str, stop_loss_based_on: str, trade_file_exit_price_on_take_profit: str, trade_file_exit_price_on_stop_loss: str, trade_file_exit_price_on_trigger):
        self.take_profit_based_on = take_profit_based_on
        self.stop_loss_based_on = stop_loss_based_on
        self.trade_file_exit_price_on_take_profit = trade_file_exit_price_on_take_profit
        self.trade_file_exit_price_on_stop_loss = trade_file_exit_price_on_stop_loss
        self.trade_file_exit_price_on_trigger = trade_file_exit_price_on_trigger
        
    def __repr__(self):
        return "<EXITPRICECONFIG %s %s>" % (self.pnl_based_on, self.trade_file_exit_based_on)
    
    def __eq__(self, other):
        return self.pnl_based_on == other.pnl_based_on and self.trade_file_exit_based_on == other.trade_file_exit_based_on
    
    def to_json(self):
        return {"pnl_based_on": self.pnl_based_on, "trade_file_exit_based_on": self.trade_file_exit_based_on}
    
class Hedge:
    def __init__(self, id: str, option_type: ENUMELEMENT,
        side: ENUMELEMENT,
        expiry_type: ENUMELEMENT, strike_selection: StrikeSelection, next_expiry_select: bool = True):
        self.id = id
        self.expiry_type = expiry_type
        self.side = side
        self.option_type = option_type
        self.strike_selection = strike_selection
        
        self.contract: Contract = None
        self.entry_order: Order = None
        self.exit_order: Order = None
        self.status = LEGSTATUS.CREATED
        self.wait_and_trade: int = WaitIn(NUMBERTYPE.POINT, 0)
        self.current_wait_and_trade: int = 0
        self.contract_initial_price: float = 0
        self.orb = None
        self.next_expiry_select = next_expiry_select
        
    def __repr__(self):
        return "<Hedge %s %s>" % (self.id, self.strike_selection)
    
    def __eq__(self, other):
        return self.id == other.id and self.strike_selection == other.strike_selection
    
    def to_json(self):
        return {"id": self.id, "strike_selection": self.strike_selection.to_json()}

class VwapLeg:
    def __init__(
        self,
        id: str,
        option_type: ENUMELEMENT,
        side: ENUMELEMENT,
        expiry_type: ENUMELEMENT,
        strike_selection: StrikeSelection,
        stop_loss: StopLoss,
        take_profit: TakeProfit,
        trailing_stop_loss: TrailingStopLoss,
        quantity: int,
        multiplier: int,
        hedge: Hedge = None,
        hedge_pnl_effect: bool = False,
        refresh_contract_on_reentry: bool = False,
        next_expiry_select: bool = True
    ):
        self.id = id
        self.option_type = option_type
        self.side = side
        self.expiry_type = expiry_type
        self.strike_selection = strike_selection
        self.stop_loss = stop_loss
        self.take_profit = take_profit
        self.trailing_stop_loss = trailing_stop_loss
        self.quantity = quantity
        self.multiplier = multiplier
        self.status = LEGSTATUS.CREATED
        self.hedge = hedge
        self.hedge_pnl_effect = hedge_pnl_effect
        self.refresh_contract_on_reentry = refresh_contract_on_reentry

        self.contract: Contract = None
        self.orders: List[Order] = []
        self.current_stop_loss: int = None
        self.current_take_profit: int = None
        self.current_wait_and_trade: int = None
        self.current_trailing_stop_loss: int = None
        self.contract_initial_price: float = None
        self.is_stop_loss_trailed: bool = False
        self.is_waiting_for_take_profit_reentry: bool = False
        self.is_waiting_for_stop_loss_reentry: bool = False
        self.is_wait_in_time_updated: bool = False
        self.wait_in_time: int = 0
        self.wait_in_time_devider: int = Config.BT_FREQUENCY
        self.leg_entry_price: float = None
        self.entry_number: int = 0
        self.stop_loss_entry_number: int = 0
        self.take_profit_entry_number: int = 0
        self.realized_pnl: float = 0
        self.reentry_reason: str = ""
        self.is_contracterized_before = False
        self.next_expiry_select = next_expiry_select

    def __repr__(self):
        return "<Leg %s %s %s %s %s %s %s %s %s %s %s %s>" % (
            self.id,
            self.option_type,
            self.side,
            self.expiry_type,
            self.strike_selection,
            self.quantity,
            self.multiplier
        )

    def __eq__(self, other):
        return (
            self.id == other.id
            and self.option_type == other.option_type
            and self.side == other.side
            and self.expiry_type == other.expiry_type
            and self.strike_selection == other.strike_selection
            and self.quantity == other.quantity
            and self.multiplier == other.multiplier
        )

    def to_json(self):
        return {
            "id": self.id,
            "option_type": self.option_type.name,
            "side": self.side.name,
            "expiry_type": self.expiry_type.name,
            "strike_selection": self.strike_selection.to_json(),
            "quantity": self.quantity,
            "multiplier": self.multiplier,
        }
        
class BoxDiff:
    def __init__(self, type: ENUMELEMENT, value: float):
        self.type = type
        self.value = value
        
    def __repr__(self):
        return "<BoxDiff %s %s>" % (self.type, self.value)
    
    def __eq__(self, other):
        return self.type == other.type and self.value == other.value
    
    def to_json(self):
        return {"type": self.type.name, "value": self.value}
    
    
class Box:
    def __init__(self, diff: BoxDiff, duration: int, force_entry: bool, force_entry_type: ENUMELEMENT, contractrize_only_once: bool):
        self.diff = diff
        self.contractrize_only_once: bool = contractrize_only_once
        self.duration = duration
        self.force_entry = force_entry
        self.force_entry_type = force_entry_type
        
    def __repr__(self):
        return "<Box %s %s %s %s %s>" % (self.diff, self.duration, self.force_entry, self.force_entry_type)
    
    def __eq__(self, other):
        return self.diff == other.diff and self.duration == other.duration and self.force_entry == other.force_entry and self.force_entry_type == other.force_entry_type
    
    def to_json(self):
        return {"diff": self.diff, "duration": self.duration, "force_entry": self.force_entry, "force_entry_type": self.force_entry_type.name}
    

class ORB:
    def __init__(self, wait_start: int, wait_till: int, entry_on: ENUMELEMENT, new_selection: int):
        self.wait_start = wait_start
        self.wait_till = wait_till
        self.entry_on = entry_on
        self.is_set = False
        self.high_range = None
        self.low_range = None
        self.new_selection = new_selection
        
    def __repr__(self) -> str:
        return "<ORB %s %s>" % (self.wait_till, self.entry_on)
    
    def __eq__(self, other: object) -> bool:
        return self.wait_till == other.wait_till and self.entry_on == other.entry_on
    

class OICheck:
    def __init__(self, check_interval: int,  value: float, recontracterized: bool):
        self.check_interval = check_interval
        self.value = value
        self.recontracterized = recontracterized
        
    def __repr__(self) -> str:
        return "<OICheck %s %s>" % (self.value, self.recontracterized)
    
    def __eq__(self, other: object) -> bool:
        return self.wait_till == other.wait_till and self.entry_on == other.entry_on
    
class Leg:
    def __init__(
        self,
        id: str,
        option_type: ENUMELEMENT,
        side: ENUMELEMENT,
        expiry_type: ENUMELEMENT,
        strike_selection: StrikeSelection,
        stop_loss: StopLoss,
        take_profit: TakeProfit,
        trailing_stop_loss: TrailingStopLoss,
        wait_and_trade: WaitIn,
        quantity: int,
        take_profit_reentry: Reentry,
        stop_loss_reentry: Reentry,
        triggered_reentry: Reentry,
        multiplier: int,
        recost_cascade: bool,
        recost_entry_on_crossover: bool,
        orb: ORB,
        oi_check: OICheck,
        hedge: Hedge = None,
        hedge_pnl_effect: bool = False,
        next_expiry_select: bool = False,
        is_idle: bool = False,
        on_entry: dict = {},
        on_exit: dict = {}
    ):
        self.id = id
        self.option_type = option_type
        self.side = side
        self.expiry_type = expiry_type
        self.strike_selection = strike_selection
        self.stop_loss = stop_loss
        self.take_profit = take_profit
        self.trailing_stop_loss = trailing_stop_loss
        self.wait_and_trade = wait_and_trade
        self.quantity = quantity
        self.take_profit_reentry = take_profit_reentry
        self.stop_loss_reentry = stop_loss_reentry
        self.triggered_reentry = triggered_reentry
        self.multiplier = multiplier
        self.status = LEGSTATUS.CREATED
        self.recost_cascade = recost_cascade
        self.recost_entry_on_crossover = recost_entry_on_crossover
        self.orb = orb
        self.oi_check = oi_check
        self.hedge = hedge
        self.hedge_pnl_effect = hedge_pnl_effect

        self.contract: Contract = None
        self.orders: List[Order] = []
        self.current_stop_loss: int = None
        self.current_take_profit: int = None
        self.current_wait_and_trade: int = None
        self.current_trailing_stop_loss: int = None
        self.contract_initial_price: float = None
        self.is_stop_loss_trailed: bool = False
        self.take_profit_reentry_remaining: int = self.take_profit_reentry.value.count
        self.stop_loss_reentry_remaining: int = self.stop_loss_reentry.value.count
        self.trigger_reentry_remaining: int = self.triggered_reentry.value.count
        self.is_waiting_for_take_profit_reentry: bool = False
        self.is_waiting_for_stop_loss_reentry: bool = False
        self.is_waiting_for_triggered_reentry: bool = False
        self.is_wait_in_time_updated: bool = False
        self.wait_in_time: int = 0
        self.wait_in_time_devider: int = Config.BT_FREQUENCY
        self.leg_entry_price: float = None
        self.entry_number: int = 0
        self.stop_loss_entry_number: int = 0
        self.take_profit_entry_number: int = 0
        self.realized_pnl: float = 0
        self.reentry_reason: str = ""
        self.is_first_entry = True
        self.next_expiry_select = next_expiry_select
        self.is_idle = is_idle
        self.is_activated = not self.is_idle
        self.on_entry = on_entry
        self.on_exit = on_exit
        self.exit_triggered = False
        self.next_action_time = 0
        self.entered_by_trigger = False
        self.is_spawned = False
        
    def __repr__(self):
        return "<Leg %s %s %s %s %s %s %s %s %s %s %s %s>" % (
            self.id,
            self.option_type,
            self.side,
            self.expiry_type,
            self.strike_selection,
            self.stop_loss,
            self.take_profit,
            self.trailing_stop_loss,
            self.quantity,
            self.take_profit_reentry,
            self.stop_loss_reentry,
            self.multiplier,
            self.recost_cascade
        )

    def __eq__(self, other):
        return (
            self.id == other.id
            and self.option_type == other.option_type
            and self.side == other.side
            and self.expiry_type == other.expiry_type
            and self.strike_selection == other.strike_selection
            and self.stop_loss == other.stop_loss
            and self.take_profit == other.take_profit
            and self.trailing_stop_loss == other.trailing_stop_loss
            and self.quantity == other.quantity
        )

    def to_json(self):
        return {
            "id": self.id,
            "option_type": self.option_type.name,
            "side": self.side.name,
            "expiry_type": self.expiry_type.name,
            "strike_selection": self.strike_selection.to_json(),
            "stop_loss": self.stop_loss.to_json(),
            "take_profit": self.take_profit.to_json(),
            "trailing_stop_loss": self.trailing_stop_loss.to_json(),
            "quantity": self.quantity,
            "take_profit_reentry": self.take_profit_reentry.to_json(),
            "stop_loss_reentry": self.stop_loss_reentry.to_json(),	
            "multiplier": self.multiplier,
            "recost_cascade": self.recost_cascade
        }
        
        
class Strategy:
    def __init__(
        self,
        name: str,
        type: ENUMELEMENT,
        index: ENUMELEMENT,
        underlying: ENUMELEMENT,
        entry_date: int,
        entry_time: int,
        exit_date: int,
        exit_time: int,
        stop_loss: StopLoss,
        take_profit: TakeProfit,
        box_stop_loss: StopLoss,
        box_take_profit: TakeProfit,
        take_profit_reentry: Reentry,
        stop_loss_reentry: Reentry,
        box_stop_loss_reentry: Reentry,
        box_take_profit_reentry: Reentry,
        squareoff_reentry: Reentry,
        rsi_reentry: Reentry,
        place_order_after: int,
        exit_price_config: ExitPriceConfig,
        pnl_calculation_from: str,
        box: Box,
        entry_rsi: Rsi,
        exit_rsi: Rsi,
        legs: List[Leg],
        squareoff_all_legs,
        dte: int,
        lock_and_trail: LockAndTrail,
        trailing_stop_loss: TrailingStopLoss,
        move_sl_to_cost: bool,
        index_base_price: int,
        multiplier: int,
        tv_expiry_day_exit_time: int,
        acceptable_weekdays: List[int]=None,
        concurrent_legs: int=MAX_INT
    ):
        self.name = name
        self.type = type
        self.index = index
        self.underlying = underlying
        self.entry_date = entry_date
        self.entry_time = entry_time
        self.exit_date = exit_date
        self.exit_time = exit_time
        self.tv_expiry_day_exit_time = tv_expiry_day_exit_time
        self.stop_loss: StopLoss = stop_loss
        self.take_profit: TakeProfit = take_profit 
        self.box_stop_loss = box_stop_loss
        self.box_take_profit = box_take_profit
        self.stop_loss_reentry = stop_loss_reentry 
        self.take_profit_reentry = take_profit_reentry
        self.box_stop_loss_reentry = box_stop_loss_reentry
        self.box_take_profit_reentry = box_take_profit_reentry
        self.squareoff_reentry = squareoff_reentry
        self.place_order_after = place_order_after
        self.rsi_reentry = rsi_reentry
        self.exit_price_config = exit_price_config
        self.pnl_calculation_from = pnl_calculation_from
        self.box = box
        self.entry_rsi = entry_rsi
        self.exit_rsi = exit_rsi
        self.legs = legs
        self.take_profit_reentry_remaining: int = self.take_profit_reentry.value.count
        self.stop_loss_reentry_remaining: int = self.stop_loss_reentry.value.count
        self.box_stop_loss_reentry_remaining = self.box_stop_loss_reentry.value.count
        self.box_take_profit_reentry_remaining = self.box_take_profit_reentry.value.count
        self.rsi_reentry_remaining: int = self.rsi_reentry.value.count
        self.sqaareoff_reentry_remaining: int = self.squareoff_reentry.value.count
        self.entry_number: int = 0
        self.is_first_entry: bool = True
        self.status = STRATEGYSTATUS.CREATED
        self.current_box_diff = None
        self.last_stop_loss_reentry_check_time = self.entry_time
        self.last_take_profit_reentry_check_time = self.entry_time
        self.last_stop_loss_check_time = self.entry_time
        self.last_take_profit_check_time = self.entry_time
        self.entry_indicator_triggered = False
        self.next_reentry_check_time = 0
        self.entry_combined_premium = 0
        self.squareoff_all_legs = squareoff_all_legs
        self.move_sl_to_cost = move_sl_to_cost
        self.is_any_leg_exited = False
        self.is_any_leg_sl_hit = False
        self.tick_profits = {}
        self.tick_losses = {}
        self.realized_pnl = 0
        self.current_stop_loss = self.stop_loss.value
        self.is_stop_loss_trailed = False
        self.dte = dte
        self.can_trail = False
        self.lock_and_trail = lock_and_trail
        self.is_lock_is_triggerd = False
        self.trailing_stop_loss = trailing_stop_loss
        self.current_trailing_stop_loss = [self.trailing_stop_loss.profit_move.value, self.trailing_stop_loss.stop_loss_move.value]
        self.index_base_price = index_base_price
        self.multiplier = multiplier
        self.next_action_time = 0
        self.concurrent_legs = concurrent_legs
        self.acceptable_weekdays = acceptable_weekdays

    def __repr__(self):
        return "<Strategy %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s>" % (
            self.name,
            self.type,
            self.index,
            self.underlying,
            self.entry_time,
            self.exit_time,
            self.stop_loss,
            self.take_profit,
            self.stop_loss_reentry,
            self.take_profit_reentry,
            self.place_order_after,
            self.exit_price_config,
            self.box,
            self.legs,
            self.squareoff_all_legs,
            self.dte
        )

    def __eq__(self, other):
        return (
            self.name == other.name
            and self.type == other.type
            and self.index == other.index
            and self.underlying == other.underlying
            and self.entry_time == other.entry_time
            and self.exit_time == other.exit_time
            and self.stop_loss == other.stop_loss
            and self.take_profit == other.take_profit
            and self.stop_loss_reentry == other.stop_loss_reentry
            and self.take_profit_reentry == other.take_profit_reentry
            and self.place_order_after == other.place_order_after
            and self.exit_price_config == other.exit_price_config
            and self.box == other.box
            and self.legs == other.legs
            and self.squareoff_all_legs == other.squareoff_all_legs
            and self.dte == other.dte
        )

    def to_json(self):
        return {
            "name": self.name,
            "type": self.type.name,
            "index": self.index.name,
            "underlying": self.underlying.name,
            "entry_time": self.entry_time,
            "exit_time": self.exit_time,
            "stop_loss": self.stop_loss.to_json(),
            "take_profit": self.take_profit.to_json(),
            "stop_loss_reentry": self.stop_loss_reentry.to_json(),
            "take_profit_reentry": self.take_profit_reentry.to_json(),
            "place_order_after": self.place_order_after,
            "exit_price_config": self.exit_price_config.to_json(),
            "box": self.box.to_json(),
            "legs": [leg.to_json() for leg in self.legs],
            "squareoff_all_legs": self.squareoff_all_legs,
            "dte": self.dte
        }

class VwapStrategy:
    def __init__(
        self,
        name: str,
        type: ENUMELEMENT,
        index: ENUMELEMENT,
        underlying: ENUMELEMENT,
        entry_date: int,
        entry_time: int,
        exit_date: int,
        exit_time: int,
        stop_loss: StopLoss,
        take_profit: TakeProfit,
        take_profit_reentry: Reentry,
        stop_loss_reentry: Reentry,
        indicator_based_reentry: Reentry,
        place_order_after: int,
        exit_price_config: ExitPriceConfig,
        pnl_calculation_from: str,
        entry_indicators: List[Indicator],
        exit_indicators: List[Indicator],
        checking_interval: int,
        max_length: int,
        legs: List[VwapLeg],
        dte: int,
        lock_and_trail: LockAndTrail,
        trailing_stop_loss: TrailingStopLoss,
        index_base_price: int,
        multiplier: int,
        tv_expiry_day_exit_time: int,
        indicator_candle_based_on: str = "underlying",
        rr: tuple = None,
        stoploss_buffer: float=0,
        entry_buffer: float=0,
        acceptable_weekdays: List[int]=0,
    ):
        self.name = name
        self.type = type
        self.index = index
        self.underlying = underlying
        self.entry_date = entry_date
        self.entry_time = entry_time
        self.exit_date = exit_date
        self.exit_time = exit_time
        self.tv_expiry_day_exit_time = tv_expiry_day_exit_time
        self.stop_loss: StopLoss = stop_loss
        self.take_profit: TakeProfit = take_profit 
        self.stop_loss_reentry = stop_loss_reentry 
        self.take_profit_reentry = take_profit_reentry
        self.indicator_based_reentry = indicator_based_reentry
        self.place_order_after = place_order_after
        self.exit_price_config = exit_price_config
        self.pnl_calculation_from = pnl_calculation_from
        self.entry_indicators = entry_indicators
        self.exit_indicators = exit_indicators
        self.checking_interval = checking_interval
        self.max_length = max_length
        self.ready_to_enter = False
        self.ready_to_exit = False
        self.legs = legs
        self.take_profit_reentry_remaining: int = self.take_profit_reentry.value.count
        self.stop_loss_reentry_remaining: int = self.stop_loss_reentry.value.count
        self.indicator_based_reentry_remaining: int = self.indicator_based_reentry.value.count
        self.entry_number: int = 0
        self.is_first_entry: bool = True
        self.status = STRATEGYSTATUS.CREATED
        self.current_box_diff = None
        self.last_stop_loss_reentry_check_time = self.entry_time
        self.last_take_profit_reentry_check_time = self.entry_time
        self.last_stop_loss_check_time = self.entry_time
        self.last_take_profit_check_time = self.entry_time
        self.entry_indicator_triggered = False
        self.next_reentry_check_time = 0
        self.entry_combined_premium = 0
        self.is_any_leg_exited = False
        self.tick_profits = {}
        self.tick_losses = {}
        self.realized_pnl = 0
        self.current_stop_loss = self.stop_loss.value
        self.is_stop_loss_trailed = False
        self.dte = dte
        self.can_trail = False
        self.lock_and_trail = lock_and_trail
        self.is_lock_is_triggerd = False
        self.trailing_stop_loss = trailing_stop_loss
        self.current_trailing_stop_loss = [self.trailing_stop_loss.profit_move.value, self.trailing_stop_loss.stop_loss_move.value]
        self.not_first_day = False
        self.indicator_based_entry = False
        self.index_base_price = index_base_price
        self.multiplier = multiplier
        self.indicator_candle_based_on = indicator_candle_based_on
        self.signal_candle_low = MAX_INT
        self.signal_candle_high = MIN_INT
        self.signal_candle = None
        self.rr = rr
        self.stoploss_buffer = stoploss_buffer
        self.entry_buffer = entry_buffer
        self.acceptable_weekdays = acceptable_weekdays

    def __repr__(self):
        return "<Strategy %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s>" % (
            self.name,
            self.type,
            self.index,
            self.underlying,
            self.entry_time,
            self.exit_time,
            self.stop_loss,
            self.take_profit,
            self.stop_loss_reentry,
            self.take_profit_reentry,
            self.place_order_after,
            self.exit_price_config,
            self.legs,
            self.dte
        )

    def __eq__(self, other):
        return (
            self.name == other.name
            and self.type == other.type
            and self.index == other.index
            and self.underlying == other.underlying
            and self.entry_time == other.entry_time
            and self.exit_time == other.exit_time
            and self.stop_loss == other.stop_loss
            and self.take_profit == other.take_profit
            and self.stop_loss_reentry == other.stop_loss_reentry
            and self.take_profit_reentry == other.take_profit_reentry
            and self.place_order_after == other.place_order_after
            and self.exit_price_config == other.exit_price_config
            and self.legs == other.legs
        )

    def to_json(self):
        return {
            "name": self.name,
            "type": self.type.name,
            "index": self.index.name,
            "underlying": self.underlying.name,
            "entry_time": self.entry_time,
            "exit_time": self.exit_time,
            "stop_loss": self.stop_loss.to_json(),
            "take_profit": self.take_profit.to_json(),
            "stop_loss_reentry": self.stop_loss_reentry.to_json(),
            "take_profit_reentry": self.take_profit_reentry.to_json(),
            "place_order_after": self.place_order_after,
            "exit_price_config": self.exit_price_config.to_json(),
            "legs": [leg.to_json() for leg in self.legs],
            "dte": self.dte
        }


class Portfolio:
    def __init__(self, id: str, strategies: List[Strategy], stop_loss: StopLoss, take_profit: TakeProfit, lock_and_trail: LockAndTrail, trailing_stop_loss: TrailingStopLoss):
        self.id = id
        self.strategies = strategies
        self.stop_loss = stop_loss
        self.take_profit = take_profit
        self.is_stop_loss_trailed = False
        self.can_trail = False
        self.lock_and_trail = lock_and_trail
        self.is_lock_is_triggerd = False
        self.trailing_stop_loss = trailing_stop_loss
        self.current_trailing_stop_loss = [self.trailing_stop_loss.profit_move.value, self.trailing_stop_loss.stop_loss_move.value]
        self.is_exit_hit = False
        self.current_take_profit = self.take_profit.value
        self.current_stop_loss = self.stop_loss.value
        
    def __repr__(self) -> str:
        return "<Portfolio %s %s>" % (
            self.id,
            self.strategies
        )
        
    def __eq__(self, other):
        return (
            self.id == other.id
        )
        
    def to_json(self):
        return {
            "name": self.id,
            "strategies": [strategy.to_json() for strategy in self.strategies]
        }
