import pandas as pd
import os

class Config:

    __config = pd.read_csv("./app/config.csv")
    __config = __config.dropna(how="any")[['Field', 'Value']].set_index("Field").to_dict()['Value']

    MYSQL_HOST = os.environ.get('MYSQL_HOST')
    MYSQL_PORT = os.environ.get('MYSQL_PORT')
    MYSQL_USER = os.environ.get('MYSQL_USER')
    MYSQL_PASSWORD = os.environ.get('MYSQL_PASSWORD')
    MYSQL_DATABASE = "ushistoricaldb" if __config['LOAD_US_DATA'].lower() == "yes" else "historicaldb"
    MYSQL_TICK_DATABASE = "nsetickhistoricaldb"
    WRITE_TRADES_TO_FILE = int(os.environ.get('WRITE_TRADES_TO_FILE'))
    LOAD_INDEXES = []
    APP_MODE = "test"
    DATA_LOAD_FROM = int(__config.get("DATA_LOAD_FROM"))
    DATA_LOAD_TILL = int(__config.get("DATA_LOAD_TILL"))
    BT_FREQUENCY = int(os.environ.get('BT_FREQUENCY'))

    EXCEPTION_DATES = [int(date_str.strip()) for date_str in open("./app/exception.csv").readline().strip().split(",") if len(date_str.strip()) != 0]
    
    for __keyy in __config:
        if __keyy == 'LOAD_US_DATA':
            continue

        if (not __keyy.startswith("LOAD_")) or (not __keyy.endswith("_DATA")):
            continue

        if int(__config[__keyy]) == 0:
            continue

        LOAD_INDEXES.append(__keyy.split("_")[1])
    
    del __config