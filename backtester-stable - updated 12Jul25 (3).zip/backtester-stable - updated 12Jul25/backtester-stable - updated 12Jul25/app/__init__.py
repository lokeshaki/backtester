
from flask import Flask
from flask_cors import CORS
from app.config import Config
from app.commons.modules import threading


def create_app():
    app = Flask(__name__)
    CORS(app)

    # Loading datata from mysql to local db
    if Config.APP_MODE == "test":
        import app.database.local as local_db
        local_db.load()
    elif Config.APP_MODE == "live":
        from app.feed import symphony as symphony
        symphony.start_feed()
        from app.broker import jainampro as jainampro
        threading.Thread(target=jainampro.run, args=()).start()
    
    # Registering blueprints
    from app.pm.routes import backtest_bp
    from app.live_execution.routes import live_execution_bp
    app.register_blueprint(backtest_bp)
    app.register_blueprint(live_execution_bp)


    return app