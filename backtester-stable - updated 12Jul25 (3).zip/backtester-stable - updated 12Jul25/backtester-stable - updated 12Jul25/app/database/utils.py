from app.commons.modules import Dict, datetime, numpy
from app.commons.constants import MAX_INT, SECONDS_IN_A_DAY, TD64S
from app.commons.enums import ENUMELEMENT, OPTIONTYPE, NSEINDEX
from app.commons.models import OHLC
from app.commons.constants import MARKET_START_TIME, MARKET_END_TIME
from app.commons.utils import get_deltas
from app.database.local import INDEX_DATA, EXPIRIES_ON_DATE, CALLS_DATA, PUTS_DATA, VIX_DATA, FUTURE_DATA, MCX_DATES, US_DATES, get_available_trading_dates
from app.database.option_chain import CALL_OPTION_CHAIN_DATA, PUT_OPTION_CHAIN_DATA, update_otion_chain
import app.api_providers.symphony as symphony
from app.config import Config
from datetime import timedelta

def get_valid_trading_dates(exchange: ENUMELEMENT, start_date: int, end_date: int) -> list:
    """
    Get available trading dates
    """

    if exchange.name in ["NSE", "BSE"]:
        return sorted(list(set(VIX_DATA.keys()) & set(range(start_date, end_date+1))))
    
    if exchange.name == "MCX":
        return sorted(list(MCX_DATES & set(range(start_date, end_date+1))))
    
    if exchange.name == "US":
        return sorted(list(US_DATES & set(range(start_date, end_date+1))))
    
    return []


def get_previous_day_vix_value(available_trading_dates: list, current_date: int, is_live: bool = False) -> int:
    """
    Get previous trading date

    Parameters:
        available_trading_dates (list): list of available trading dates
        current_date (int): current date in YYYYMMDD format
    Returns:
        int: previous trading date
    """
    try:
        if is_live:
            return symphony.get_previous_day_vix_value()
        else:
            previous_date = available_trading_dates[available_trading_dates.index(current_date) - 1]
            return VIX_DATA[previous_date]
    except IndexError:
        raise Exception(f"No previous trading date found for {current_date}")
    
def get_previous_day_closing_price(index: ENUMELEMENT, available_trading_dates: list, current_date: int, is_live: bool = False) -> int:
    if is_live:
        return symphony.get_previous_day_closing_price(index)
    else:
        previous_date = available_trading_dates[available_trading_dates.index(current_date) - 1]
        last_tick = MARKET_END_TIME[NSEINDEX.get_exchange(index.name)] - Config.BT_FREQUENCY
        ohlc = get_ohlc(index, previous_date, start_time=last_tick-Config.BT_FREQUENCY, end_time=last_tick)
        if ohlc:
            return ohlc.close
        else:
            None


def get_trading_time_stamp(exchange):
    """
    Get trading timestamp
    """
    return range(MARKET_START_TIME[exchange], MARKET_END_TIME[exchange], Config.BT_FREQUENCY)


def get_index_data_by_date(index: ENUMELEMENT, date: str) -> Dict[int, OHLC]:
    """
    Get data for a particular index and date

    Parameters:
        index (str): index name
        date (str): date in YYYY-MM-DD format
    Returns:
        dict: data for a particular index and date
    """
    try:
        return INDEX_DATA[index.name][date]
    except KeyError:
        raise Exception(f"No data found for index {index} and date {date}")


def get_available_expiry_dates(index: ENUMELEMENT, date: str) -> list:
    """
    Get available expiry dates for a particular index and date

    Parameters:
        index (str): index name
        date (str): date in YYYY-MM-DD format
    Returns:
        list: list of available expiry dates
    """

    return sorted(list(EXPIRIES_ON_DATE[index.name][date]))


def get_current_week_expiry_date(index: ENUMELEMENT, date: str, is_live: bool = False) -> str:
    """
    Get current week expiry date for a particular index and date
    For MCX instruments, returns the current month expiry (closest expiry)

    Parameters:
        index (str): index name
        date (str): date in YYYY-MM-DD format
    Returns:
        str: current week expiry date (or current month expiry for MCX)
    """
    if is_live:
        return symphony.get_current_week_expiry(index)
    else:
        # For MCX instruments, return the closest (current) monthly expiry
        if index.name in ["COPPER", "CRUDEOIL", "CRUDEOILM", "GOLD", "GOLDM", "NATGASMINI", "NATURALGAS", "NICKEL", "SILVER", "SILVERM", "ZINC"]:
            expiries = sorted(list(EXPIRIES_ON_DATE[index.name][date]))
            return expiries[0]  # Return the closest monthly expiry
        else:
            return sorted(list(EXPIRIES_ON_DATE[index.name][date]))[0]


def get_next_week_expiry_date(index: ENUMELEMENT, date: str, is_live: bool = False) -> str:
    """
    Get next week expiry date for a particular index and date

    Parameters:
        index (str): index name
        date (str): date in YYYY-MM-DD format
    Returns:
        str: next week expiry date
    """
    if is_live:
        return symphony.get_next_week_expiry(index)
    else:
        return sorted(list(EXPIRIES_ON_DATE[index.name][date]))[1]

def get_monthly_expiry_date(index: ENUMELEMENT, date: str, is_live: bool = False) -> str:
    """
    Get monthly expiry date for a particular index and date

    Parameters:
        index (str): index name
        date (str): date in YYYY-MM-DD format
    Returns:
        str: monthly expiry date
    """
    if is_live:
        return symphony.get_monthly_expiry(index)
    else:
        expiries = sorted(list(EXPIRIES_ON_DATE[index.name][date]))
        weekly_expiry = expiries[0]
        current_month = int(str(weekly_expiry)[2:4])
        for expiry_date in expiries:
            month = int(str(expiry_date)[2:4])
            if month != current_month:
                break
            monthly_expiry = expiry_date

    return monthly_expiry


def get_ohlc(
    index: ENUMELEMENT,
    date: int,
    expiry_date: str = None,
    strike_price: int = None,
    option_type: ENUMELEMENT = None,
    for_entry: bool = False,
    start_time: int = None,
    end_time: int = None,
    is_hedge: bool = False
) -> OHLC:
    """
    Get OHLC for a particular index, date, expiry date, strike price and option type

    Parameters:
        index (str): index name
        date (str): date in YYYY-MM-DD format
        expiry_date (str): expiry date in YYYY-MM-DD format
        strike_price (int): strike price
        option_type (str): option type
    Returns:
        OHLC: OHLC for a particular index, date, expiry date, strike price and option type
    """
    exchange = NSEINDEX.get_exchange(index.name)
    try:
        candles = []
        if start_time > end_time:
            start_time = end_time
        if not option_type:
            for time in range(start_time, end_time + Config.BT_FREQUENCY, Config.BT_FREQUENCY):
                if time in INDEX_DATA[index.name][date]:
                    candle = INDEX_DATA[index.name][date].get(time, None)
                    if candle:
                        candles.append(candle)
        elif option_type == OPTIONTYPE.CALL:
            for time in range(start_time, end_time + Config.BT_FREQUENCY, Config.BT_FREQUENCY):
                if time in CALLS_DATA[index.name][date]:
                    candle = None
                    try:
                        candle = CALLS_DATA[index.name][date][time][expiry_date][strike_price]
                    except KeyError:
                        pass
                    if candle:
                        candles.append(candle)
        elif option_type == OPTIONTYPE.PUT:
            for time in range(start_time, end_time + Config.BT_FREQUENCY, Config.BT_FREQUENCY):
                if time in PUTS_DATA[index.name][date]:
                    candle = None
                    try:
                        candle = PUTS_DATA[index.name][date][time][expiry_date][strike_price]
                    except KeyError:
                        pass
                    if candle:
                        candles.append(candle)
        if len(candles) == 0:
            if for_entry or start_time < MARKET_START_TIME[exchange]:
                return None
            return get_ohlc(index, date, expiry_date, strike_price, option_type, False, start_time - Config.BT_FREQUENCY, end_time - Config.BT_FREQUENCY, is_hedge)
        volume = 0
        for candle in candles:
            volume += candle.volume
        return OHLC(
            date,
            end_time,
            open=candles[0].open,
            high=max([candle.high for candle in candles]),
            low=min([candle.low for candle in candles]),
            close=candles[-1].close,
            volume=volume,
            coi= sum([candle.coi for candle in candles if candle.coi is not None])
        )
    except KeyError:
        if for_entry or start_time < MARKET_START_TIME[exchange]:
            return None
        else:
            return get_ohlc(index, date, expiry_date, strike_price, option_type, False, start_time - (end_time - start_time), end_time - (end_time - start_time), is_hedge)
        

def get_index_ohlc(index: ENUMELEMENT, date: int, start_time: int, end_time: int) -> OHLC:
    """
    Get OHLC for a particular index, date and time

    Parameters:
        index (str): index name
        date (str): date in YYYY-MM-DD format
        time (int): time in seconds
    Returns:
        OHLC: OHLC for a particular index, date and time
    """
    try:
        candles = []
        if start_time > end_time:
            start_time = end_time
        for time in range(int(start_time), int(end_time) + Config.BT_FREQUENCY, Config.BT_FREQUENCY):
            if time in INDEX_DATA[index.name][date]:
                candle = INDEX_DATA[index.name][date].get(time, None)
                if candle:
                    candles.append(candle)
        if len(candles) == 0:
            raise KeyError("No data found for index %s, date %s, start_time %s, end_time %s" % (index, date, start_time, end_time))
        return OHLC(
            date,
            end_time,
            open=candles[0].open,
            high=max([candle.high for candle in candles]),
            low=min([candle.low for candle in candles]),
            close=candles[-1].close
        )
    except KeyError:
        raise Exception(f"No data found for index {index}, date {date} and time {start_time}-{end_time}")

def get_future_ohlc(index: ENUMELEMENT, date: int, start_time: int, end_time: int) -> OHLC:
    """
    Get OHLC for a particular index, date, time and expiry date

    Parameters:
        index (str): index name
        date (str): date in YYYY-MM-DD format
        time (int): time in seconds
        expiry_date (str): expiry date in YYYY-MM-DD format
    Returns:
        OHLC: OHLC for a particular index, date, time and expiry date
    """
    exchange = NSEINDEX.get_exchange(index.name)
    try:
        candles = []
        if start_time > end_time:
            start_time = end_time
        for time in range(start_time, end_time + Config.BT_FREQUENCY, Config.BT_FREQUENCY):
            if time in FUTURE_DATA[index.name][date]:
                candle = FUTURE_DATA[index.name][date].get(time, None)
                if candle:
                    candles.append(candle)
        if len(candles) == 0:
            return get_future_ohlc(index, date, start_time - Config.BT_FREQUENCY, end_time - Config.BT_FREQUENCY)
        return OHLC(
            date,
            end_time,
            open=candles[0].open,
            high=max([candle.high for candle in candles]),
            low=min([candle.low for candle in candles]),
            close=candles[-1].close
        )
    except KeyError:
        if start_time < MARKET_START_TIME[exchange]:
            None
        else:
            return get_future_ohlc(index, date, start_time - (end_time - start_time), end_time - (end_time - start_time))

def get_closest_valid_strike_price(
    index: ENUMELEMENT,
    date: int,
    time: int,
    expiry_date: str,
    strike: float,
    option_type: ENUMELEMENT,
    is_live: bool = False
) -> float:
    
    exchange = NSEINDEX.get_exchange(index.name)
    try:
        closest_strike_price = None
        min_diff = MAX_INT
        if option_type == OPTIONTYPE.CALL:
            if is_live:
                update_otion_chain(index, OPTIONTYPE.CALL, expiry_date)
                call_data = CALL_OPTION_CHAIN_DATA[index.name][expiry_date]
            else:
                call_data = CALLS_DATA[index.name][date][time][expiry_date]
            for valid_strike in call_data:
                if abs(strike - valid_strike) < min_diff:
                    min_diff = abs(strike - valid_strike)
                    closest_strike_price = valid_strike
        elif option_type == OPTIONTYPE.PUT:
            if is_live:
                update_otion_chain(index, OPTIONTYPE.PUT, expiry_date)
                put_data = PUT_OPTION_CHAIN_DATA[index.name][expiry_date]
            else:
                put_data = PUTS_DATA[index.name][date][time][expiry_date]
            for valid_strike in put_data:
                if abs(strike - valid_strike) < min_diff:
                    min_diff = abs(strike - valid_strike)
                    closest_strike_price = valid_strike
        return closest_strike_price
    except KeyError:
        if time < MARKET_START_TIME[exchange]:
            return None
        else:
            return get_closest_valid_strike_price(index, date, time-Config.BT_FREQUENCY, expiry_date, strike, option_type)

def get_closest_strike_price(
    index: ENUMELEMENT,
    date: int,
    time: int,
    expiry_date: str,
    price: int,
    option_type: ENUMELEMENT,
    is_live: bool = False
) -> float:
    """
    Get closest strike price for a particular index, date, time, strike price and option type

    Parameters:
        index (str): index name
        date (str): date in YYYY-MM-DD format
        time (int): time in seconds
        strike_price (int): strike price
        option_type (str): option type
    Returns:
        int: closest strike price
    """
    exchange = NSEINDEX.get_exchange(index.name)
    try:
        closest_strike_price = None
        min_diff = MAX_INT
        if option_type == OPTIONTYPE.CALL:
            if is_live:
                update_otion_chain(index, OPTIONTYPE.CALL, expiry_date)
                call_data = CALL_OPTION_CHAIN_DATA[index.name][expiry_date]
            else:
                call_data = CALLS_DATA[index.name][date][time][expiry_date]
            for strike in call_data:
                strike_premium = call_data[strike].open/100.0
                if abs(price - strike_premium) < min_diff:
                    min_diff = abs(price - strike_premium)
                    closest_strike_price = strike
        elif option_type == OPTIONTYPE.PUT:
            if is_live:
                update_otion_chain(index, OPTIONTYPE.PUT, expiry_date)
                put_data = PUT_OPTION_CHAIN_DATA[index.name][expiry_date]
            else:
                put_data = PUTS_DATA[index.name][date][time][expiry_date]
            for strike in put_data:
                strike_premium = put_data[strike].open/100.0
                if abs(price - strike_premium) < min_diff:
                    min_diff = abs(price - strike_premium)
                    closest_strike_price = strike
        return closest_strike_price
    except KeyError:
        if time < MARKET_START_TIME[exchange]:
            return None
        else:
            return get_closest_strike_price(index, date, time-Config.BT_FREQUENCY, expiry_date, price, option_type)
        
def get_ge_strike_price(
    index: ENUMELEMENT,
    date: int,
    time: int,
    expiry_date: str,
    price: int,
    option_type: ENUMELEMENT,
    is_live: bool = False
) -> float:
    """
    Get closest strike price for a particular index, date, time, strike price and option type

    Parameters:
        index (str): index name
        date (str): date in YYYY-MM-DD format
        time (int): time in seconds
        strike_price (int): strike price
        option_type (str): option type
    Returns:
        int: closest strike price
    """
    exchange = NSEINDEX.get_exchange(index.name)
    try:
        closest_strike_price = None
        min_diff = MAX_INT
        if option_type == OPTIONTYPE.CALL:
            if is_live:
                update_otion_chain(index, OPTIONTYPE.CALL, expiry_date)
                call_data = CALL_OPTION_CHAIN_DATA[index.name][expiry_date]
            else:
                call_data = CALLS_DATA[index.name][date][time][expiry_date]
            for strike in call_data:
                strike_premium = call_data[strike].open/100.0
                if strike_premium > price:
                    if abs(price - strike_premium) < min_diff:
                        min_diff = abs(price - strike_premium)
                        closest_strike_price = strike
        elif option_type == OPTIONTYPE.PUT:
            if is_live:
                update_otion_chain(index, OPTIONTYPE.PUT, expiry_date)
                put_data = PUT_OPTION_CHAIN_DATA[index.name][expiry_date]
            else:
                put_data = PUTS_DATA[index.name][date][time][expiry_date]
            for strike in put_data:
                strike_premium = put_data[strike].open/100.0
                if strike_premium > price:
                    if abs(price - strike_premium) < min_diff:
                        min_diff = abs(price - strike_premium)
                        closest_strike_price = strike
        return closest_strike_price
    except KeyError:
        if time < MARKET_START_TIME[exchange]:
            return None
        else:
            return get_ge_strike_price(index, date, time-Config.BT_FREQUENCY, expiry_date, price, option_type)
        
def get_le_strike_price(
    index: ENUMELEMENT,
    date: int,
    time: int,
    expiry_date: str,
    price: int,
    option_type: ENUMELEMENT,
    is_live: bool = False
) -> float:
    """
    Get closest strike price for a particular index, date, time, strike price and option type

    Parameters:
        index (str): index name
        date (str): date in YYYY-MM-DD format
        time (int): time in seconds
        strike_price (int): strike price
        option_type (str): option type
    Returns:
        int: closest strike price
    """
    exchange = NSEINDEX.get_exchange(index.name)
    try:
        closest_strike_price = None
        min_diff = MAX_INT
        if option_type == OPTIONTYPE.CALL:
            if is_live:
                update_otion_chain(index, OPTIONTYPE.CALL, expiry_date)
                call_data = CALL_OPTION_CHAIN_DATA[index.name][expiry_date]
            else:
                call_data = CALLS_DATA[index.name][date][time][expiry_date]
            for strike in call_data:
                strike_premium = call_data[strike].open/100.0
                if strike_premium < price:
                    if abs(price - strike_premium) < min_diff:
                        min_diff = abs(price - strike_premium)
                        closest_strike_price = strike
        elif option_type == OPTIONTYPE.PUT:
            if is_live:
                update_otion_chain(index, OPTIONTYPE.PUT, expiry_date)
                put_data = PUT_OPTION_CHAIN_DATA[index.name][expiry_date]
            else:
                put_data = PUTS_DATA[index.name][date][time][expiry_date]
            for strike in put_data:
                strike_premium = put_data[strike].open/100.0
                if strike_premium < price:
                    if abs(price - strike_premium) < min_diff:
                        min_diff = abs(price - strike_premium)
                        closest_strike_price = strike
        return closest_strike_price
    except KeyError:
        if time < MARKET_START_TIME[exchange]:
            None
        else:
            return get_le_strike_price(index, date, time-Config.BT_FREQUENCY, expiry_date, price, option_type)

def get_min_diff_strike_price(
    index: ENUMELEMENT,
    date: int,
    time: int,
    expiry_date: str,
    price: int,
    option_type: ENUMELEMENT,
    is_live: bool = False
) -> float:
    """
    Get closest strike price for a particular index, date, time, strike price and option type

    Parameters:
        index (str): index name
        date (str): date in YYYY-MM-DD format
        time (int): time in seconds
        strike_price (int): strike price
        option_type (str): option type
    Returns:
        int: closest strike price
    """
    exchange = NSEINDEX.get_exchange(index.name)
    try:
        closest_strike_price = None
        min_diff = MAX_INT
        if option_type == OPTIONTYPE.CALL:
            if is_live:
                update_otion_chain(index, OPTIONTYPE.CALL, expiry_date)
                call_data = CALL_OPTION_CHAIN_DATA[index.name][expiry_date]
            else:
                call_data = CALLS_DATA[index.name][date][time][expiry_date]
            for strike in call_data:
                put_premium = None
                try:
                    temp_time = time
                    while temp_time >= MARKET_START_TIME[exchange]:
                        put_premium = PUTS_DATA[index.name][date][temp_time][expiry_date][strike].open/100.0
                        if put_premium:
                            break
                        temp_time -= 60
                except Exception as ex:
                    continue
                strike_premium = call_data[strike].open/100.0
                if abs(put_premium - strike_premium) < min_diff:
                    min_diff = abs(put_premium - strike_premium)
                    closest_strike_price = strike
        elif option_type == OPTIONTYPE.PUT:
            if is_live:
                update_otion_chain(index, OPTIONTYPE.PUT, expiry_date)
                put_data = PUT_OPTION_CHAIN_DATA[index.name][expiry_date]
            else:
                put_data = PUTS_DATA[index.name][date][time][expiry_date]
            for strike in put_data:
                call_premium = None
                try:
                    temp_time = time
                    while temp_time >= MARKET_START_TIME[exchange]:
                        call_premium = CALLS_DATA[index.name][date][temp_time][expiry_date][strike].open/100.0
                        if call_premium:
                            break
                        temp_time -= 60
                except Exception as ex:
                    continue
                strike_premium = put_data[strike].open/100.0
                if abs(call_premium - strike_premium) < min_diff:
                    min_diff = abs(call_premium - strike_premium)
                    closest_strike_price = strike
        return closest_strike_price
    except KeyError:
        if time < MARKET_START_TIME[exchange]:
            None
        else:
            return get_min_diff_strike_price(index, date, time-Config.BT_FREQUENCY, expiry_date, price, option_type)

     
def get_strike_closest_to_delta(
    index: ENUMELEMENT,
    fut_price: float,
    atm: float,
    date: int,
    time: int,
    expiry_date: str,
    delta: float,
    option_type: ENUMELEMENT,
    is_live: bool = False
) -> float:
    """
    Get closest strike price for a particular index, date, time, strike price and option type

    Parameters:
        index (str): index name
        date (str): date in YYYY-MM-DD format
        time (int): time in seconds
        strike_price (int): strike price
        option_type (str): option type
    Returns:
        int: closest strike price
    """
    exchange = NSEINDEX.get_exchange(index.name)
    try:
        closest_strike_price = None
        min_diff = MAX_INT
        if is_live:
            update_otion_chain(index, OPTIONTYPE.CALL, expiry_date)
            if option_type == OPTIONTYPE.CALL:
                opt_data = CALL_OPTION_CHAIN_DATA[index.name][expiry_date]
            else:
                opt_data = PUT_OPTION_CHAIN_DATA[index.name][expiry_date]
        else:
            if option_type == OPTIONTYPE.CALL:
                opt_data = CALLS_DATA[index.name][date][time][expiry_date]
            else:
                opt_data = PUTS_DATA[index.name][date][time][expiry_date]
        t = (numpy.datetime64(datetime.combine(datetime.strptime(str(expiry_date), "%y%m%d").date(), datetime(2021, 1, 1, 15, 30, 0).time())) - numpy.datetime64(datetime.strptime(str(int(date)), '%y%m%d')+timedelta(seconds=time))).astype(TD64S) / SECONDS_IN_A_DAY
        for strike in opt_data:
            if atm > strike:
                ohlc = get_ohlc(index, date, expiry_date, strike, OPTIONTYPE.PUT, start_time=time, end_time=time)
            else:
                ohlc = get_ohlc(index, date, expiry_date, strike, OPTIONTYPE.CALL, start_time=time, end_time=time)
            if ohlc is None:
                continue
            call_delta, put_Delta = get_deltas(fut_price, ohlc.open, strike, option_type, t)
            if option_type == OPTIONTYPE.CALL:
                if abs(call_delta - delta) < min_diff:
                    min_diff = abs(call_delta - delta)
                    closest_strike_price = strike
            elif option_type == OPTIONTYPE.PUT:
                if abs(put_Delta - delta) < min_diff:
                    min_diff = abs(put_Delta - delta)
                    closest_strike_price = strike
        return closest_strike_price
    except KeyError:
        if time < MARKET_START_TIME[exchange]:
            None
        else:
            return get_strike_closest_to_delta(index, fut_price, atm, date, time-Config.BT_FREQUENCY, expiry_date, delta, option_type, is_live)
        
        
def get_strike_ge_delta(
    index: ENUMELEMENT,
    fut_price: float,
    atm: float,
    date: int,
    time: int,
    expiry_date: str,
    delta: float,
    option_type: ENUMELEMENT,
    is_live: bool = False
) -> float:
    """
    Get closest strike price for a particular index, date, time, strike price and option type

    Parameters:
        index (str): index name
        date (str): date in YYYY-MM-DD format
        time (int): time in seconds
        strike_price (int): strike price
        option_type (str): option type
    Returns:
        int: closest strike price
    """
    exchange = NSEINDEX.get_exchange(index.name)
    try:
        closest_strike_price = None
        min_diff = MAX_INT
        if is_live:
            update_otion_chain(index, OPTIONTYPE.CALL, expiry_date)
            if option_type == OPTIONTYPE.CALL:
                opt_data = CALL_OPTION_CHAIN_DATA[index.name][expiry_date]
            else:
                opt_data = PUT_OPTION_CHAIN_DATA[index.name][expiry_date]
        else:
            if option_type == OPTIONTYPE.CALL:
                opt_data = CALLS_DATA[index.name][date][time][expiry_date]
            else:
                opt_data = PUTS_DATA[index.name][date][time][expiry_date]
        t = (numpy.datetime64(datetime.combine(datetime.strptime(str(expiry_date), "%y%m%d").date(), datetime(2021, 1, 1, 15, 30, 0).time())) - numpy.datetime64(datetime.strptime(str(int(date)), '%y%m%d')+timedelta(seconds=time))).astype(TD64S) / SECONDS_IN_A_DAY
        for strike in opt_data:
            if atm > strike:
                ohlc = get_ohlc(index, date, expiry_date, strike, OPTIONTYPE.PUT, start_time=time, end_time=time)
            else:
                ohlc = get_ohlc(index, date, expiry_date, strike, OPTIONTYPE.CALL, start_time=time, end_time=time)
            if ohlc is None:
                continue
            call_delta, put_Delta = get_deltas(fut_price, ohlc.open, strike, option_type, t)
            if option_type == OPTIONTYPE.CALL:
                if call_delta > delta:
                    if abs(call_delta - delta) < min_diff:
                        min_diff = abs(call_delta - delta)
                        closest_strike_price = strike
            elif option_type == OPTIONTYPE.PUT:
                if put_Delta > delta:
                    if abs(put_Delta - delta) < min_diff:
                        min_diff = abs(put_Delta - delta)
                        closest_strike_price = strike
        return closest_strike_price
    except KeyError:
        if time < MARKET_START_TIME[exchange]:
            None
        else:
            return get_strike_ge_delta(index, fut_price, date, time-Config.BT_FREQUENCY, expiry_date, delta, option_type, is_live)
        
def get_strike_le_delta(
    index: ENUMELEMENT,
    fut_price: float,
    atm: float,
    date: int,
    time: int,
    expiry_date: str,
    delta: float,
    option_type: ENUMELEMENT,
    is_live: bool = False
) -> float:
    """
    Get closest strike price for a particular index, date, time, strike price and option type

    Parameters:
        index (str): index name
        date (str): date in YYYY-MM-DD format
        time (int): time in seconds
        strike_price (int): strike price
        option_type (str): option type
    Returns:
        int: closest strike price
    """
    exchange = NSEINDEX.get_exchange(index.name)
    try:
        closest_strike_price = None
        min_diff = MAX_INT
        if is_live:
            update_otion_chain(index, OPTIONTYPE.CALL, expiry_date)
            if option_type == OPTIONTYPE.CALL:
                opt_data = CALL_OPTION_CHAIN_DATA[index.name][expiry_date]
            else:
                opt_data = PUT_OPTION_CHAIN_DATA[index.name][expiry_date]
        else:
            if option_type == OPTIONTYPE.CALL:
                opt_data = CALLS_DATA[index.name][date][time][expiry_date]
            else:
                opt_data = PUTS_DATA[index.name][date][time][expiry_date]
        t = (numpy.datetime64(datetime.combine(datetime.strptime(str(expiry_date), "%y%m%d").date(), datetime(2021, 1, 1, 15, 30, 0).time())) - numpy.datetime64(datetime.strptime(str(int(date)), '%y%m%d')+timedelta(seconds=time))).astype(TD64S) / SECONDS_IN_A_DAY
        for strike in opt_data:
            if atm > strike:
                ohlc = get_ohlc(index, date, expiry_date, strike, OPTIONTYPE.PUT, start_time=time, end_time=time)
            else:
                ohlc = get_ohlc(index, date, expiry_date, strike, OPTIONTYPE.CALL, start_time=time, end_time=time)
            if ohlc is None:
                continue
            call_delta, put_Delta = get_deltas(fut_price, ohlc.open, strike, option_type, t)
            if option_type == OPTIONTYPE.CALL:
                if call_delta < delta:
                    if abs(call_delta - delta) < min_diff:
                        min_diff = abs(call_delta - delta)
                        closest_strike_price = strike
            elif option_type == OPTIONTYPE.PUT:
                if put_Delta < delta:
                    if abs(put_Delta - delta) < min_diff:
                        min_diff = abs(put_Delta - delta)
                        closest_strike_price = strike
        return closest_strike_price
    except KeyError:
        if time < MARKET_START_TIME[exchange]:
            None
        else:
            return get_strike_le_delta(index, fut_price, date, time-Config.BT_FREQUENCY, expiry_date, delta, option_type, is_live)
