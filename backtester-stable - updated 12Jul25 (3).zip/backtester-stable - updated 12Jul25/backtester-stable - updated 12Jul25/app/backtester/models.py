from typing import List
from app.commons.models import Order

class ResultTrade:
    def __init__(
        self,
        strategy_entry_number,
        strategy_name,
        leg_id,
        entry_number,
        stop_loss_entry_number,
        take_profit_entry_number,
        symbol,
        expiry,
        strike,
        option_type,
        side,
        qty,
        entry_time,
        entry_price,
        exit_time,
        exit_price,
        pnl,
        reason,
        max_profit,
        max_loss,
        index_entry_price,
        index_exit_price
    ):
        self.strategy_entry_number = strategy_entry_number
        self.strategy_name = strategy_name
        self.leg_id = leg_id
        self.entry_number = entry_number
        self.stop_loss_entry_number = stop_loss_entry_number
        self.take_profit_entry_number = take_profit_entry_number
        self.symbol = symbol
        self.expiry = expiry
        self.strike = strike
        self.option_type = option_type
        self.side = side
        self.qty = qty
        self.entry_time = entry_time
        self.entry_price = entry_price
        self.exit_time = exit_time
        self.exit_price = exit_price
        self.pnl = pnl
        self.reason = reason
        self.max_profit = max_profit
        self.max_loss = max_loss
        self.index_entry_price = index_entry_price
        self.index_exit_price = index_exit_price
        
    def __repr__(self):
        return "<ResultTrede %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s>" % (
            self.strategy_entry_number,
            self.leg_id,
            self.entry_number,
            self.stop_loss_entry_number,
            self.take_profit_entry_number,
            self.symbol,
            self.expiry,
            self.strike,
            self.option_type,
            self.side,
            self.qty,
            self.entry_time,
            self.entry_price,
            self.exit_time,
            self.exit_price,
            self.pnl,
            self.reason,
            self.max_profit,
            self.max_loss,
            self.index_entry_price,
            self.index_exit_price
        )
        
    def to_json(self):
        return {
            "strategy_entry_number": self.strategy_entry_number,
            "strategy_name": self.strategy_name,
            "leg_id": self.leg_id,
            "entry_number": self.entry_number,
            "stop_loss_entry_number": self.stop_loss_entry_number,
            "take_profit_entry_number": self.take_profit_entry_number,
            "symbol": self.symbol.name,
            "expiry": self.expiry,
            "strike": self.strike,
            "option_type": self.option_type.name,
            "side": self.side.name,
            "qty": self.qty,
            "entry_time": self.entry_time,
            "entry_price": self.entry_price,
            "exit_time": self.exit_time,
            "exit_price": self.exit_price,
            "pnl": self.pnl,
            "reason": self.reason,
            "max_profit": self.max_profit,
            "max_loss": self.max_loss,
            "index_entry_price": self.index_entry_price,
            "index_exit_price": self.index_exit_price
        }

class BacktestResult:
    def __init__(
        self,
        backtest_id,
        pnl,
        max_drawdown,
        win_percentage,
        loss_percentage,
        max_win_streak,
        max_loss_streak,
        total_number_of_trades,
        time_taken,
        orders: List[ResultTrade],
        strategy_profits,
        strategy_losses
    ):
        self.backtest_id = backtest_id
        self.pnl = pnl
        self.max_drawdown = max_drawdown
        self.win_percentage = win_percentage
        self.loss_percentage = loss_percentage
        self.max_win_streak = max_win_streak
        self.max_loss_streak = max_loss_streak
        self.total_number_of_trades = total_number_of_trades
        self.time_taken = time_taken
        self.orders = orders
        self.strategy_profits = strategy_profits
        self.strategy_losses = strategy_losses

    def __repr__(self):
        return "<BacktestResult %s %s %s %s %s %s %s %s %s>" % (
            self.backtest_id,
            self.pnl,
            self.max_drawdown,
            self.win_percentage,
            self.loss_percentage,
            self.max_win_streak,
            self.max_loss_streak,
            self.total_number_of_trades,
            self.time_taken
        )
        
    def to_json(self):
        return {
            "backtest_id": self.backtest_id,
            "pnl": self.pnl,
            "max_drawdown": self.max_drawdown,
            "win_percentage": self.win_percentage,
            "loss_percentage": self.loss_percentage,
            "max_win_streak": self.max_win_streak,
            "max_loss_streak": self.max_loss_streak,
            "total_number_of_trades": self.total_number_of_trades,
            "time_taken": self.time_taken,
            "orders": [order.to_json() for order in self.orders],
            "strategy_profits": self.strategy_profits,
            "strategy_losses": self.strategy_losses
        }
