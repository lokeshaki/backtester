from time import time
from app.commons.modules import logging, Dict
from app.commons.enums import (
    STRATEGYSTATUS,
    ENUMELEMENT,
    STRIKESELECTIONTYPE,
    FEEDSOURCE,
    BROKER,
)

from app.parser.models import VwapStrategy, Strategy
from app.database.utils import (
    get_available_trading_dates,
    get_trading_time_stamp,
    get_current_week_expiry_date,
)
from app.evaluator.vwap_ema import evaluate_vwap_strategy
from app.evaluator import evaluate_strategy
from app.evaluator.utils import tb_strategy_day_reset, vwap_strategy_day_reset
from app.backtester.utils import generate_backtest_result

logger = logging.getLogger(__name__)


def run_backtest(
    strategy: Strategy,
    start_date: int,
    end_date: int,
    index_base_price: float,
    fix_vix: float,
    broker_details: Dict,
    exchange: ENUMELEMENT,
    product_type: ENUMELEMENT,
    order_type: ENUMELEMENT,
):
    """
    Run backtest for given strategy
    :param strategy: Strategy object
    :return: None
    """
    backtest_start_time = time()
    current_date = start_date
    orders = []
    broker = eval(broker_details.get("broker"))
    client_id = broker_details.get("client_id")
    trading_timestamps = get_trading_time_stamp(exchange=exchange.name)
    all_trading_dates = get_available_trading_dates(
        index=strategy.index, start_date=180101, end_date=300101
    )
    available_trading_dates_for_looping = get_available_trading_dates(
        strategy.index, start_date, end_date
    )

    if all_trading_dates == available_trading_dates_for_looping:
        for leg in strategy.legs:
            if leg.strike_selection.type == STRIKESELECTIONTYPE.BY_DYNAMIC_FACTOR:
                available_trading_dates_for_looping = all_trading_dates[1:]
                break

    for current_date in available_trading_dates_for_looping:
        strategy.status = STRATEGYSTATUS.CREATED
        
        # Handle DTE calculation differently for MCX vs NSE/BSE
        if strategy.dte != None:
            if strategy.index.name in ["COPPER", "CRUDEOIL", "CRUDEOILM", "GOLD", "GOLDM", "NATGASMINI", "NATURALGAS", "NICKEL", "SILVER", "SILVERM", "ZINC"]:
                # MCX instruments: Use monthly expiry dates
                try:
                    from app.database.local import EXPIRIES_ON_DATE
                    
                    # If DTE >= 30, run on all days
                    if strategy.dte >= 30:
                        pass  # Don't skip any days, run on all trading days
                    else:
                        # If DTE < 30, run only on specific days (DTE days before expiry)
                        # For MCX, use the first leg's expiry_type to determine which expiry
                        if strategy.legs and len(strategy.legs) > 0:
                            first_leg = strategy.legs[0]
                            # MCX typically uses MONTHLY expiry, but check the leg's expiry_type
                            if hasattr(first_leg, 'expiry_type') and first_leg.expiry_type.name == "NEXT_WEEKLY":
                                # Use next month expiry
                                expiries = sorted(list(EXPIRIES_ON_DATE[strategy.index.name][current_date]))
                                target_expiry = expiries[1] if len(expiries) > 1 else expiries[0]
                            else:
                                # Default to current month expiry (WEEKLY or MONTHLY for MCX)
                                target_expiry = sorted(list(EXPIRIES_ON_DATE[strategy.index.name][current_date]))[0]
                        else:
                            # Fallback to current month if no legs
                            target_expiry = sorted(list(EXPIRIES_ON_DATE[strategy.index.name][current_date]))[0]
                        
                        # Calculate DTE: days between current_date and target_expiry
                        date_index = all_trading_dates.index(current_date)
                        expiry_index = all_trading_dates.index(target_expiry)
                        
                        if strategy.dte != (expiry_index - date_index):
                            continue
                        
                except (KeyError, IndexError, ValueError):
                    continue  # Skip if no expiry data available or date not found
            else:
                # NSE/BSE instruments: Original weekly expiry logic
                weekly_expiry = get_current_week_expiry_date(
                    strategy.index, current_date, False
                )
                if strategy.dte != (weekly_expiry - current_date):
                    continue
        try:
            for trading_timestamp in trading_timestamps:

                evaluate_strategy(
                    strategy,
                    current_date,
                    trading_timestamp,
                    index_base_price,
                    fix_vix,
                    broker,
                    client_id,
                    exchange,
                    product_type,
                    order_type,
                    orders,
                    all_trading_dates,
                    FEEDSOURCE.HISTORICAL,
                )

        except Exception as ex:
            logger.info(
                "Exception occured while backtesting, for date %s", current_date
            )
            logger.exception(ex)
        strategy.take_profit_reentry_remaining = (
            strategy.take_profit_reentry.value.count
        )
        strategy.stop_loss_reentry_remaining = strategy.stop_loss_reentry.value.count
        strategy.entry_number = 0
        strategy.is_first_entry = True
        tb_strategy_day_reset(strategy)
        strategy.status = STRATEGYSTATUS.RUNNING
        strategy.entry_indicator_triggered = False
        strategy.last_stop_loss_check_time = strategy.entry_time
        strategy.last_take_profit_check_time = strategy.entry_time
        strategy.last_stop_loss_reentry_check_time = strategy.entry_time
        strategy.last_take_profit_reentry_check_time = strategy.entry_time
        strategy.entry_combined_premium = 0
        strategy.box_take_profit_reentry_remaining = (
            strategy.box_take_profit_reentry.value.count
        )
        strategy.box_stop_loss_reentry_remaining = (
            strategy.box_stop_loss_reentry.value.count
        )
        strategy.rsi_reentry_remaining = strategy.rsi_reentry.value.count
        strategy.sqaareoff_reentry_remaining = strategy.squareoff_reentry.value.count
        strategy.is_any_leg_exited = False
        strategy.is_any_leg_sl_hit = False
        strategy.next_reentry_check_time = 0
        strategy.can_trail = False
        strategy.current_stop_loss = strategy.stop_loss.value
        strategy.realized_pnl = 0
        for leg in strategy.legs:
            if leg.orb is not None:
                leg.orb.high_range = None
                leg.orb.low_range = None
                leg.orb.is_set = False
            leg.is_first_entry = True
        # current_date += 1
    return generate_backtest_result(
        backtest_start_time, orders, strategy.tick_profits, strategy.tick_losses
    )


def run_vwap_backtest(
    strategy: VwapStrategy,
    start_date: int,
    end_date: int,
    index_base_price: float,
    fix_vix: float,
    broker_details: Dict,
    exchange: ENUMELEMENT,
    product_type: ENUMELEMENT,
    order_type: ENUMELEMENT,
):
    """
    Run backtest for given strategy
    :param strategy: Strategy object
    :return: None
    """
    backtest_start_time = time()
    current_date = start_date
    orders = []
    broker = eval(broker_details.get("broker"))
    client_id = broker_details.get("client_id")
    trading_timestamps = get_trading_time_stamp(exchange=exchange.name)
    all_trading_dates = get_available_trading_dates(
        index=strategy.index, start_date=180101, end_date=300101
    )
    available_trading_dates_for_looping = get_available_trading_dates(
        strategy.index, start_date, end_date
    )

    if all_trading_dates == available_trading_dates_for_looping:
        for leg in strategy.legs:
            if leg.strike_selection.type == STRIKESELECTIONTYPE.BY_DYNAMIC_FACTOR:
                available_trading_dates_for_looping = all_trading_dates[1:]
                break

    for current_date in available_trading_dates_for_looping:
        strategy.status = STRATEGYSTATUS.CREATED
        
        # Handle DTE calculation differently for MCX vs NSE/BSE
        if strategy.dte != None:
            if strategy.index.name in ["COPPER", "CRUDEOIL", "CRUDEOILM", "GOLD", "GOLDM", "NATGASMINI", "NATURALGAS", "NICKEL", "SILVER", "SILVERM", "ZINC"]:
                # MCX instruments: Use monthly expiry dates
                try:
                    from app.database.local import EXPIRIES_ON_DATE
                    
                    # If DTE >= 30, run on all days
                    if strategy.dte >= 30:
                        pass  # Don't skip any days, run on all trading days
                    else:
                        # If DTE < 30, run only on specific days (DTE days before expiry)
                        # For MCX, use the first leg's expiry_type to determine which expiry
                        if strategy.legs and len(strategy.legs) > 0:
                            first_leg = strategy.legs[0]
                            # MCX typically uses MONTHLY expiry, but check the leg's expiry_type
                            if hasattr(first_leg, 'expiry_type') and first_leg.expiry_type.name == "NEXT_WEEKLY":
                                # Use next month expiry
                                expiries = sorted(list(EXPIRIES_ON_DATE[strategy.index.name][current_date]))
                                target_expiry = expiries[1] if len(expiries) > 1 else expiries[0]
                            else:
                                # Default to current month expiry (WEEKLY or MONTHLY for MCX)
                                target_expiry = sorted(list(EXPIRIES_ON_DATE[strategy.index.name][current_date]))[0]
                        else:
                            # Fallback to current month if no legs
                            target_expiry = sorted(list(EXPIRIES_ON_DATE[strategy.index.name][current_date]))[0]
                        
                        # Calculate DTE: days between current_date and target_expiry
                        date_index = all_trading_dates.index(current_date)
                        expiry_index = all_trading_dates.index(target_expiry)
                        
                        if strategy.dte != (expiry_index - date_index):
                            continue
                        
                except (KeyError, IndexError, ValueError):
                    continue  # Skip if no expiry data available or date not found
            else:
                # NSE/BSE instruments: Original weekly expiry logic
                weekly_expiry = get_current_week_expiry_date(
                    strategy.index, current_date, False
                )
                if strategy.dte != (weekly_expiry - current_date):
                    continue
        try:
            for trading_timestamp in trading_timestamps:

                evaluate_vwap_strategy(
                    strategy,
                    current_date,
                    trading_timestamp,
                    index_base_price,
                    fix_vix,
                    broker,
                    client_id,
                    exchange,
                    product_type,
                    order_type,
                    orders,
                    all_trading_dates,
                    FEEDSOURCE.HISTORICAL,
                )
            strategy.not_first_day = True
        except Exception as ex:
            logger.info(
                "Exception occured while backtesting, for date %s", current_date
            )
            logger.exception(ex)
        strategy.take_profit_reentry_remaining = (
            strategy.take_profit_reentry.value.count
        )
        strategy.stop_loss_reentry_remaining = strategy.stop_loss_reentry.value.count
        strategy.indicator_based_reentry_remaining = strategy.indicator_based_reentry.value.count
        strategy.entry_number = 0
        strategy.is_first_entry = True
        vwap_strategy_day_reset(strategy)
        strategy.status = STRATEGYSTATUS.RUNNING
        strategy.entry_indicator_triggered = False
        strategy.last_stop_loss_check_time = strategy.entry_time
        strategy.last_take_profit_check_time = strategy.entry_time
        strategy.last_stop_loss_reentry_check_time = strategy.entry_time
        strategy.last_take_profit_reentry_check_time = strategy.entry_time
        strategy.entry_combined_premium = 0
        strategy.is_any_leg_exited = False
        strategy.next_reentry_check_time = 0
        strategy.can_trail = False
        strategy.current_stop_loss = strategy.stop_loss.value
        strategy.realized_pnl = 0
        strategy.ready_to_enter = False
        for leg in strategy.legs:
            leg.is_contracterized_before = False
            
        # current_date += 1
    return generate_backtest_result(
        backtest_start_time, orders, strategy.tick_profits, strategy.tick_losses
    )
