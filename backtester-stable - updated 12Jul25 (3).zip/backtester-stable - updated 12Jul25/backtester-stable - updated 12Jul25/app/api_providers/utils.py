from app.commons.modules import datetime, timedelta
from app.commons.utils import date_1980

def from_exchange_timestamp(timestamp: int) -> datetime:
    """
    Convert timestamp from exchange to datetime object

    Parameters:
        timestamp (int): timestamp 
    Returns:
        datetime: datetime object
    """
    return date_1980() + timedelta(seconds=timestamp)