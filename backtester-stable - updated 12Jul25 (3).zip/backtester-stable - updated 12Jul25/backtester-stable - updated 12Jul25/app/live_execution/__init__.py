from app.commons.enums import *
from app.parser.models import Strategy
from app.commons.modules import Dict, sleep
from app.commons.utils import int_date, int_time, now
from app.broker import broker_login
from app.evaluator import evaluate_strategy

def run_live_execution(strategy: Strategy,
    start_date: int,
    end_date: int,
    index_base_price: float,
    fix_vix: float,
    broker_details: Dict,
    exchange: ENUMELEMENT,
    product_type: ENUMELEMENT,
    order_type: ENUMELEMENT,
    feed_source: ENUMELEMENT):
    broker_login(**broker_details)
    broker = eval(broker_details.get('broker'))
    client_id = broker_details.get('client_id')
    current_date = int_date(now())
    available_trading_dates = [int_date(now())]
    orders = []
    while True:
        trading_timestamp = int_time(now())
        evaluate_strategy(strategy, current_date, trading_timestamp, index_base_price, fix_vix, broker, client_id, exchange, product_type, order_type, orders, available_trading_dates, feed_source, True)
        sleep(1)
        