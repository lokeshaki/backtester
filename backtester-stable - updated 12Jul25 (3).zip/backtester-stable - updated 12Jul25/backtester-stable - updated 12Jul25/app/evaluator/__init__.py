from app.commons.enums import NUMBERTYPE, ENUMELEMENT, SIDE, STRATEGYSTATUS, LEGSTATUS, ORDERSTATUS, REENTRYTYPE, OPTIONTYPE, UNDERLYINGTYPE, FORCEENTRYTYPE, ORBBREAKOUTTYPE
from app.commons.models import TimeStamp
from app.commons.modules import logging
from app.commons.constants import MARKET_START_TIME
from app.commons.utils import reverse_side, get_strike_diff_for_index, round_to
from app.evaluator import utils as utils
from app.evaluator.utils import (
    calculate_current_pnl,
    is_stop_loss_hit,
    is_take_profit_hit,
    is_stg_profit_hit,
    is_stg_stop_loss_hit,
    is_box_stop_loss_hit,
    is_box_take_profit_hit,
    is_box_diff_hit,
    calculate_box_diff_points,
    get_pnl_dict,
    evaluate_leg_entry,
    evaluate_leg_exit,
    get_underlying_ohlc,
    is_box_created,
    contractrize_leg,
    contractrize_vwap_leg,
    get_combined_candle,
    eval_indicators,
    get_rsi,
    get_heikin_ashi,
    to_timeindex,
    place_hedge_exit_order,
    place_exit_order,
    running_leg_count,
    remove_spawned_legs,
    reset_leg,
    tb_strategy_reentry_reset,
    tb_strategy_day_reset,
    vwap_strategy_reentry_reset,
    vwap_strategy_day_reset,
    portfolio_day_reset,
    trail_sl,
    trail_stg_sl,
    is_sl_hit,
    is_tp_hit,
    is_lock_is_triggered,
    calculate_stop_loss_points,
    calculate_take_profit_points,
    calculate_trailing_stop_loss_points,
    calculate_wait_points,
    calculate_how_much_stop_loss_should_move,
    stop_loss_update,
    is_waiting_is_over,
    calculate_current_pnl,
    get_monthly_expiry_date,
    get_previous_day_closing_price,
    get_previous_day_vix_value,
    get_closest_strike_price,
    get_ge_strike_price,
    get_le_strike_price,
    get_strike_closest_to_delta,
    get_strike_ge_delta,
    get_strike_le_delta,
    get_closest_valid_strike_price,
    get_min_diff_strike_price,
    get_quote,
    get_candles,
    place_order,
    round_to,
    get_strike_diff_for_index,
    get_deltas,
    reverse_side,
    datetime,
    sign,
    get_current_week_expiry_date,
    get_next_week_expiry_date,
    get_monthly_expiry_date,
    get_closest_strike_price,
    get_ge_strike_price,
    get_le_strike_price,
    get_previous_day_vix_value,
    get_previous_day_closing_price,
    get_strike_closest_to_delta,
    get_strike_ge_delta,
    get_strike_le_delta,
    get_closest_valid_strike_price,
    get_min_diff_strike_price,
)
from app.parser.models import Strategy
from app.commons.models import Order
from app.broker import place_order
from app.feed import get_quote
from app.database.utils import get_monthly_expiry_date
from app.config import Config


logger = logging.getLogger(__name__)


def get_hedge_exit_price(strategy, hedge_ohlc, leg):
    """
    Helper function to calculate hedge exit price based on PnL calculation type
    """
    if strategy.pnl_calculation_from == "OPEN":
        return hedge_ohlc.open/100.0
    elif strategy.pnl_calculation_from == "CLOSE":
        return hedge_ohlc.close/100.0
    elif strategy.pnl_calculation_from == "HIGH":
        return hedge_ohlc.high/100.0
    elif strategy.pnl_calculation_from == "LOW":
        return hedge_ohlc.low/100.0
    else:
        # Default behavior for any other value
        return hedge_ohlc.low/100.0 if leg.hedge.side == SIDE.BUY else hedge_ohlc.high/100.0


def evaluate_strategy(strategy: Strategy, current_date: int, trading_timestamp: int, index_base_price: float, fix_vix: float, broker: str, client_id: str, exchange: ENUMELEMENT, product_type: ENUMELEMENT, order_type: ENUMELEMENT, orders: list, available_trading_dates: list, feed_source: ENUMELEMENT, is_live: bool=False):
    
    if strategy.entry_date and strategy.exit_date:
        if (current_date < strategy.entry_date and current_date > strategy.exit_date):
            return
        else:
            entry_time = int(str(strategy.entry_date)+str(strategy.entry_time))
            exit_time = int(str(strategy.exit_date)+str(strategy.exit_time))
    else:
        entry_time = int(str(current_date)+str(strategy.entry_time))
        exit_time = int(str(current_date)+str(strategy.exit_time))
    
    timestamp = int(str(current_date)+str(trading_timestamp))
    monthly_expiry = None
    tick_pnl = 0

    if is_time_for_entry(timestamp, entry_time):
        previous_date = available_trading_dates[available_trading_dates.index(current_date)-1]
        for leg in strategy.legs:
            leg.is_wait_in_time_updated = False
        if (strategy.status == STRATEGYSTATUS.CREATED or strategy.status == STRATEGYSTATUS.RUNNING) and strategy.next_reentry_check_time <= trading_timestamp:
            strategy.next_reentry_check_time = 0
            strike_diff = get_strike_diff_for_index(strategy.index)
            if strategy.entry_rsi:
                check_interval = strategy.entry_rsi.interval
            else:
                check_interval = 0
            if strategy.underlying == UNDERLYINGTYPE.FUTURE:
                monthly_expiry = get_monthly_expiry_date(strategy.index, current_date, is_live)
                index_ohlc = get_quote(feed_source, strategy.index, current_date,trading_timestamp - check_interval, trading_timestamp, option_type=OPTIONTYPE.FUT, expiry=monthly_expiry)
            elif strategy.underlying == UNDERLYINGTYPE.CASH:
                index_ohlc = get_quote(feed_source, strategy.index, current_date, trading_timestamp - check_interval, trading_timestamp)
            index_price = index_ohlc.open/100.0
            atm = round_to(index_price, strike_diff)
            
            if strategy.box and strategy.is_first_entry:
                if len(strategy.legs) != 2:
                    raise Exception("Box strategy should have 2 legs")
                for leg in strategy.legs:
                    if leg.status != LEGSTATUS.CONTRACTRIZED or not strategy.box.contractrize_only_once:
                        contractrize_leg(strategy.index, index_base_price, index_price, fix_vix, available_trading_dates, current_date, trading_timestamp, atm, strike_diff, exchange, leg, is_live, feed_source)
                        
                    if leg.status == LEGSTATUS.CONTRACTRIZED:
                        leg.contract.ltp = get_quote(feed_source, leg.contract.symbol, current_date, trading_timestamp, trading_timestamp, leg.contract.expiry_date, leg.contract.strike_price, leg.contract.option_type).open/100
                is_all_leg_contractrized = all([leg.status == LEGSTATUS.CONTRACTRIZED for leg in strategy.legs])
                if is_all_leg_contractrized:
                    strategy.current_box_diff = calculate_box_diff_points(strategy.legs[0].contract.ltp, strategy.legs[1].contract.ltp, strategy.box.diff)
                    if is_box_diff_hit(strategy.legs[0].contract.ltp, strategy.legs[1].contract.ltp, strategy.current_box_diff):
                        strategy.is_first_entry = False
                    if strategy.box.duration <= trading_timestamp:
                        if strategy.box.force_entry:
                            if strategy.box.force_entry_type == FORCEENTRYTYPE.HIGHER_PREMIUM:
                                if strategy.legs[0].contract.ltp > strategy.legs[1].contract.ltp:
                                    premium = strategy.legs[0].contract.ltp
                                    contractrize_leg(strategy.index, index_base_price, index_price, fix_vix, available_trading_dates, current_date, trading_timestamp, atm, strike_diff, exchange, strategy.legs[1], is_live, feed_source, True, premium)
                                    strategy.is_first_entry = False
                                else:
                                    premium = strategy.legs[1].contract.ltp
                                    contractrize_leg(strategy.index, index_base_price, index_price, fix_vix, available_trading_dates, current_date, trading_timestamp, atm, strike_diff, exchange, strategy.legs[0], is_live, feed_source, True, premium)
                                    strategy.is_first_entry = False
                            else:
                                if strategy.legs[0].contract.ltp < strategy.legs[1].contract.ltp:
                                    premium = strategy.legs[0].contract.ltp
                                    contractrize_leg(strategy.index, index_base_price, index_price, fix_vix, available_trading_dates, current_date, trading_timestamp, atm, strike_diff, exchange, strategy.legs[1], is_live, feed_source, True, premium)
                                    strategy.is_first_entry = False
                                else:
                                    premium = strategy.legs[1].contract.ltp
                                    contractrize_leg(strategy.index, index_base_price, index_price, fix_vix, available_trading_dates, current_date, trading_timestamp, atm, strike_diff, exchange, strategy.legs[0], is_live, feed_source, True, premium)
                                    strategy.is_first_entry = False
                        else:
                            strategy.status = STRATEGYSTATUS.STOPPED
                            
                if strategy.is_first_entry:
                    return
            
            if strategy.entry_rsi and not strategy.entry_indicator_triggered:
                can_make_full_candle = (trading_timestamp - MARKET_START_TIME[exchange.name])%strategy.entry_rsi.interval == 0
                if  can_make_full_candle:
                    current_rsi = get_rsi(strategy.index,strategy.entry_rsi, current_date, previous_date, trading_timestamp, is_live)
                    if current_rsi and is_rsi_trigggered(strategy.entry_rsi, current_rsi):
                        strategy.entry_indicator_triggered = True
            else:
                strategy.entry_indicator_triggered = True
            if strategy.entry_indicator_triggered:
                for leg in strategy.legs:
                    if strategy.concurrent_legs <= running_leg_count(strategy.legs):
                        break
                    evaluate_leg_entry(strategy, leg, timestamp, exit_time, index_base_price, index_price, fix_vix, available_trading_dates, current_date, trading_timestamp, atm, strike_diff, exchange, is_live, feed_source, orders, broker, client_id, order_type, product_type)
        
        if strategy.status == STRATEGYSTATUS.RUNNING:
            strategy_profits = [sum([leg.realized_pnl for leg in strategy.legs])]
            strategy_losses = [sum([leg.realized_pnl for leg in strategy.legs])]
            is_stop_loss_check_time_update = False
            is_take_profit_check_time_update = False
            
            for leg in strategy.legs:
                is_stop_loss_check_time_update, is_take_profit_check_time_update = evaluate_leg_exit(strategy,  leg, current_date, timestamp, trading_timestamp, exit_time, index_price, index_base_price, fix_vix, atm, strike_diff, monthly_expiry, available_trading_dates, strategy_profits, strategy_losses,order_type, product_type, broker, client_id, orders, exchange, feed_source, is_live)
            
            strategy_profit = sum(strategy_profits)
            strategy_loss = sum(strategy_losses)           
                        
            if strategy.is_any_leg_sl_hit == True and strategy.move_sl_to_cost:
                for leg in strategy.legs:
                    if leg.current_stop_loss != None:
                        leg.current_stop_loss = 0.001
                        strategy.is_any_leg_sl_hit = False
                        
            if is_stop_loss_check_time_update:
                strategy.last_stop_loss_check_time = trading_timestamp
            if is_take_profit_check_time_update:
                strategy.last_take_profit_check_time = trading_timestamp

            if strategy.lock_and_trail.lock:
                if not strategy.can_trail and is_lock_is_triggered(strategy_profit, strategy.lock_and_trail.lock):
                    strategy.is_lock_is_triggerd = True
                    strategy.current_stop_loss = strategy.lock_and_trail.trail
                    strategy.can_trail = True
            else:
                if not strategy.can_trail:
                    strategy.can_trail = True
            
            if strategy.can_trail:
                trail_stg_sl(strategy, strategy_profit)
                
                
            if is_box_stop_loss_hit(strategy.entry_combined_premium, strategy_loss, strategy.legs[0].quantity, strategy.box_stop_loss):
                strategy.status = STRATEGYSTATUS.BOX_SL_HIT
                for leg in strategy.legs:
                    if leg.status in [LEGSTATUS.ENTERED, LEGSTATUS.EXIT_TRIGGERED]:
                        if leg.hedge:
                            if leg.hedge.entry_order:
                                if leg.hedge.entry_order.status == ORDERSTATUS.COMPLETE:
                                    hedge_ohlc = get_quote(
                                        feed_source,
                                        leg.hedge.entry_order.contract.symbol,
                                        current_date,
                                        strategy.entry_time,
                                        trading_timestamp,
                                        leg.hedge.entry_order.contract.expiry_date,
                                        leg.hedge.entry_order.contract.strike_price,
                                        leg.hedge.entry_order.contract.option_type,
                                        is_hedge=True,
                                    )
                                    if hedge_ohlc:
                                        exit_price = get_hedge_exit_price(strategy, hedge_ohlc, leg)
                                        place_hedge_exit_order(strategy, leg, product_type, order_type, current_date, trading_timestamp, index_price, broker, client_id, "Stg Box Stop Loss Hedge Exit", orders)
                                    else:
                                        continue
                                else:
                                    leg.status = LEGSTATUS.WAITING_FOR_BOX_STOP_LOSS_EXIT
                        else:
                            leg.status = LEGSTATUS.WAITING_FOR_BOX_STOP_LOSS_EXIT
                    elif leg.status in [LEGSTATUS.CREATED, LEGSTATUS.CONTRACTRIZED]:
                        leg.status = LEGSTATUS.EXITED
                if strategy.box_stop_loss_reentry_remaining > 0:
                    strategy.entry_number += 1
                    strategy.box_stop_loss_reentry_remaining -= 1
                    strategy.next_reentry_check_time = trading_timestamp + strategy.box_stop_loss_reentry.value.cool_off_time
                else:
                    strategy.status = STRATEGYSTATUS.COMPLETED
                    strategy.next_action_time = 0
                            
            if is_box_take_profit_hit(strategy.entry_combined_premium, strategy_profit, strategy.legs[0].quantity, strategy.box_take_profit):
                strategy.status = STRATEGYSTATUS.BOX_TP_HIT
                for leg in strategy.legs:
                    if leg.status in [LEGSTATUS.ENTERED, LEGSTATUS.EXIT_TRIGGERED]:
                        if leg.hedge:
                            if leg.hedge.entry_order:
                                if leg.hedge.entry_order.status == ORDERSTATUS.COMPLETE:
                                    hedge_ohlc = get_quote(
                                        feed_source,
                                        leg.hedge.entry_order.contract.symbol,
                                        current_date,
                                        strategy.entry_time,
                                        trading_timestamp,
                                        leg.hedge.entry_order.contract.expiry_date,
                                        leg.hedge.entry_order.contract.strike_price,
                                        leg.hedge.entry_order.contract.option_type,
                                        is_hedge=True,
                                    )
                                    if hedge_ohlc:
                                        if leg.hedge.entry_order.status == ORDERSTATUS.COMPLETE:
                                            exit_price = get_hedge_exit_price(strategy, hedge_ohlc, leg)
                                            place_hedge_exit_order(strategy, leg, product_type, order_type, current_date, trading_timestamp, index_price, broker, client_id, "Stg Box Take Profit Hedge Exit", orders)
                                    else:
                                        continue
                                else:
                                    leg.status = LEGSTATUS.WAITING_FOR_BOX_TAKE_PROFIT_EXIT
                        else:
                            leg.status = LEGSTATUS.WAITING_FOR_BOX_TAKE_PROFIT_EXIT
                    elif leg.status in [LEGSTATUS.CREATED, LEGSTATUS.CONTRACTRIZED]:
                        leg.status = LEGSTATUS.EXITED
                if strategy.box_take_profit_reentry_remaining > 0:
                    strategy.entry_number += 1
                    strategy.box_take_profit_reentry_remaining -= 1
                    strategy.next_reentry_check_time = trading_timestamp + strategy.box_take_profit_reentry.value.cool_off_time
                else:
                    strategy.status = STRATEGYSTATUS.COMPLETED  
                    strategy.next_action_time = 0
                    
            if is_stg_stop_loss_hit(strategy_loss, strategy.current_stop_loss):
                strategy.status = STRATEGYSTATUS.SL_HIT
                for leg in strategy.legs:
                    if leg.status in [LEGSTATUS.ENTERED, LEGSTATUS.EXIT_TRIGGERED]:
                        if leg.hedge:
                            if leg.hedge.entry_order:
                                if leg.hedge.entry_order.status == ORDERSTATUS.COMPLETE:
                                    hedge_ohlc = get_quote(
                                        feed_source,
                                        leg.hedge.entry_order.contract.symbol,
                                        current_date,
                                        strategy.entry_time,
                                        trading_timestamp,
                                        leg.hedge.entry_order.contract.expiry_date,
                                        leg.hedge.entry_order.contract.strike_price,
                                        leg.hedge.entry_order.contract.option_type,
                                        is_hedge=True,
                                    )
                                    if hedge_ohlc:
                                        exit_price = get_hedge_exit_price(strategy, hedge_ohlc, leg)
                                        exit_reason = "Stg Stop Loss Hedge Exit"
                                        if strategy.is_lock_is_triggerd:
                                            if strategy.is_stop_loss_trailed:
                                                exit_reason = "Stg Stop Loss Trailing Hit"
                                            else:
                                                exit_reason = "Stg Minimum Profit Lock Hit"
                                        else:
                                            if strategy.is_stop_loss_trailed:
                                                exit_reason = "Stg Stop Loss Trailing Hit"
                                        place_hedge_exit_order(strategy, leg, product_type, order_type, current_date, trading_timestamp, index_price, broker, client_id, exit_reason, orders)
                                    else:
                                        continue
                                else:
                                    leg.status = LEGSTATUS.WAITING_FOR_STG_STOP_LOSS_EXIT
                        else:
                            leg.status = LEGSTATUS.WAITING_FOR_STG_STOP_LOSS_EXIT
                    
                    elif leg.status in [LEGSTATUS.CREATED, LEGSTATUS.CONTRACTRIZED]:
                        leg.status = LEGSTATUS.EXITED
                if strategy.stop_loss_reentry_remaining > 0:
                    strategy.entry_number += 1
                    strategy.stop_loss_reentry_remaining -= 1
                else:
                    strategy.is_first_entry = True
                    strategy.status = STRATEGYSTATUS.COMPLETED
                    strategy.next_action_time = 0
                    
            if is_stg_profit_hit(strategy_profit, strategy.take_profit.value):
                strategy.status = STRATEGYSTATUS.TP_HIT
                for leg in strategy.legs:
                    if leg.status in [LEGSTATUS.ENTERED, LEGSTATUS.EXIT_TRIGGERED]:
                        if leg.hedge:
                            if leg.hedge.entry_order:
                                if leg.hedge.entry_order.status == ORDERSTATUS.COMPLETE:
                                    hedge_ohlc = get_quote(
                                        feed_source,
                                        leg.hedge.entry_order.contract.symbol,
                                        current_date,
                                        strategy.entry_time,
                                        trading_timestamp,
                                        leg.hedge.entry_order.contract.expiry_date,
                                        leg.hedge.entry_order.contract.strike_price,
                                        leg.hedge.entry_order.contract.option_type,
                                        is_hedge=True,
                                    )
                                    if hedge_ohlc:
                                        exit_price = get_hedge_exit_price(strategy, hedge_ohlc, leg)
                                        place_hedge_exit_order(strategy, leg, product_type, order_type, current_date, trading_timestamp, index_price, broker, client_id, "Stg Take Profit Hedge Exit", orders)
                                    else:
                                        continue
                                else:
                                    leg.status = LEGSTATUS.WAITING_FOR_STG_TAKE_PROFIT_EXIT
                        else:
                            leg.status = LEGSTATUS.WAITING_FOR_STG_TAKE_PROFIT_EXIT
                    elif leg.status in [LEGSTATUS.CREATED, LEGSTATUS.CONTRACTRIZED]:
                        leg.status = LEGSTATUS.EXITED
                if strategy.take_profit_reentry_remaining > 0:
                    strategy.entry_number += 1
                    strategy.take_profit_reentry_remaining -= 1
                else:
                    strategy.status = STRATEGYSTATUS.COMPLETED
                    strategy.next_action_time = 0
                    
            if strategy.exit_rsi:
                can_make_full_candle = (trading_timestamp - MARKET_START_TIME[exchange.name])%strategy.exit_rsi.interval == 0
                if  can_make_full_candle and strategy.entry_indicator_triggered:
                    strategy.exit_rsi and can_make_full_candle and strategy.entry_indicator_triggered
                    current_rsi = get_rsi(strategy.index,strategy.exit_rsi, current_date, previous_date, trading_timestamp, is_live)
                    if current_rsi and is_rsi_trigggered(strategy.exit_rsi, current_rsi):
                        strategy.status = STRATEGYSTATUS.RSI_HIT
                        for leg in strategy.legs:
                            if leg.status in [LEGSTATUS.ENTERED, LEGSTATUS.EXIT_TRIGGERED]:
                                if leg.hedge:
                                    if leg.hedge.entry_order:
                                        if leg.hedge.entry_order.status == ORDERSTATUS.COMPLETE:
                                            hedge_ohlc = get_quote(
                                                feed_source,
                                                leg.hedge.entry_order.contract.symbol,
                                                current_date,
                                                strategy.entry_time,
                                                trading_timestamp,
                                                leg.hedge.entry_order.contract.expiry_date,
                                                leg.hedge.entry_order.contract.strike_price,
                                                leg.hedge.entry_order.contract.option_type,
                                                is_hedge=True,
                                            )
                                            if hedge_ohlc:
                                                                                            exit_price = get_hedge_exit_price(strategy, hedge_ohlc, leg)
                                            place_hedge_exit_order(strategy, leg, product_type, order_type, current_date, trading_timestamp, index_price, broker, client_id, "Stg RSI Hedge Exit", orders)
                                            else:
                                                continue
                                        else:
                                            leg.status = LEGSTATUS.WAITING_FOR_STG_RSI_EXIT
                                else:
                                    leg.status = LEGSTATUS.WAITING_FOR_STG_RSI_EXIT
                            elif leg.status in [LEGSTATUS.CREATED, LEGSTATUS.CONTRACTRIZED]:
                                leg.status = LEGSTATUS.EXITED
                        if strategy.rsi_reentry_remaining > 0:
                            strategy.entry_number += 1
                            strategy.rsi_reentry_remaining -= 1 ## RSI reentry not implemented
                            strategy.next_reentry_check_time = trading_timestamp + strategy.rsi_reentry.value.cool_off_time
                        else:
                            strategy.status = STRATEGYSTATUS.COMPLETED
                            strategy.next_action_time = 0
                            
            if (strategy.status == STRATEGYSTATUS.SQUAREOFF_ALL and strategy.next_action_time <= timestamp) or (strategy.squareoff_all_legs and strategy.is_any_leg_exited):
                strategy.status = STRATEGYSTATUS.SQUAREOFF_ALL
                for leg in strategy.legs:
                    if leg.status in [LEGSTATUS.ENTERED, LEGSTATUS.EXIT_TRIGGERED]:
                        if leg.hedge:
                            if leg.hedge.entry_order:
                                if leg.hedge.entry_order.status == ORDERSTATUS.COMPLETE:
                                    hedge_ohlc = get_quote(
                                        feed_source,
                                        leg.hedge.entry_order.contract.symbol,
                                        current_date,
                                        strategy.entry_time,
                                        trading_timestamp,
                                        leg.hedge.entry_order.contract.expiry_date,
                                        leg.hedge.entry_order.contract.strike_price,
                                        leg.hedge.entry_order.contract.option_type,
                                        is_hedge=True,
                                    )
                                    if hedge_ohlc:
                                        exit_price = get_hedge_exit_price(strategy, hedge_ohlc, leg)
                                        place_hedge_exit_order(strategy, leg, product_type, order_type, current_date, trading_timestamp, index_price, broker, client_id, "Stg Square Off All Legs Hedge Exit", orders)
                                    else:
                                        continue
                                else:
                                    leg.status = LEGSTATUS.WAITING_FOR_SQUAREOFF_EXIT
                        else:
                            leg.status = LEGSTATUS.WAITING_FOR_SQUAREOFF_EXIT
                    elif leg.status in [LEGSTATUS.CREATED, LEGSTATUS.CONTRACTRIZED]:
                        leg.status = LEGSTATUS.EXITED
                if strategy.sqaareoff_reentry_remaining > 0:
                    strategy.entry_number += 1
                    strategy.sqaareoff_reentry_remaining -= 1
                    strategy.next_reentry_check_time = trading_timestamp + strategy.squareoff_reentry.value.cool_off_time
                else:
                    strategy.status = STRATEGYSTATUS.COMPLETED

            is_all_legs_exited = True
            for leg in strategy.legs:
                if leg.status == LEGSTATUS.WAITING_FOR_HEDGE_EXIT:
                    if leg.hedge.exit_order.status == ORDERSTATUS.COMPLETE:
                        if leg.hedge_pnl_effect:
                            hedge_pnl = calculate_current_pnl(leg.hedge.exit_order.average_price, leg.hedge.entry_order.average_price, leg.hedge.side, leg.take_profit.type)*leg.quantity*leg.multiplier*strategy.multiplier
                            if leg.hedge.side == SIDE.BUY:
                                leg.realized_pnl += hedge_pnl
                                strategy.realized_pnl += hedge_pnl
                            else:
                                leg.realized_pnl += -hedge_pnl
                                strategy.realized_pnl += -hedge_pnl
                        if leg.hedge.exit_order.reason in ["Stg Stop Loss Hedge Exit", "Stg Stop Loss Trailing Hit", "Stg Minimum Profit Lock Hit"]:
                            leg.status = LEGSTATUS.WAITING_FOR_STG_STOP_LOSS_EXIT
                        elif leg.hedge.exit_order.reason == "Stg Take Profit Hedge Exit":
                            leg.status = LEGSTATUS.WAITING_FOR_STG_TAKE_PROFIT_EXIT
                        elif leg.hedge.exit_order.reason == "Stg Square Off All Legs Hedge Exit":
                            leg.status = LEGSTATUS.WAITING_FOR_SQUAREOFF_EXIT
                        elif leg.hedge.exit_order.reason == "Stg RSI Hedge Exit":
                            leg.status = LEGSTATUS.WAITING_FOR_STG_RSI_EXIT
                        elif leg.hedge.exit_order.reason == "Stg Box Stop Loss Hedge Exit":
                            leg.status = LEGSTATUS.WAITING_FOR_BOX_STOP_LOSS_EXIT
                        elif leg.hedge.exit_order.reason == "Stg Box Take Profit Hedge Exit":
                            leg.status = LEGSTATUS.WAITING_FOR_BOX_TAKE_PROFIT_EXIT
                            
                if leg.status == LEGSTATUS.WAITING_FOR_SQUAREOFF_EXIT:
                    last_order = leg.orders[-1]
                    ohlc = get_quote(
                        feed_source,
                        last_order.contract.symbol,
                        current_date,
                        strategy.entry_time,
                        trading_timestamp,
                        last_order.contract.expiry_date,
                        last_order.contract.strike_price,
                        last_order.contract.option_type,
                    )
                    if strategy.pnl_calculation_from == "OPEN":
                        exit_price = ohlc.open/100.0
                    elif strategy.pnl_calculation_from == "CLOSE":
                        exit_price = ohlc.close/100.0
                    else:
                        exit_price = ohlc.low/100.0 if last_order.side == SIDE.BUY else ohlc.high/100.0

                    place_exit_order(strategy, leg, last_order, product_type, order_type, current_date, trading_timestamp, index_price, "Square Off All Leg", broker, client_id, exit_price, orders, LEGSTATUS.WAITING_FOR_SQUAREOFF_FILL)
                            
                if leg.status == LEGSTATUS.WAITING_FOR_BOX_STOP_LOSS_EXIT:
                    last_order = leg.orders[-1]
                    ohlc = get_quote(
                        feed_source,
                        last_order.contract.symbol,
                        current_date,
                        strategy.entry_time,
                        trading_timestamp,
                        last_order.contract.expiry_date,
                        last_order.contract.strike_price,
                        last_order.contract.option_type,
                    )
                    if ohlc is None:
                        continue
                    if strategy.pnl_calculation_from == "OPEN":
                        exit_price = ohlc.open/100.0
                    elif strategy.pnl_calculation_from == "CLOSE":
                        exit_price = ohlc.close/100.0
                    else:
                        exit_price = ohlc.low/100.0 if last_order.side == SIDE.BUY else ohlc.high/100.0

                    place_exit_order(strategy, leg, last_order, product_type, order_type, current_date, trading_timestamp, index_price, "Box Stop Loss Hit", broker, client_id, exit_price, orders, LEGSTATUS.WAITING_FOR_BOX_STOP_LOSS_FILL)
                        
                if leg.status == LEGSTATUS.WAITING_FOR_BOX_TAKE_PROFIT_EXIT:
                    last_order = leg.orders[-1]
                    ohlc = get_quote(
                        feed_source,
                        last_order.contract.symbol,
                        current_date,
                        strategy.entry_time,
                        trading_timestamp,
                        last_order.contract.expiry_date,
                        last_order.contract.strike_price,
                        last_order.contract.option_type,
                    )
                    if ohlc is None:
                        continue
                    if strategy.pnl_calculation_from == "OPEN":
                        exit_price = ohlc.open/100.0
                    elif strategy.pnl_calculation_from == "CLOSE":
                        exit_price = ohlc.close/100.0
                    else:
                        exit_price = ohlc.low/100.0 if last_order.side == SIDE.SELL else ohlc.high/100.0
                        
                    place_exit_order(strategy, leg, last_order, product_type, order_type, current_date, trading_timestamp, index_price, "Box Take Profit Hit", broker, client_id, exit_price, orders, LEGSTATUS.WAITING_FOR_STG_TAKE_PROFIT_FILL)
                    
                if leg.status == LEGSTATUS.WAITING_FOR_STG_STOP_LOSS_EXIT:
                    last_order = leg.orders[-1]
                    ohlc = get_quote(
                        feed_source,
                        last_order.contract.symbol,
                        current_date,
                        strategy.entry_time,
                        trading_timestamp,
                        last_order.contract.expiry_date,
                        last_order.contract.strike_price,
                        last_order.contract.option_type,
                    )
                    if ohlc is None:
                        continue
                    if strategy.pnl_calculation_from == "OPEN":
                        exit_price = ohlc.open/100.0
                    elif strategy.pnl_calculation_from == "CLOSE":
                        exit_price = ohlc.close/100.0
                    else:
                        exit_price = ohlc.low/100.0 if last_order.side == SIDE.BUY else ohlc.high/100.0

                    exit_reason = "Overall Stop Loss Hit"
                    if strategy.is_lock_is_triggerd:
                        if strategy.is_stop_loss_trailed:
                            exit_reason = "Stg Stop Loss Trailing Hit"
                        else:
                            exit_reason = "Stg Minimum Profit Lock Hit"
                    else:
                        if strategy.is_stop_loss_trailed:
                            exit_reason = "Stg Stop Loss Trailing Hit"
                            
                    place_exit_order(strategy, leg, last_order, product_type, order_type, current_date, trading_timestamp, index_price, exit_reason, broker, client_id, exit_price, orders, LEGSTATUS.WAITING_FOR_STG_STOP_LOSS_FILL)
            
                if leg.status == LEGSTATUS.WAITING_FOR_STG_TAKE_PROFIT_EXIT:
                    last_order = leg.orders[-1]
                    ohlc = get_quote(
                        feed_source,
                        last_order.contract.symbol,
                        current_date,
                        strategy.entry_time,
                        trading_timestamp,
                        last_order.contract.expiry_date,
                        last_order.contract.strike_price,
                        last_order.contract.option_type,
                    )
                    if ohlc is None:
                        continue
                    if strategy.pnl_calculation_from == "OPEN":
                        exit_price = ohlc.open/100.0
                    elif strategy.pnl_calculation_from == "CLOSE":
                        exit_price = ohlc.close/100.0
                    else:
                        exit_price = ohlc.low/100.0 if last_order.side == SIDE.SELL else ohlc.high/100.0
                        
                    place_exit_order(strategy, leg, last_order, product_type, order_type, current_date, trading_timestamp, index_price, "Overall Take Profit Hit", broker, client_id, exit_price, orders, LEGSTATUS.WAITING_FOR_STG_TAKE_PROFIT_FILL)
                    
                if leg.status == LEGSTATUS.WAITING_FOR_STG_RSI_EXIT:
                    last_order = leg.orders[-1]
                    ohlc = get_quote(
                        feed_source,
                        last_order.contract.symbol,
                        current_date,
                        strategy.entry_time,
                        trading_timestamp,
                        last_order.contract.expiry_date,
                        last_order.contract.strike_price,
                        last_order.contract.option_type,
                    )
                    if ohlc is None:
                        continue
                    if strategy.pnl_calculation_from == "OPEN":
                        exit_price = ohlc.open/100.0
                    elif strategy.pnl_calculation_from == "CLOSE":
                        exit_price = ohlc.close/100.0
                    else:
                        exit_price = ohlc.low/100.0 if last_order.side == SIDE.SELL else ohlc.high/100.0
                    place_exit_order(strategy, leg, last_order, product_type, order_type, current_date, trading_timestamp, index_price, "Overall RSI Hit", broker, client_id, exit_price, orders, LEGSTATUS.WAITING_FOR_STG_RSI_EXIT_FILL)
                    
                if leg.status in [LEGSTATUS.WAITING_FOR_BOX_STOP_LOSS_FILL, LEGSTATUS.WAITING_FOR_BOX_TAKE_PROFIT_FILL, LEGSTATUS.WAITING_FOR_STG_STOP_LOSS_FILL, LEGSTATUS.WAITING_FOR_STG_TAKE_PROFIT_FILL, LEGSTATUS.WAITING_FOR_STG_RSI_EXIT_FILL, LEGSTATUS.WAITING_FOR_SQUAREOFF_FILL]:
                    exit_order = leg.orders[-1]
                    if exit_order.status == ORDERSTATUS.COMPLETE:
                        entry_order = leg.orders[-2]
                        leg_pnl = calculate_current_pnl(exit_order.average_price, entry_order.average_price, entry_order.side, leg.take_profit.type)*entry_order.quantity
                        leg.realized_pnl += leg_pnl
                        strategy.realized_pnl += leg_pnl
                        leg.status = LEGSTATUS.EXITED
                        
                if leg.status not in [LEGSTATUS.EXITED, LEGSTATUS.STOP_LOSS_REENTRY, LEGSTATUS.TAKE_PROFIT_REENTRY]:
                    is_all_legs_exited = False
            if is_all_legs_exited and (strategy.take_profit_reentry_remaining > -1 or strategy.stop_loss_reentry_remaining > -1 or strategy.box_stop_loss_reentry_remaining > -1 or strategy.box_take_profit_reentry_remaining > -1 or strategy.rsi_reentry_remaining > -1 or strategy.sqaareoff_reentry_remaining > -1) and strategy.status in [STRATEGYSTATUS.SL_HIT, STRATEGYSTATUS.TP_HIT, STRATEGYSTATUS.RSI_HIT, STRATEGYSTATUS.BOX_SL_HIT, STRATEGYSTATUS.BOX_TP_HIT, STRATEGYSTATUS.SQUAREOFF_ALL]:
                tb_strategy_reentry_reset(strategy)
            
            for leg in strategy.legs:
                if leg.status not in [LEGSTATUS.EXITED, LEGSTATUS.STOP_LOSS_REENTRY, LEGSTATUS.TAKE_PROFIT_REENTRY, LEGSTATUS.TRIGGER_REENTRY, LEGSTATUS.CREATED, LEGSTATUS.CONTRACTRIZED]:
                    last_order = leg.orders[-1]
                    # if leg.hedge:
                        
                    if last_order.status == ORDERSTATUS.COMPLETE:
                        close_ohlc = get_quote(
                            feed_source,
                            leg.contract.symbol,
                            current_date,
                            strategy.entry_time,
                            trading_timestamp,
                            leg.contract.expiry_date,
                            leg.contract.strike_price,
                            leg.contract.option_type,
                            True
                        )
                        
                        if close_ohlc is None:
                            continue
                        pnl = calculate_current_pnl(
                                close_ohlc.close/100.0,
                                last_order.average_price,
                                last_order.side,
                                leg.take_profit.type,
                            )*last_order.quantity
                        tick_pnl += pnl
                    
    strategy.tick_profits[current_date] = strategy.tick_profits.get(current_date, {})
    strategy.tick_profits[current_date][trading_timestamp] =  tick_pnl+ strategy.realized_pnl
    strategy.tick_losses[current_date] = strategy.tick_losses.get(current_date, {})
    strategy.tick_losses[current_date][trading_timestamp] =  tick_pnl + strategy.realized_pnl
    
    for leg in strategy.legs:   
        if leg.stop_loss.params.check_frequency == Config.BT_FREQUENCY:
            strategy.last_stop_loss_check_time = trading_timestamp
        if leg.take_profit.params.check_frequency == Config.BT_FREQUENCY:
            strategy.last_take_profit_check_time = trading_timestamp