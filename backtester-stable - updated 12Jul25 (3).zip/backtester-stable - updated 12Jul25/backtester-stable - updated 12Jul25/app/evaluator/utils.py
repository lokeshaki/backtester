from app.commons.modules import logging, Tuple, List, ta, datetime, pd, timedelta, numpy, deepcopy, uuid
from app.commons.models import OHLC, Order, TimeStamp
from app.parser.models import Leg, Strategy, Rsi, VwapStrategy, Portfolio
from app.commons.enums import (
    NUMBERTYPE,
    ENUMELEMENT,
    SIDE,
    EXPIRYTYPE,
    STRIKESELECTIONTYPE,
    OPTIONTYPE,
    LEGSTATUS,
    FEEDSOURCE,
    UNDERLYINGTYPE,
    STRATEGYSTATUS,
    FORCEENTRYTYPE,
    RSIDIRECTION,
    REENTRYTYPE,
    ORBBREAKOUTTYPE,
    ORDERSTATUS,
    LOCKTYPE,
)

from app.commons.constants import MAX_INT, MIN_INT, SECONDS_IN_A_DAY, TD64S, MARKET_START_TIME

from app.commons.utils import (
    round_to,
    get_strike_diff_for_index,
    get_deltas,
    reverse_side,
    datetime,
    sign
)
from app.commons.models import Contract
from app.database.utils import (
    get_current_week_expiry_date,
    get_next_week_expiry_date,
    get_monthly_expiry_date,
    get_closest_strike_price,
    get_ge_strike_price,
    get_le_strike_price,
    get_previous_day_vix_value,
    get_previous_day_closing_price,
    get_strike_closest_to_delta,
    get_strike_ge_delta,
    get_strike_le_delta,
    get_closest_valid_strike_price,
    get_min_diff_strike_price,
)
from app.parser.models import (
    StopLoss,
    TakeProfit,
    TrailingStopLoss,
    WaitIn,
    Leg,
    Strategy,
    Rsi,
)
from app.feed import get_quote, get_candles
from app.broker import place_order
from app.config import Config

logger = logging.getLogger(__name__)


def is_rsi_trigggered(rsi: Rsi, current_rsi: float) -> bool:
    if rsi.direction == RSIDIRECTION.OUTSIDE:
        return current_rsi >= rsi.overbought_level or current_rsi <= rsi.oversold_level
    elif rsi.direction == RSIDIRECTION.INSIDE:
        return current_rsi >= rsi.oversold_level and current_rsi <= rsi.overbought_level
    else:
        raise ValueError("Invalid RSI direction")


def is_time_for_entry(current_time: int, entry_time: int) -> bool:
    """
    Check if entry time is reached

    Parameters:
        current_time (int): current time in seconds
        entry_time (int): entry time in seconds
    Returns:
        bool: True if entry time is reached, False otherwise
    """

    return current_time >= entry_time


def is_time_for_exit(current_time: int, exit_time: int) -> bool:
    """
    Check if exit time is reached

    Parameters:
        current_time (int): current time in seconds
        exit_time (int): exit time in seconds
    Returns:
        bool: True if exit time is reached, False otherwise
    """

    return current_time >= exit_time


def calculate_current_pnl(
    ltp: float, trade_price: float, trade_side: ENUMELEMENT, pnl_type: NUMBERTYPE
) -> float:
    """
    Calculate current PnL based on LTP, trade price and trade side

    Parameters:
        ltp (float): last traded price in INR
        trade_price (float): trade price in INR
        trade_side (SIDE): trade side
    Returns:
        float: current PnL in points
    """

    # if pnl_type == NUMBERTYPE.POINT:
    if trade_side == SIDE.BUY:
        return ltp - trade_price
    elif trade_side == SIDE.SELL:
        return trade_price - ltp
    else:
        raise ValueError("Invalid trade side")
    # elif pnl_type == NUMBERTYPE.PERCENTAGE:
    #     if trade_side == SIDE.BUY:
    #         return (ltp - trade_price) / trade_price * 100
    #     elif trade_side == SIDE.SELL:
    #         return (trade_price - ltp) / trade_price * 100
    #     else:
    #         raise ValueError("Invalid trade side")
    # else:
    #     raise ValueError("Invalid PnL type")


def trail_sl(
    leg: Leg,
    profit_index_pnl: float,
    open_profit: float,
    index_based_sl,
    index_based_tp,
    last_order: Order,
):
    stop_loss_move = calculate_how_much_stop_loss_should_move(
        profit_index_pnl,
        open_profit,
        leg.current_trailing_stop_loss[0],
        leg.current_trailing_stop_loss[1],
        index_based_sl,
        index_based_tp,
    )
    new_stop_loss = stop_loss_update(
        calculate_stop_loss_points(
            last_order.index_price, last_order.average_price, leg.stop_loss, leg.side
        ),
        leg.current_stop_loss,
        stop_loss_move,
    )
    if new_stop_loss:
        leg.is_stop_loss_trailed = True
        leg.current_stop_loss = new_stop_loss


def trail_stg_sl(
    strategy: Strategy,
    strategy_profit,
    lock_type =LOCKTYPE.REGULAR,
):
    tp_for_trail = strategy_profit
    if strategy.lock_and_trail.lock:
        tp_for_trail -= strategy.lock_and_trail.lock
    instrument_move = strategy.current_trailing_stop_loss[0]
    sl_move = strategy.current_trailing_stop_loss[1]
    if lock_type == LOCKTYPE.MAX_TILL_TIME and strategy.trailing_stop_loss:
        instrument_move = strategy.current_trailing_stop_loss[0]*strategy_profit/100
        sl_move = strategy.current_trailing_stop_loss[1]*strategy_profit/100
    stg_stop_loss_move = calculate_how_much_stop_loss_should_move(
        0,
        tp_for_trail,
        instrument_move,
        sl_move,
        False,
        False,
    )
    sl_for_trail = strategy.stop_loss.value
    if strategy.lock_and_trail.lock:
        sl_for_trail = strategy.lock_and_trail.trail
    stg_new_stop_loss = stop_loss_update(
        sl_for_trail, strategy.current_stop_loss, stg_stop_loss_move, True
    )
    if stg_new_stop_loss:
        strategy.is_stop_loss_trailed = True
        strategy.current_stop_loss = stg_new_stop_loss


def is_stop_loss_hit(pnl: float, stop_loss_points: float) -> bool:
    """
    Check if stop loss is hit

    Parameters:
        pnl (float): current PnL in points
        stop_loss_points (float): stop loss points
    Returns:
        bool: True if stop loss is hit, False otherwise
    """

    return pnl <= -round_to(stop_loss_points, 0.05)


def is_box_stop_loss_hit(
    entry_preminum: float, pnl: float, quantity: int, stop_loss: StopLoss
):
    if stop_loss.value == MAX_INT or pnl >= 0:
        return False
    if stop_loss.type == NUMBERTYPE.POINT:
        return abs(pnl / quantity) >= stop_loss.value
    elif stop_loss.type == NUMBERTYPE.PERCENTAGE:
        return abs(pnl / quantity) / entry_preminum * 100 >= stop_loss.value


def is_take_profit_hit(pnl: float, take_profit_points: float) -> bool:
    """
    Check if take profit is hit

    Parameters:
        pnl (float): current PnL in points
        take_profit_points (float): take profit points
    Returns:
        bool: True if take profit is hit, False otherwise
    """

    return pnl >= take_profit_points


def is_stg_profit_hit(pnl, take_profit):
    """
    Check if stg profit is hit

    Parameters:
        pnl (float): current PnL in points
        take_profit (float): take profit in rupees
    Returns:
        bool: True if take profit is hit, False otherwise
    """
    return take_profit != MAX_INT and pnl != 0 and pnl >= take_profit


def is_stg_stop_loss_hit(pnl, stop_loss):
    """
    Check if stg stoploss is hit

    Parameters:
        pnl (float): current PnL in points
        take_profit (float): stoploss in rupees
    Returns:
        bool: True if stop loss is hit, False otherwise
    """
    return stop_loss != MAX_INT and pnl != 0 and pnl <= stop_loss


def is_box_take_profit_hit(
    entry_preminum: float, pnl: float, quantity: int, take_profit: TakeProfit
):
    if take_profit.value == MAX_INT or pnl <= 0:
        return False
    if take_profit.type == NUMBERTYPE.POINT:
        return abs(pnl / quantity) >= take_profit.value
    elif take_profit.type == NUMBERTYPE.PERCENTAGE:
        return abs(pnl / quantity) / entry_preminum * 100 >= take_profit.value


def is_waiting_is_over(
    ltp_of_contract: float, intial_price_of_contract: float, wait_in_points: float
) -> bool:
    """
    Check if waiting time is over

    Args:
        move (int): Contract price move in points
        wait_in_points (float): waiting time in points

    Returns:
        bool: _description_
    """

    move = ltp_of_contract - intial_price_of_contract
    if wait_in_points == 0:
        return True
    if wait_in_points > 0:
        return move >= wait_in_points
    elif wait_in_points < 0:
        return move <= wait_in_points


def is_lock_is_triggered(current_profit: float, lock: float):
    return current_profit > lock


def calculate_stop_loss_points(
    index_price: float, trade_price: float, stop_loss: StopLoss, side: SIDE = None
) -> float:
    """
    Calculate stop loss points

    Parameters:
        trade_price (float): trade price in INR
        stop_loss (StopLoss): stop loss
    Returns:
        float: stop loss points
    """

    if stop_loss.type in [NUMBERTYPE.POINT, NUMBERTYPE.INDEX_POINTS]:
        return stop_loss.value
    elif stop_loss.type == NUMBERTYPE.PERCENTAGE:
        return trade_price * stop_loss.value / 100
    elif stop_loss.type == NUMBERTYPE.INDEX_PERCENTAGE:
        return index_price * stop_loss.value / 100
    elif stop_loss.type == NUMBERTYPE.PREMIUM:
        if side == SIDE.BUY:
            return trade_price - stop_loss.value
        elif side == SIDE.SELL:
            return stop_loss.value - trade_price
    else:
        raise ValueError("Invalid stop loss type")


def calculate_take_profit_points(
    index_price: float, trade_price: float, take_profit: TakeProfit, side: SIDE = None
) -> float:
    """
    Calculate take profit points

    Parameters:
        trade_price (float): trade price in INR
        take_profit (TakeProfit): take profit
    Returns:
        float: take profit points
    """

    if take_profit.type in [NUMBERTYPE.POINT, NUMBERTYPE.INDEX_POINTS]:
        return take_profit.value
    elif take_profit.type == NUMBERTYPE.PERCENTAGE:
        return trade_price * take_profit.value / 100
    elif take_profit.type == NUMBERTYPE.INDEX_PERCENTAGE:
        return index_price * take_profit.value / 100
    elif take_profit.type == NUMBERTYPE.PREMIUM:
        if side == SIDE.BUY:
            return take_profit.value - trade_price
        elif side == SIDE.SELL:
            return trade_price - take_profit.value
    else:
        raise ValueError("Invalid take profit type")


def calculate_trailing_stop_loss_points(
    index_price: float, trade_price: float, trailing_stop_loss: TrailingStopLoss
) -> Tuple[float, float]:
    """
    Calculate trailing stop loss points

    Parameters:
        trade_price (float): trade price in INR
        trailing_stop_loss (TrailingStopLoss): trailing stop loss
    Returns:
        Tuple[float, float]: trailing stop loss points
    """

    if trailing_stop_loss.profit_move.type in [
        NUMBERTYPE.POINT,
        NUMBERTYPE.INDEX_POINTS,
    ]:
        profit_move_points = trailing_stop_loss.profit_move.value
    elif trailing_stop_loss.profit_move.type == NUMBERTYPE.PERCENTAGE:
        profit_move_points = trade_price * trailing_stop_loss.profit_move.value / 100
    elif trailing_stop_loss.profit_move.type == NUMBERTYPE.INDEX_PERCENTAGE:
        profit_move_points = index_price * trailing_stop_loss.profit_move.value / 100
    else:
        raise ValueError("Invalid trailing stop loss type")

    if trailing_stop_loss.stop_loss_move.type in [
        NUMBERTYPE.POINT,
        NUMBERTYPE.INDEX_POINTS,
    ]:
        stop_loss_move_points = trailing_stop_loss.stop_loss_move.value
    elif trailing_stop_loss.stop_loss_move.type == NUMBERTYPE.PERCENTAGE:
        stop_loss_move_points = (
            trade_price * trailing_stop_loss.stop_loss_move.value / 100
        )
    elif trailing_stop_loss.stop_loss_move.type == NUMBERTYPE.INDEX_PERCENTAGE:
        stop_loss_move_points = (
            trade_price * trailing_stop_loss.stop_loss_move.value / 100
        )
    else:
        raise ValueError("Invalid trailing stop loss type")

    return (profit_move_points, stop_loss_move_points)


def calculate_wait_points(ltp: float, wait_and_trade: WaitIn) -> float:
    """
    Calculate wait and trade points

    Parameters:
        trade_price (float): trade price in INR
        wait_and_trade (WaitAndTrade): wait and trade
    Returns:
        Tuple[float, float]: wait and trade points
    """

    if wait_and_trade.type == NUMBERTYPE.POINT:
        wait_points = wait_and_trade.value
    elif wait_and_trade.type == NUMBERTYPE.PERCENTAGE:
        wait_points = ltp * wait_and_trade.value / 100
    else:
        raise ValueError("Invalid wait and trade type")

    return wait_points


def calculate_how_much_stop_loss_should_move(
    index_pnl: float,
    pnl: float,
    profit_move_points: float,
    stop_loss_move_points: float,
    index_based_sl: bool = False,
    index_based_tp: bool = False,
) -> float:
    """
    Calculate stop loss price

    Parameters:
        pnl (float): current PnL in points
        profit_move_points (float): profit move points
        stop_loss_move_points (float): stop loss move points
    Returns:
        float: stop loss price
    """
    if index_based_sl and index_based_tp:
        pnl = index_pnl
    multiplier = 0
    if profit_move_points != 0:
        multiplier = pnl / profit_move_points
    if multiplier > 1:
        return int(multiplier) * stop_loss_move_points
    else:
        return 0


def stop_loss_update(
    stop_loss_in_points: float,
    current_stop_loss_in_points: float,
    how_much_stop_loss_should_move: float,
    is_stg_stop_loss: bool = False,
) -> bool:
    """
    Check if stop loss should be updated

    Parameters:
        trade_price (float): trade price in INR
        stop_loss_in_points (float): stop loss in points
        current_stop_loss_in_points (float): current stop loss in points
        how_much_stop_loss_should_move (float): how much stop loss should move
    Returns:
        bool: True if stop loss should be updated, False otherwise
    """

    if is_stg_stop_loss:
        new_stop_loss_in_points = stop_loss_in_points + how_much_stop_loss_should_move
        if new_stop_loss_in_points >= 99999999:
            return False
        elif current_stop_loss_in_points >= new_stop_loss_in_points:
            return False
        else:
            return new_stop_loss_in_points
    else:
        new_stop_loss_in_points = stop_loss_in_points - how_much_stop_loss_should_move
        if current_stop_loss_in_points <= new_stop_loss_in_points:
            return False
        else:
            return new_stop_loss_in_points


def is_box_diff_hit(
    leg_one_ltp: float, leg_two_ltp: float, box_diff_in_points: float
) -> bool:
    """
    Check if box difference is hit

    Parameters:
        leg_one_ltp (float): leg one last traded price in INR
        leg_two_ltp (float): leg two last traded price in INR
        box_diff (float): box difference in INR
    Returns:
        bool: True if box difference is hit, False otherwise
    """

    return abs(leg_one_ltp - leg_two_ltp) <= box_diff_in_points


def calculate_box_diff_points(
    leg_one_ltp: float, leg_two_ltp: float, box_diff: ENUMELEMENT
) -> float:
    """
    Calculate box difference

    Parameters:
        leg_one_ltp (float): leg one last traded price in INR
        leg_two_ltp (float): leg two last traded price in INR
        box_diff (float): box difference in INR
    Returns:
        float: box difference in points

    """
    if box_diff.type == NUMBERTYPE.POINT:
        return box_diff.value
    elif box_diff.type == NUMBERTYPE.PERCENTAGE:
        return min([leg_one_ltp, leg_two_ltp]) * box_diff.value / 100
    
    
def remove_spawned_legs(strategy: Strategy):
    for leg in strategy.legs.copy():
        if leg.is_spawned:
            strategy.legs.remove(leg)
    

def reset_leg(leg: Leg):
    leg.status = LEGSTATUS.CREATED
    leg.stop_loss_reentry_remaining = leg.stop_loss_reentry.value.count
    leg.take_profit_reentry_remaining = leg.take_profit_reentry.value.count
    leg.trigger_reentry_remaining = leg.triggered_reentry.value.count
    leg.realized_pnl = 0
    leg.leg_entry_price = None
    leg.entry_number = 0
    leg.stop_loss_entry_number = 0
    leg.take_profit_entry_number = 0
    leg.reentry_reason = ""
    leg.current_stop_loss = None
    leg.current_take_profit = None
    leg.current_trailing_stop_loss = None
    leg.is_stop_loss_trailed = False
    leg.wait_in_time = 0
    if leg.hedge:
        leg.hedge.contract = None
        leg.hedge.entry_order = None
        leg.hedge.exit_order = None
        leg.hedge.status = LEGSTATUS.CREATED

def tb_strategy_reentry_reset(strategy: Strategy):
    for leg in strategy.legs:
        leg.status = LEGSTATUS.CREATED
        leg.stop_loss_reentry_remaining = leg.stop_loss_reentry.value.count
        leg.take_profit_reentry_remaining = leg.take_profit_reentry.value.count
        leg.trigger_reentry_remaining = leg.triggered_reentry.value.count
        leg.realized_pnl = 0
        leg.leg_entry_price = None
        leg.entry_number = 0
        leg.stop_loss_entry_number = 0
        leg.take_profit_entry_number = 0
        leg.reentry_reason = ""
        leg.current_stop_loss = None
        leg.current_take_profit = None
        leg.current_trailing_stop_loss = None
        leg.is_stop_loss_trailed = False
        leg.wait_in_time = 0
        if leg.hedge:
            leg.hedge.contract = None
            leg.hedge.entry_order = None
            leg.hedge.exit_order = None
            leg.hedge.status = LEGSTATUS.CREATED

    strategy.is_any_leg_sl_hit = False
    strategy.is_any_leg_exited = False
    strategy.entry_indicator_triggered = False
    strategy.entry_combined_premium = 0
    strategy.can_trail = False
    strategy.current_stop_loss = strategy.stop_loss.value
    strategy.status = STRATEGYSTATUS.RUNNING
    strategy.is_lock_is_triggerd = False


def tb_strategy_day_reset(strategy: Strategy):
    remove_spawned_legs(strategy)
    tb_strategy_reentry_reset(strategy)
    strategy.take_profit_reentry_remaining = strategy.take_profit_reentry.value.count
    strategy.stop_loss_reentry_remaining = strategy.stop_loss_reentry.value.count
    strategy.entry_number = 0
    strategy.is_first_entry = True
    strategy.last_stop_loss_check_time = strategy.entry_time
    strategy.last_take_profit_check_time = strategy.entry_time
    strategy.last_stop_loss_reentry_check_time = strategy.entry_time
    strategy.last_take_profit_reentry_check_time = strategy.entry_time
    strategy.entry_combined_premium = 0
    strategy.box_take_profit_reentry_remaining = (
        strategy.box_take_profit_reentry.value.count
    )
    strategy.box_stop_loss_reentry_remaining = (
        strategy.box_stop_loss_reentry.value.count
    )
    strategy.rsi_reentry_remaining = strategy.rsi_reentry.value.count
    strategy.sqaareoff_reentry_remaining = strategy.squareoff_reentry.value.count
    strategy.realized_pnl = 0
    strategy.next_action_time = 0
    for leg in strategy.legs:
        if leg.orb is not None:
            leg.orb.high_range = None
            leg.orb.low_range = None
            leg.orb.is_set = False
        leg.is_first_entry = True
        leg.is_activated = not leg.is_idle
        leg.next_action_time = 0
        leg.exit_triggered = False
        leg.entered_by_trigger = False


def vwap_strategy_reentry_reset(strategy: VwapStrategy):
    for leg in strategy.legs:
        leg.status = LEGSTATUS.CREATED
        leg.realized_pnl = 0
        leg.leg_entry_price = None
        leg.entry_number = 0
        leg.stop_loss_entry_number = 0
        leg.take_profit_entry_number = 0
        leg.reentry_reason = ""
        leg.current_stop_loss = None
        leg.current_take_profit = None
        leg.current_trailing_stop_loss = None
        leg.is_stop_loss_trailed = False
        leg.wait_in_time = 0
        if leg.hedge:
            leg.hedge.contract = None
            leg.hedge.entry_order = None
            leg.hedge.exit_order = None
            leg.hedge.status = LEGSTATUS.CREATED

    strategy.is_any_leg_exited = False
    strategy.entry_indicator_triggered = False
    strategy.entry_combined_premium = 0
    strategy.can_trail = False
    strategy.current_stop_loss = strategy.stop_loss.value
    strategy.status = STRATEGYSTATUS.RUNNING
    strategy.is_lock_is_triggerd = False
    strategy.can_trail = False
    strategy.ready_to_enter = False
    strategy.signal_candle_low = MAX_INT
    strategy.signal_candle_high = MIN_INT
    strategy.indicator_based_entry = False


def vwap_strategy_day_reset(strategy: VwapStrategy):
    vwap_strategy_reentry_reset(strategy)
    strategy.take_profit_reentry_remaining = strategy.take_profit_reentry.value.count
    strategy.stop_loss_reentry_remaining = strategy.stop_loss_reentry.value.count
    strategy.stop_loss_reentry_remaining = strategy.stop_loss_reentry.value.count
    strategy.indicator_based_reentry_remaining = (
        strategy.indicator_based_reentry.value.count
    )
    strategy.entry_number = 0
    strategy.is_first_entry = True
    strategy.last_stop_loss_check_time = strategy.entry_time
    strategy.last_take_profit_check_time = strategy.entry_time
    strategy.last_stop_loss_reentry_check_time = strategy.entry_time
    strategy.last_take_profit_reentry_check_time = strategy.entry_time
    strategy.next_reentry_check_time = 0
    strategy.realized_pnl = 0
    for leg in strategy.legs:
        leg.is_contracterized_before = False


def portfolio_day_reset(strategy: Portfolio):

    strategy.is_stop_loss_trailed = False
    strategy.is_lock_is_triggerd = False
    if strategy.lock_and_trail.type in [LOCKTYPE.MAX_TILL_TIME, LOCKTYPE.MAX_POSSIBLE_PROFIT]:
        strategy.lock_and_trail.lock = 0
    strategy.current_take_profit = strategy.take_profit.value
    strategy.can_trail = False
    strategy.is_exit_hit = False
    strategy.current_stop_loss = strategy.stop_loss.value


def contractrize_leg(
    index: ENUMELEMENT,
    index_base_price: float,
    index_price: float,
    fix_vix: float,
    available_trading_dates: List[int],
    current_date: int,
    trading_timestamp: int,
    atm: float,
    strike_diff: int,
    exchange: ENUMELEMENT,
    leg: Leg,
    is_live: bool,
    feed_source: FEEDSOURCE,
    is_box: bool = False,
    other_leg_ltp: float = None,
):
    if leg.expiry_type == EXPIRYTYPE.WEEKLY:
        leg_expiry = get_current_week_expiry_date(index, current_date, is_live)
    elif leg.expiry_type == EXPIRYTYPE.NEXT_WEEKLY:
        leg_expiry = get_next_week_expiry_date(index, current_date, is_live)
    elif leg.expiry_type == EXPIRYTYPE.MONTHLY:
        leg_expiry = get_monthly_expiry_date(index, current_date, is_live)

    if leg.next_expiry_select == True and leg_expiry == current_date:
        leg_expiry = get_next_week_expiry_date(index, current_date, is_live)
    
    atm = get_closest_valid_strike_price(index, current_date, trading_timestamp, leg_expiry, atm, leg.option_type, is_live)
    
    # If ATM is None, skip this leg as data is not available
    if atm is None:
        return None

    if is_box:
        strike = get_closest_strike_price(
            index,
            current_date,
            trading_timestamp,
            leg_expiry,
            other_leg_ltp,
            leg.option_type,
            is_live,
        )
    elif leg.strike_selection.type == STRIKESELECTIONTYPE.BY_ATM_STRIKE:
        strike = atm + leg.strike_selection.value * strike_diff * leg.option_type.value
    elif leg.strike_selection.type == STRIKESELECTIONTYPE.BY_CLOSEST_PREMIUM:
        strike = get_closest_strike_price(
            index,
            current_date,
            trading_timestamp,
            leg_expiry,
            leg.strike_selection.value,
            leg.option_type,
            is_live,
        )
    elif leg.strike_selection.type == STRIKESELECTIONTYPE.BY_GE_PREMIUM:
        strike = get_ge_strike_price(
            index,
            current_date,
            trading_timestamp,
            leg_expiry,
            leg.strike_selection.value,
            leg.option_type,
            is_live,
        )
    elif leg.strike_selection.type == STRIKESELECTIONTYPE.BY_LE_PREMIUM:
        strike = get_le_strike_price(
            index,
            current_date,
            trading_timestamp,
            leg_expiry,
            leg.strike_selection.value,
            leg.option_type,
            is_live,
        )
    elif leg.strike_selection.type == STRIKESELECTIONTYPE.BY_MIN_STRIKE_DIFF:
        strike = get_min_diff_strike_price(
            index,
            current_date,
            trading_timestamp,
            leg_expiry,
            leg.strike_selection.value,
            leg.option_type,
            is_live,
        )
        strike = strike + leg.strike_selection.value * strike_diff * leg.option_type.value
    elif leg.strike_selection.type == STRIKESELECTIONTYPE.BY_CLOSEST_DELTA:
        monthly_expiry = get_monthly_expiry_date(index, current_date)
        if monthly_expiry == leg_expiry:
            fut_ohlc = get_quote(feed_source, index, current_date,trading_timestamp, trading_timestamp, option_type=OPTIONTYPE.FUT, expiry=monthly_expiry)
            fut_price = fut_ohlc.open

        else:
            atmceprice = get_quote(feed_source, index, current_date, trading_timestamp, trading_timestamp, option_type=OPTIONTYPE.CALL, expiry=leg_expiry, strike=atm, for_entry=False)
            atmpeprice = get_quote(feed_source, index, current_date, trading_timestamp, trading_timestamp, option_type=OPTIONTYPE.PUT, expiry=leg_expiry, strike=atm, for_entry=False)

            fut_price = atmceprice.open/100 - atmpeprice.open/100 + atm
            fut_price *= 100
        strike = get_strike_closest_to_delta(
            index,
            fut_price,
            atm,
            current_date,
            trading_timestamp,
            leg_expiry,
            leg.strike_selection.value,
            leg.option_type,
            is_live,
        )
    elif leg.strike_selection.type == STRIKESELECTIONTYPE.BY_GE_DELTA:
        monthly_expiry = get_monthly_expiry_date(index, current_date)
        if monthly_expiry == leg_expiry:
            fut_ohlc = get_quote(feed_source, index, current_date,trading_timestamp, trading_timestamp, option_type=OPTIONTYPE.FUT, expiry=monthly_expiry)
            fut_price = fut_ohlc.open

        else:
            atmceprice = get_quote(feed_source, index, current_date, trading_timestamp, trading_timestamp, option_type=OPTIONTYPE.CALL, expiry=leg_expiry, strike=atm, for_entry=False)
            atmpeprice = get_quote(feed_source, index, current_date, trading_timestamp, trading_timestamp, option_type=OPTIONTYPE.PUT, expiry=leg_expiry, strike=atm, for_entry=False)

            fut_price = atmceprice.open/100 - atmpeprice.open/100 + atm
            fut_price *= 100
        strike = get_strike_ge_delta(
            index,
            fut_price,
            atm,
            current_date,
            trading_timestamp,
            leg_expiry,
            leg.strike_selection.value,
            leg.option_type,
            is_live,
        )
    elif leg.strike_selection.type == STRIKESELECTIONTYPE.BY_LE_DELTA:
        monthly_expiry = get_monthly_expiry_date(index, current_date)
        if monthly_expiry == leg_expiry:
            fut_ohlc = get_quote(feed_source, index, current_date,trading_timestamp, trading_timestamp, option_type=OPTIONTYPE.FUT, expiry=monthly_expiry)
            fut_price = fut_ohlc.open

        else:
            atmceprice = get_quote(feed_source, index, current_date, trading_timestamp, trading_timestamp, option_type=OPTIONTYPE.CALL, expiry=leg_expiry, strike=atm, for_entry=False)
            atmpeprice = get_quote(feed_source, index, current_date, trading_timestamp, trading_timestamp, option_type=OPTIONTYPE.PUT, expiry=leg_expiry, strike=atm, for_entry=False)

            fut_price = atmceprice.open/100 - atmpeprice.open/100 + atm
            fut_price *= 100
        strike = get_strike_le_delta(
            index,
            fut_price,
            atm,
            current_date,
            trading_timestamp,
            leg_expiry,
            leg.strike_selection.value,
            leg.option_type,
            is_live,
        )
    elif leg.strike_selection.type == STRIKESELECTIONTYPE.BY_MATCH_PREMIUM:
        sign = leg.strike_selection.value.split("_")[0]
        value = float(leg.strike_selection.value.split("_")[1])
        atmceprice = get_quote(feed_source, index, current_date, trading_timestamp, trading_timestamp, option_type=OPTIONTYPE.CALL, expiry=leg_expiry, strike=atm)
        atmpeprice = get_quote(feed_source, index, current_date, trading_timestamp, trading_timestamp, option_type=OPTIONTYPE.PUT, expiry=leg_expiry, strike=atm)
        premium = max([atmceprice.open, atmpeprice.open]) if value > 0 else min([atmceprice.open, atmpeprice.open])
        if ((premium == atmceprice.open) and (leg.option_type == OPTIONTYPE.CALL)) or ((premium == atmpeprice.open) and (leg.option_type == OPTIONTYPE.PUT)):
            sign = "="
        if sign == "=":
            strike = get_closest_strike_price(
                index,
                current_date,
                trading_timestamp,
                leg_expiry,
                premium/100,
                leg.option_type,
                is_live,
            )
        elif sign == ">":
            strike = get_ge_strike_price(
                index,
                current_date,
                trading_timestamp,
                leg_expiry,
                premium/100,
                leg.option_type,
                is_live,
            )
        elif sign == "<":
            strike = get_le_strike_price(
                index,
                current_date,
                trading_timestamp,
                leg_expiry,
                premium/100,
                leg.option_type,
                is_live,
            )
    elif leg.strike_selection.type == STRIKESELECTIONTYPE.BY_ATM_STRADDLE:
        call_quote = get_quote(
            feed_source,
            index,
            current_date,
            trading_timestamp,
            trading_timestamp,
            leg_expiry,
            atm,
            OPTIONTYPE.CALL,
        )
        if not call_quote:
            return
        call_price = call_quote.open / 100.0
        put_quote = get_quote(
            feed_source,
            index,
            current_date,
            trading_timestamp,
            trading_timestamp,
            leg_expiry,
            atm,
            OPTIONTYPE.PUT,
        )
        if not put_quote:
            return
        put_price = put_quote.open / 100.0
        straddle_price = call_price + put_price
        strike_diff = get_strike_diff_for_index(index)
        strike = round_to(
            atm + (straddle_price * leg.strike_selection.value), strike_diff
        )
    elif leg.strike_selection.type == STRIKESELECTIONTYPE.BY_DYNAMIC_FACTOR:
        previous_day_closing_price = (
            get_previous_day_closing_price(
                index, available_trading_dates, current_date, is_live
            )
            / 100
        )
        previous_day_vix_value = (
            get_previous_day_vix_value(available_trading_dates, current_date, is_live)
            / 100
        )
        cal1 = (previous_day_closing_price / index_base_price) * 100
        cal2 = (previous_day_vix_value / fix_vix) * 100
        cal1_per = (cal1 / 100.0) - 1
        cal2_per = 1.5 * (cal2 / 100.0) - 1.5

        dynamic_vix = 100 * (1 + cal2_per)
        factor = ((1 + cal1_per) * dynamic_vix) / 3
        sign = leg.strike_selection.value.split("_")[0]
        value = float(leg.strike_selection.value.split("_")[1])
        premium = factor * value
        if sign == ">":
            strike = get_ge_strike_price(
                index,
                current_date,
                trading_timestamp,
                leg_expiry,
                premium,
                leg.option_type,
                is_live,
            )
        elif sign == "<":
            strike = get_le_strike_price(
                index,
                current_date,
                trading_timestamp,
                leg_expiry,
                premium,
                leg.option_type,
                is_live,
            )
        elif sign == "=":
            strike = get_closest_strike_price(
                index,
                current_date,
                trading_timestamp,
                leg_expiry,
                premium,
                leg.option_type,
                is_live,
            )
        else:
            raise Exception("Invalid sign")

    if leg.strike_selection.type in [
        STRIKESELECTIONTYPE.BY_ATM_STRIKE,
        STRIKESELECTIONTYPE.BY_ATM_STRADDLE,
    ]:  # for getting nearest strike
        strike = get_closest_valid_strike_price(
            index,
            current_date,
            trading_timestamp,
            leg_expiry,
            strike,
            leg.option_type,
            is_live,
        )

    leg.contract = Contract(exchange, index, leg_expiry, strike, leg.option_type)
    contract_ohlc = get_quote(
        feed_source,
        index,
        current_date,
        trading_timestamp,
        trading_timestamp,
        leg.contract.expiry_date,
        leg.contract.strike_price,
        leg.contract.option_type,
    )
    if not contract_ohlc:
        return
    if not leg.orb:
        leg.current_wait_and_trade = calculate_wait_points(
            contract_ohlc.open / 100.0, leg.wait_and_trade
        )
    else:
        leg.current_wait_and_trade = 0
    leg.contract_initial_price = contract_ohlc.open / 100.0

    # if not leg.leg_entry_price:
    #     leg.leg_entry_price = leg.contract_initial_price
    leg.status = LEGSTATUS.CONTRACTRIZED


def contractrize_vwap_leg(
    index: ENUMELEMENT,
    index_base_price: float,
    index_price: float,
    fix_vix: float,
    available_trading_dates: List[int],
    current_date: int,
    trading_timestamp: int,
    atm: float,
    strike_diff: int,
    exchange: ENUMELEMENT,
    leg: Leg,
    is_live: bool,
    feed_source: FEEDSOURCE,
    is_box: bool = False,
    other_leg_ltp: float = None,
):
    if leg.expiry_type == EXPIRYTYPE.WEEKLY:
        leg_expiry = get_current_week_expiry_date(index, current_date, is_live)
    elif leg.expiry_type == EXPIRYTYPE.NEXT_WEEKLY:
        leg_expiry = get_next_week_expiry_date(index, current_date, is_live)
    elif leg.expiry_type == EXPIRYTYPE.MONTHLY:
        leg_expiry = get_monthly_expiry_date(index, current_date, is_live)

    if leg.next_expiry_select == True and leg_expiry == current_date:
        leg_expiry = get_next_week_expiry_date(index, current_date, is_live)
    
    atm = get_closest_valid_strike_price(index, current_date, trading_timestamp, leg_expiry, atm, leg.option_type, is_live)
    
    # If ATM is None, skip this leg as data is not available
    if atm is None:
        return None

    if is_box:
        strike = get_closest_strike_price(
            index,
            current_date,
            trading_timestamp,
            leg_expiry,
            other_leg_ltp,
            leg.option_type,
            is_live,
        )
    elif leg.strike_selection.type == STRIKESELECTIONTYPE.BY_ATM_STRIKE:
        strike = atm + leg.strike_selection.value * strike_diff * leg.option_type.value
    elif leg.strike_selection.type == STRIKESELECTIONTYPE.BY_CLOSEST_PREMIUM:
        strike = get_closest_strike_price(
            index,
            current_date,
            trading_timestamp,
            leg_expiry,
            leg.strike_selection.value,
            leg.option_type,
            is_live,
        )
    elif leg.strike_selection.type == STRIKESELECTIONTYPE.BY_GE_PREMIUM:
        strike = get_ge_strike_price(
            index,
            current_date,
            trading_timestamp,
            leg_expiry,
            leg.strike_selection.value,
            leg.option_type,
            is_live,
        )
    elif leg.strike_selection.type == STRIKESELECTIONTYPE.BY_LE_PREMIUM:
        strike = get_le_strike_price(
            index,
            current_date,
            trading_timestamp,
            leg_expiry,
            leg.strike_selection.value,
            leg.option_type,
            is_live,
        )
    elif leg.strike_selection.type == STRIKESELECTIONTYPE.BY_CLOSEST_DELTA:
        monthly_expiry = get_monthly_expiry_date(index, current_date)
        if monthly_expiry == leg_expiry:
            fut_ohlc = get_quote(feed_source, index, current_date,trading_timestamp, trading_timestamp, option_type=OPTIONTYPE.FUT, expiry=monthly_expiry)
            fut_price = fut_ohlc.open

        else:
            atmceprice = get_quote(feed_source, index, current_date, trading_timestamp, trading_timestamp, option_type=OPTIONTYPE.CALL, expiry=leg_expiry, strike=atm, for_entry=False)
            atmpeprice = get_quote(feed_source, index, current_date, trading_timestamp, trading_timestamp, option_type=OPTIONTYPE.PUT, expiry=leg_expiry, strike=atm, for_entry=False)

            fut_price = atmceprice.open/100 - atmpeprice.open/100 + atm
            fut_price *= 100
        strike = get_strike_closest_to_delta(
            index,
            fut_price,
            atm,
            current_date,
            trading_timestamp,
            leg_expiry,
            leg.strike_selection.value,
            leg.option_type,
            is_live,
        )
    elif leg.strike_selection.type == STRIKESELECTIONTYPE.BY_GE_DELTA:
        monthly_expiry = get_monthly_expiry_date(index, current_date)
        if monthly_expiry == leg_expiry:
            fut_ohlc = get_quote(feed_source, index, current_date,trading_timestamp, trading_timestamp, option_type=OPTIONTYPE.FUT, expiry=monthly_expiry)
            fut_price = fut_ohlc.open

        else:
            atmceprice = get_quote(feed_source, index, current_date, trading_timestamp, trading_timestamp, option_type=OPTIONTYPE.CALL, expiry=leg_expiry, strike=atm, for_entry=False)
            atmpeprice = get_quote(feed_source, index, current_date, trading_timestamp, trading_timestamp, option_type=OPTIONTYPE.PUT, expiry=leg_expiry, strike=atm, for_entry=False)

            fut_price = atmceprice.open/100 - atmpeprice.open/100 + atm
            fut_price *= 100
        strike = get_strike_ge_delta(
            index,
            fut_price,
            atm,
            current_date,
            trading_timestamp,
            leg_expiry,
            leg.strike_selection.value,
            leg.option_type,
            is_live,
        )
    elif leg.strike_selection.type == STRIKESELECTIONTYPE.BY_LE_DELTA:
        monthly_expiry = get_monthly_expiry_date(index, current_date)
        if monthly_expiry == leg_expiry:
            fut_ohlc = get_quote(feed_source, index, current_date,trading_timestamp, trading_timestamp, option_type=OPTIONTYPE.FUT, expiry=monthly_expiry)
            fut_price = fut_ohlc.open

        else:
            atmceprice = get_quote(feed_source, index, current_date, trading_timestamp, trading_timestamp, option_type=OPTIONTYPE.CALL, expiry=leg_expiry, strike=atm, for_entry=False)
            atmpeprice = get_quote(feed_source, index, current_date, trading_timestamp, trading_timestamp, option_type=OPTIONTYPE.PUT, expiry=leg_expiry, strike=atm, for_entry=False)

            fut_price = atmceprice.open/100 - atmpeprice.open/100 + atm
            fut_price *= 100
        strike = get_strike_le_delta(
            index,
            fut_price,
            atm,
            current_date,
            trading_timestamp,
            leg_expiry,
            leg.strike_selection.value,
            leg.option_type,
            is_live,
        )
    elif leg.strike_selection.type == STRIKESELECTIONTYPE.BY_ATM_STRADDLE:
        call_quote = get_quote(
            feed_source,
            index,
            current_date,
            trading_timestamp,
            trading_timestamp,
            leg_expiry,
            atm,
            OPTIONTYPE.CALL,
        )
        if not call_quote:
            return
        call_price = call_quote.open / 100.0
        put_quote = get_quote(
            feed_source,
            index,
            current_date,
            trading_timestamp,
            trading_timestamp,
            leg_expiry,
            atm,
            OPTIONTYPE.PUT,
        )
        if not put_quote:
            return
        put_price = put_quote.open / 100.0
        straddle_price = call_price + put_price
        strike_diff = get_strike_diff_for_index(index)
        strike = round_to(
            atm + (straddle_price * leg.strike_selection.value), strike_diff
        )
    elif leg.strike_selection.type == STRIKESELECTIONTYPE.BY_DYNAMIC_FACTOR:
        previous_day_closing_price = (
            get_previous_day_closing_price(
                index, available_trading_dates, current_date, is_live
            )
            / 100
        )
        previous_day_vix_value = (
            get_previous_day_vix_value(available_trading_dates, current_date, is_live)
            / 100
        )
        cal1 = (previous_day_closing_price / index_base_price) * 100
        cal2 = (previous_day_vix_value / fix_vix) * 100
        cal1_per = (cal1 / 100.0) - 1
        cal2_per = 1.5 * (cal2 / 100.0) - 1.5

        dynamic_vix = 100 * (1 + cal2_per)
        factor = ((1 + cal1_per) * dynamic_vix) / 3
        sign = leg.strike_selection.value.split("_")[0]
        value = float(leg.strike_selection.value.split("_")[1])
        premium = factor * value
        if sign == ">":
            strike = get_ge_strike_price(
                index,
                current_date,
                trading_timestamp,
                leg_expiry,
                premium,
                leg.option_type,
                is_live,
            )
        elif sign == "<":
            strike = get_le_strike_price(
                index,
                current_date,
                trading_timestamp,
                leg_expiry,
                premium,
                leg.option_type,
                is_live,
            )
        elif sign == "=":
            strike = get_closest_strike_price(
                index,
                current_date,
                trading_timestamp,
                leg_expiry,
                premium,
                leg.option_type,
                is_live,
            )
        else:
            raise Exception("Invalid sign")

    if leg.strike_selection.type in [
        STRIKESELECTIONTYPE.BY_ATM_STRIKE,
        STRIKESELECTIONTYPE.BY_ATM_STRADDLE,
    ]:  # for getting nearest strike
        strike = get_closest_valid_strike_price(
            index,
            current_date,
            trading_timestamp,
            leg_expiry,
            strike,
            leg.option_type,
            is_live,
        )

    leg.contract = Contract(exchange, index, leg_expiry, strike, leg.option_type)
    contract_ohlc = get_quote(
        feed_source,
        index,
        current_date,
        trading_timestamp,
        trading_timestamp,
        leg.contract.expiry_date,
        leg.contract.strike_price,
        leg.contract.option_type,
    )
    if not contract_ohlc:
        return
    leg.contract_initial_price = contract_ohlc.open / 100.0
    # if not leg.leg_entry_price:
    #     leg.leg_entry_price = leg.contract_initial_price
    leg.status = LEGSTATUS.CONTRACTRIZED


def get_underlying_ohlc(
    strategy: Strategy,
    current_date,
    monthly_expiry,
    trading_timestamp,
    feed_source,
    is_live,
):
    if strategy.underlying == UNDERLYINGTYPE.FUTURE:
        return get_quote(
            feed_source,
            strategy.index,
            current_date,
            trading_timestamp,
            trading_timestamp,
            option_type=OPTIONTYPE.FUT,
            expiry=monthly_expiry,
        )
    elif strategy.underlying == UNDERLYINGTYPE.CASH:
        return get_quote(
            feed_source,
            strategy.index,
            current_date,
            trading_timestamp,
            trading_timestamp,
        )


def is_box_created(
    strategy: Strategy,
    index_base_price,
    index_price,
    fix_vix,
    available_trading_dates,
    current_date,
    trading_timestamp,
    atm,
    strike_diff,
    exchange,
    feed_source,
    is_live,
):
    if strategy.is_first_entry:
        if len(strategy.legs) != 2:
            raise Exception("Box strategy should have 2 legs")
        for leg in strategy.legs:
            if (
                leg.status != LEGSTATUS.CONTRACTRIZED
                or not strategy.box.contractrize_only_once
            ):
                contractrize_leg(
                    strategy.index,
                    index_base_price,
                    index_price,
                    fix_vix,
                    available_trading_dates,
                    current_date,
                    trading_timestamp,
                    atm,
                    strike_diff,
                    exchange,
                    leg,
                    is_live,
                    feed_source,
                )

            if leg.status == LEGSTATUS.CONTRACTRIZED:
                leg.contract.ltp = (
                    get_quote(
                        feed_source,
                        leg.contract.symbol,
                        current_date,
                        trading_timestamp,
                        leg.contract.expiry_date,
                        leg.contract.strike_price,
                        leg.contract.option_type,
                    ).open
                    / 100
                )
        is_all_leg_contractrized = all(
            [leg.status == LEGSTATUS.CONTRACTRIZED for leg in strategy.legs]
        )
        if is_all_leg_contractrized:
            strategy.current_box_diff = calculate_box_diff_points(
                strategy.legs[0].contract.ltp,
                strategy.legs[1].contract.ltp,
                strategy.box.diff,
            )
            if is_box_diff_hit(
                strategy.legs[0].contract.ltp,
                strategy.legs[1].contract.ltp,
                strategy.current_box_diff,
            ):
                strategy.is_first_entry = False
            if strategy.box.duration <= trading_timestamp:
                if strategy.box.force_entry:
                    if strategy.box.force_entry_type == FORCEENTRYTYPE.HIGHER_PREMIUM:
                        if (
                            strategy.legs[0].contract.ltp
                            > strategy.legs[1].contract.ltp
                        ):
                            premium = strategy.legs[0].contract.ltp
                            contractrize_leg(
                                strategy.index,
                                index_base_price,
                                index_price,
                                fix_vix,
                                available_trading_dates,
                                current_date,
                                trading_timestamp,
                                atm,
                                strike_diff,
                                exchange,
                                strategy.legs[1],
                                is_live,
                                feed_source,
                                True,
                                premium,
                            )
                            strategy.is_first_entry = False
                        else:
                            premium = strategy.legs[1].contract.ltp
                            contractrize_leg(
                                strategy.index,
                                index_base_price,
                                index_price,
                                fix_vix,
                                available_trading_dates,
                                current_date,
                                trading_timestamp,
                                atm,
                                strike_diff,
                                exchange,
                                strategy.legs[0],
                                is_live,
                                feed_source,
                                True,
                                premium,
                            )
                            strategy.is_first_entry = False
                    else:
                        if (
                            strategy.legs[0].contract.ltp
                            < strategy.legs[1].contract.ltp
                        ):
                            premium = strategy.legs[0].contract.ltp
                            contractrize_leg(
                                strategy.index,
                                index_base_price,
                                index_price,
                                fix_vix,
                                available_trading_dates,
                                current_date,
                                trading_timestamp,
                                atm,
                                strike_diff,
                                exchange,
                                strategy.legs[1],
                                is_live,
                                feed_source,
                                True,
                                premium,
                            )
                            strategy.is_first_entry = False
                        else:
                            premium = strategy.legs[1].contract.ltp
                            contractrize_leg(
                                strategy.index,
                                index_base_price,
                                index_price,
                                fix_vix,
                                available_trading_dates,
                                current_date,
                                trading_timestamp,
                                atm,
                                strike_diff,
                                exchange,
                                strategy.legs[0],
                                is_live,
                                feed_source,
                                True,
                                premium,
                            )
                            strategy.is_first_entry = False
                else:
                    strategy.status = STRATEGYSTATUS.STOPPED

        if strategy.is_first_entry:
            return False
        else:
            return True


def get_pnl_dict(
    minute_ohlc: OHLC,
    profit_index_ohlc: OHLC,
    loss_index_ohlc: OHLC,
    profit_ohlc: OHLC,
    loss_ohlc: OHLC,
    last_order: Order,
    leg: Leg,
    evaluator_type="",
):
    pnl_dict = {}
    profit_type = NUMBERTYPE.POINT
    if evaluator_type != "Vwap":
        profit_type = leg.take_profit.type

    pnl_dict["minute_open_profit"] = calculate_current_pnl(
        minute_ohlc.open / 100.0, last_order.average_price, last_order.side, profit_type
    )
    pnl_dict["minute_close_profit"] = calculate_current_pnl(
        minute_ohlc.close / 100.0,
        last_order.average_price,
        last_order.side,
        profit_type,
    )
    pnl_dict["minute_high_profit"] = calculate_current_pnl(
        minute_ohlc.high / 100.0, last_order.average_price, last_order.side, profit_type
    )
    pnl_dict["minute_low_profit"] = calculate_current_pnl(
        minute_ohlc.low / 100.0, last_order.average_price, last_order.side, profit_type
    )

    pnl_dict["minute_open_loss"] = calculate_current_pnl(
        minute_ohlc.open / 100.0, last_order.average_price, last_order.side, profit_type
    )
    pnl_dict["minute_close_loss"] = calculate_current_pnl(
        minute_ohlc.close / 100.0,
        last_order.average_price,
        last_order.side,
        profit_type,
    )
    pnl_dict["minute_high_loss"] = calculate_current_pnl(
        minute_ohlc.high / 100.0, last_order.average_price, last_order.side, profit_type
    )
    pnl_dict["minute_low_loss"] = calculate_current_pnl(
        minute_ohlc.low / 100.0, last_order.average_price, last_order.side, profit_type
    )

    pnl_dict["index_open_profit"] = calculate_current_pnl(
        profit_index_ohlc.open / 100.0,
        last_order.index_price,
        last_order.side,
        profit_type,
    )
    pnl_dict["index_close_profit"] = calculate_current_pnl(
        profit_index_ohlc.close / 100.0,
        last_order.index_price,
        last_order.side,
        profit_type,
    )
    pnl_dict["index_high_profit"] = calculate_current_pnl(
        profit_index_ohlc.high / 100.0,
        last_order.index_price,
        last_order.side,
        profit_type,
    )
    pnl_dict["index_low_profit"] = calculate_current_pnl(
        profit_index_ohlc.low / 100.0,
        last_order.index_price,
        last_order.side,
        profit_type,
    )

    pnl_dict["index_open_loss"] = calculate_current_pnl(
        loss_index_ohlc.open / 100.0,
        last_order.index_price,
        last_order.side,
        profit_type,
    )
    pnl_dict["index_close_loss"] = calculate_current_pnl(
        loss_index_ohlc.close / 100.0,
        last_order.index_price,
        last_order.side,
        profit_type,
    )
    pnl_dict["index_high_loss"] = calculate_current_pnl(
        loss_index_ohlc.high / 100.0,
        last_order.index_price,
        last_order.side,
        profit_type,
    )
    pnl_dict["index_low_loss"] = calculate_current_pnl(
        loss_index_ohlc.low / 100.0,
        last_order.index_price,
        last_order.side,
        profit_type,
    )

    if leg.contract.option_type == OPTIONTYPE.PUT:
        pnl_dict["index_open_profit"] = -pnl_dict["index_open_profit"]
        pnl_dict["index_close_profit"] = -pnl_dict["index_close_profit"]
        pnl_dict["index_high_profit"] = -pnl_dict["index_high_profit"]
        pnl_dict["index_low_profit"] = -pnl_dict["index_low_profit"]

        pnl_dict["index_open_loss"] = -pnl_dict["index_open_loss"]
        pnl_dict["index_close_loss"] = -pnl_dict["index_close_loss"]
        pnl_dict["index_high_loss"] = -pnl_dict["index_high_loss"]
        pnl_dict["index_low_loss"] = -pnl_dict["index_low_loss"]

    pnl_dict["open_loss"] = calculate_current_pnl(
        loss_ohlc.open / 100.0, last_order.average_price, last_order.side, profit_type
    )
    pnl_dict["close_loss"] = calculate_current_pnl(
        loss_ohlc.close / 100.0, last_order.average_price, last_order.side, profit_type
    )
    pnl_dict["high_loss"] = calculate_current_pnl(
        loss_ohlc.high / 100.0, last_order.average_price, last_order.side, profit_type
    )
    pnl_dict["low_loss"] = calculate_current_pnl(
        loss_ohlc.low / 100.0, last_order.average_price, last_order.side, profit_type
    )

    pnl_dict["open_profit"] = calculate_current_pnl(
        profit_ohlc.open / 100.0, last_order.average_price, last_order.side, profit_type
    )

    pnl_dict["close_profit"] = calculate_current_pnl(
        profit_ohlc.close / 100.0,
        last_order.average_price,
        last_order.side,
        profit_type,
    )

    pnl_dict["high_profit"] = calculate_current_pnl(
        profit_ohlc.high / 100.0, last_order.average_price, last_order.side, profit_type
    )

    pnl_dict["low_profit"] = calculate_current_pnl(
        profit_ohlc.low / 100.0, last_order.average_price, last_order.side, profit_type
    )

    return pnl_dict


def is_sl_hit(
    strategy: Strategy,
    leg: Leg,
    current_date: int,
    trading_timestamp: int,
    atm: float,
    current_stop_loss: float,
    last_order: Order,
    feed_source: str,
):
    is_sl_hit = False
    is_stop_loss_check_time_update = False
    delta_based_sl = leg.stop_loss.type == NUMBERTYPE.ABSOLUTE_DELTA
    if (
        leg.stop_loss.params.check_frequency == Config.BT_FREQUENCY
        or strategy.last_stop_loss_check_time + leg.stop_loss.params.check_frequency
        <= trading_timestamp
    ):
        if delta_based_sl:
            if atm > leg.contract.strike_price:
                ohlc = get_quote(
                    feed_source,
                    last_order.contract.symbol,
                    current_date,
                    strategy.last_stop_loss_check_time + Config.BT_FREQUENCY,
                    trading_timestamp,
                    last_order.contract.expiry_date,
                    last_order.contract.strike_price,
                    OPTIONTYPE.CALL
                )
                option_type_ = OPTIONTYPE.CALL
            else:
                ohlc = get_quote(
                    feed_source,
                    last_order.contract.symbol,
                    current_date,
                    strategy.last_stop_loss_check_time + Config.BT_FREQUENCY,
                    trading_timestamp,
                    last_order.contract.expiry_date,
                    last_order.contract.strike_price,
                    OPTIONTYPE.PUT
                )
                option_type_ = OPTIONTYPE.PUT
            monthly_expiry = get_monthly_expiry_date(strategy.index, current_date)
            if monthly_expiry == leg.contract.expiry_date:
                fut_ohlc = get_quote(feed_source, strategy.index, current_date,trading_timestamp, trading_timestamp, option_type=OPTIONTYPE.FUT, expiry=monthly_expiry)
                fut_price = fut_ohlc.open

            else:
                atmceprice = get_quote(feed_source, strategy.index, current_date, trading_timestamp, trading_timestamp, option_type=OPTIONTYPE.CALL, expiry=leg.contract.expiry_date, strike=atm, for_entry=False)
                atmpeprice = get_quote(feed_source, strategy.index, current_date, trading_timestamp, trading_timestamp, option_type=OPTIONTYPE.PUT, expiry=leg.contract.expiry_date, strike=atm, for_entry=False)

                fut_price = atmceprice.open/100 - atmpeprice.open/100 + atm
                fut_price *= 100
            t = (numpy.datetime64(datetime.combine(datetime.strptime(str(leg.contract.expiry_date), "%y%m%d").date(), datetime(2021, 1, 1, 15, 30, 0).time())) - numpy.datetime64(datetime.strptime(str(int(current_date)), '%y%m%d')+timedelta(seconds=trading_timestamp))).astype(TD64S) / SECONDS_IN_A_DAY
            call_delta, put_delta = get_deltas(fut_price, ohlc.open, leg.contract.strike_price, option_type_.name, t)
            if leg.contract.option_type == OPTIONTYPE.CALL:
                if leg.side == SIDE.BUY:
                    is_sl_hit = is_stop_loss_hit(call_delta, -leg.stop_loss.value)
                else:
                    is_sl_hit = is_stop_loss_hit(leg.stop_loss.value, -call_delta)
            else:
                if leg.side == SIDE.BUY:
                    is_sl_hit = is_stop_loss_hit(leg.stop_loss.value, -put_delta)
                else:
                    is_sl_hit = is_stop_loss_hit(put_delta, -leg.stop_loss.value)

        else:
            is_sl_hit = is_stop_loss_hit(current_stop_loss, leg.current_stop_loss)
        is_stop_loss_check_time_update = True

    return is_sl_hit, delta_based_sl, is_stop_loss_check_time_update


def is_tp_hit(
    strategy: Strategy,
    leg: Leg,
    current_date: int,
    trading_timestamp: int,
    atm: float,
    current_profit: float,
    last_order: Order,
    feed_source: str,
):
    is_tp_hit = False
    delta_based_tp = leg.take_profit.type == NUMBERTYPE.ABSOLUTE_DELTA
    is_take_profit_check_time_update = False
    if (
        leg.take_profit.params.check_frequency == Config.BT_FREQUENCY
        or strategy.last_take_profit_check_time + leg.take_profit.params.check_frequency
        <= trading_timestamp
    ):
        if delta_based_tp:
            if atm > leg.contract.strike_price:
                ohlc = get_quote(
                    feed_source,
                    last_order.contract.symbol,
                    current_date,
                    strategy.last_stop_loss_check_time + Config.BT_FREQUENCY,
                    trading_timestamp,
                    last_order.contract.expiry_date,
                    last_order.contract.strike_price,
                    OPTIONTYPE.CALL
                )
                option_type_ = OPTIONTYPE.CALL
            else:
                ohlc = get_quote(
                    feed_source,
                    last_order.contract.symbol,
                    current_date,
                    strategy.last_stop_loss_check_time + Config.BT_FREQUENCY,
                    trading_timestamp,
                    last_order.contract.expiry_date,
                    last_order.contract.strike_price,
                    OPTIONTYPE.PUT
                )
                option_type_ = OPTIONTYPE.PUT
            monthly_expiry = get_monthly_expiry_date(strategy.index, current_date)
            if monthly_expiry == leg.contract.expiry_date:
                fut_ohlc = get_quote(feed_source, strategy.index, current_date,trading_timestamp, trading_timestamp, option_type=OPTIONTYPE.FUT, expiry=monthly_expiry)
                fut_price = fut_ohlc.open

            else:
                atmceprice = get_quote(feed_source, strategy.index, current_date, trading_timestamp, trading_timestamp, option_type=OPTIONTYPE.CALL, expiry=leg.contract.expiry_date, strike=atm, for_entry=False)
                atmpeprice = get_quote(feed_source, strategy.index, current_date, trading_timestamp, trading_timestamp, option_type=OPTIONTYPE.PUT, expiry=leg.contract.expiry_date, strike=atm, for_entry=False)

                fut_price = atmceprice.open/100 - atmpeprice.open/100 + atm
                fut_price *= 100
            t = (numpy.datetime64(datetime.combine(datetime.strptime(str(leg.contract.expiry_date), "%y%m%d").date(), datetime(2021, 1, 1, 15, 30, 0).time())) - numpy.datetime64(datetime.strptime(str(int(current_date)), '%y%m%d')+timedelta(seconds=trading_timestamp))).astype(TD64S) / SECONDS_IN_A_DAY
            call_delta, put_delta = get_deltas(fut_price, ohlc.open, leg.contract.strike_price, option_type_.name, t)
            if leg.contract.option_type == OPTIONTYPE.CALL:
                if leg.side == SIDE.BUY:
                    is_tp_hit = is_take_profit_hit(call_delta, leg.take_profit.value)
                else:
                    is_tp_hit = is_take_profit_hit(leg.take_profit.value, call_delta)
            else:
                if leg.side == SIDE.BUY:
                    is_tp_hit = is_take_profit_hit(leg.take_profit.value, put_delta)
                else:
                    is_tp_hit = is_take_profit_hit(put_delta, leg.take_profit.value)
        else:
            delta_based_tp = False
            is_tp_hit = is_take_profit_hit(current_profit, leg.current_take_profit)
        is_take_profit_check_time_update = True

    return is_tp_hit, delta_based_tp, is_take_profit_check_time_update


def place_hedge_exit_order(
    strategy: Strategy,
    leg: Leg,
    product_type,
    order_type,
    current_date,
    trading_timestamp,
    index_price,
    broker,
    client_id,
    reason,
    orders,
):
    hedge_exit_order = Order(
        strategy.entry_number,
        strategy.name,
        leg.hedge.id,
        leg.entry_number,
        leg.stop_loss_entry_number,
        leg.take_profit_entry_number,
        leg.hedge.contract,
        product_type,
        order_type,
        reverse_side(leg.hedge.side),
        0,
        0,
        leg.quantity * leg.multiplier,
        TimeStamp(current_date, trading_timestamp),
        index_price,
        reason,
    )
    broker_order_id = place_order(broker, client_id, hedge_exit_order)
    hedge_exit_order.broker_order_id = broker_order_id
    orders.append(hedge_exit_order)
    leg.hedge.exit_order = hedge_exit_order
    leg.status = LEGSTATUS.WAITING_FOR_HEDGE_EXIT


def running_leg_count(legs: List[Leg]):
    return len([leg for leg in legs if leg.status not in [LEGSTATUS.CREATED, LEGSTATUS.CONTRACTRIZED, LEGSTATUS.EXITED]])

def place_exit_order(
    strategy: Strategy,
    leg: Leg,
    last_order: Order,
    product_type,
    order_type,
    current_date,
    trading_timestamp,
    index_price,
    reason: str,
    broker,
    client_id,
    exit_price,
    orders: List[Order],
    new_leg_status,
):
    order = Order(
        strategy.entry_number,
        strategy.name,
        leg.id,
        leg.entry_number,
        leg.stop_loss_entry_number,
        leg.take_profit_entry_number,
        last_order.contract,
        product_type,
        order_type,
        reverse_side(leg.side),
        0,
        0,
        last_order.quantity,
        TimeStamp(current_date, trading_timestamp),
        index_price,
        reason,
    )
    broker_order_id = place_order(broker, client_id, order, exit_price)
    order.broker_order_id = broker_order_id
    orders.append(order)
    leg.orders.append(order)
    leg.status = new_leg_status


def get_rsi(
    index: ENUMELEMENT,
    rsi: Rsi,
    current_date: int,
    previous_date: int,
    trading_timestamp: int,
    is_live: bool,
):
    candles: List[OHLC] = get_candles(
        index,
        rsi.length * 3,
        rsi.interval,
        current_date,
        previous_date,
        trading_timestamp,
        is_live,
    )
    if len(candles) == 0:
        return None
    candles_close = {"close": [candle.close / 100.0 for candle in candles]}
    df = pd.DataFrame(candles_close)
    ta_rsi = ta.rsi(df["close"], rsi.length)
    return ta_rsi.iloc[-1]


def get_heikin_ashi(candles: list[OHLC]):
    if (candles is None) or len(candles) == 0:
        return None

    heikin_ashi_candles: List[OHLC] = []
    for i in range(len(candles)):
        current_candle = candles[i]
        close = (
            current_candle.open
            + current_candle.high
            + current_candle.low
            + current_candle.close
        ) / 4
        previous_candle = candles[i] if i == 0 else heikin_ashi_candles[-1]
        open = (previous_candle.open + previous_candle.close) / 2
        high = max([current_candle.high, open, close])
        low = min([current_candle.low, open, close])
        heikin_ashi_candles.append(
            OHLC(
                current_candle.date,
                current_candle.time,
                open,
                high,
                low,
                close,
                current_candle.volume,
            )
        )

    return heikin_ashi_candles


def get_combined_candle(
    index: ENUMELEMENT,
    legs: List[Leg],
    length: int,
    interval: int,
    current_date: int,
    previous_date: int,
    trading_timestamp: int,
    is_live: bool,
    today_data: bool=False,
) -> List[OHLC]:
    combined_candles: List[OHLC] = None
    for leg in legs:
        candles: List[OHLC] = get_candles(
            index,
            int(length * 3 * interval / 60),
            60,
            current_date,
            previous_date,
            trading_timestamp,
            leg.contract.expiry_date,
            leg.contract.strike_price,
            leg.contract.option_type,
            is_live,
            today_data
        )
        if combined_candles:
            for candle in candles:
                for combined_candle in combined_candles:
                    if combined_candle.time == candle.time:
                        combined_candle.open += candle.open
                        combined_candle.high += candle.high
                        combined_candle.low += candle.low
                        combined_candle.close += candle.close
                        combined_candle.volume += candle.volume
        else:
            combined_candles = candles
            
    final_candles = []
    mins_per_candle = int(interval/60)
    # candles_count =  (length * 3)*(mins_per_candle)
    if not today_data:
        combined_candles = combined_candles[1:]
    if len(combined_candles) >= mins_per_candle:
        for i in range(mins_per_candle, len(combined_candles) + mins_per_candle, mins_per_candle):
            candles_slice = combined_candles[i-mins_per_candle:i]
            volume = 0
            for candle in candles_slice:
                volume += candle.volume
            final_candle = OHLC(
                current_date,
                candles_slice[0].time,
                open=candles_slice[0].open,
                high=max([candle.high for candle in candles_slice]),
                low=min([candle.low for candle in candles_slice]),
                close=candles_slice[-1].close,
                volume=volume,
                coi= sum([candle.coi for candle in candles_slice if candle.coi is not None])
            )
            final_candles.append(final_candle)
    return final_candles


def to_timeindex(row):
    return datetime.strptime(str(row.date), "%y%m%d") + timedelta(seconds=int(row.time))


def eval_indicators(indicators: List, data, today_data = None):
    stack = []
    for indicator in indicators:
        if indicator not in ["or", "and"]:
            if type(indicator).__name__ == "VwapIndicator":
                stack.append(indicator.eval(today_data))
            else:
                stack.append(indicator.eval(data))
        else:
            indicator_1 = stack.pop(-1)
            indicator_2 = stack.pop(-1)
            stack.append(eval(str(indicator_1) + f" {indicator} " + str(indicator_2)))
    return stack[-1]


def evaluate_leg_entry(
    strategy: Strategy,
    leg: Leg,
    timestamp: int,
    exit_time: int,
    index_base_price,
    index_price,
    fix_vix,
    available_trading_dates,
    current_date,
    trading_timestamp,
    atm,
    strike_diff,
    exchange,
    is_live,
    feed_source,
    orders,
    broker,
    client_id,
    order_type,
    product_type,
):
    
    if not leg.is_wait_in_time_updated:
        leg.wait_in_time -= Config.BT_FREQUENCY
        leg.is_wait_in_time_updated = True
    is_immidiate_reentry = False
    if is_time_for_exit(timestamp, exit_time):
        leg.status == LEGSTATUS.EXITED
        return
    if (
        leg.status in [LEGSTATUS.ENTERED, LEGSTATUS.EXIT_TRIGGERED]
        or leg.status == LEGSTATUS.EXITED
        or not leg.is_activated
        or leg.next_action_time > trading_timestamp
    ):
        return
    if leg.status == LEGSTATUS.CREATED:
        # logger.info("Created")
        contractrize_leg(
            strategy.index,
            index_base_price,
            index_price,
            fix_vix,
            available_trading_dates,
            current_date,
            trading_timestamp,
            atm,
            strike_diff,
            exchange,
            leg,
            is_live,
            feed_source,
        )
    if leg.status == LEGSTATUS.STOP_LOSS_REENTRY:
        logger.info("Stop Loss reentry")
        leg.wait_in_time = (
            leg.stop_loss_reentry.value.check_frequency
            - (trading_timestamp - strategy.entry_time)
            % leg.stop_loss_reentry.value.check_frequency
        )
        leg.wait_in_time_devider = leg.stop_loss_reentry.value.check_frequency
        leg.is_wait_in_time_updated = True
        if leg.stop_loss_reentry.value.cutoff_time < trading_timestamp:
            leg.status = LEGSTATUS.EXITED
            return
        if leg.stop_loss_reentry.type == REENTRYTYPE.IMMIDIATE:
            is_immidiate_reentry = True
            leg.status = LEGSTATUS.CONTRACTRIZED
        elif leg.stop_loss_reentry.type == REENTRYTYPE.IMMIDIATE_NC:
            contractrize_leg(
                strategy.index,
                index_base_price,
                index_price,
                fix_vix,
                available_trading_dates,
                current_date,
                trading_timestamp,
                atm,
                strike_diff,
                exchange,
                leg,
                is_live,
                feed_source,
            )
            is_immidiate_reentry = True
        elif leg.stop_loss_reentry.type == REENTRYTYPE.AS_ORIGINAL:
            contractrize_leg(
                strategy.index,
                index_base_price,
                index_price,
                fix_vix,
                available_trading_dates,
                current_date,
                trading_timestamp,
                atm,
                strike_diff,
                exchange,
                leg,
                is_live,
                feed_source,
            )
            leg.is_waiting_for_stop_loss_reentry = True
        elif leg.stop_loss_reentry.type == REENTRYTYPE.RE_COST:
            contract_ohlc = get_quote(
                feed_source,
                leg.contract.symbol,
                current_date,
                trading_timestamp,
                trading_timestamp,
                leg.contract.expiry_date,
                leg.contract.strike_price,
                leg.contract.option_type,
                True,
            )
            if not contract_ohlc:
                return
            # if leg.wait_and_trade.value == 0:
            if not leg.recost_entry_on_crossover:
                leg.current_wait_and_trade = (
                    leg.leg_entry_price - contract_ohlc.open / 100
                )
                leg.contract_initial_price = contract_ohlc.open / 100
            else:
                leg.current_wait_and_trade = leg.leg_entry_price - leg.contract.ltp
                leg.contract_initial_price = leg.contract.ltp

            if not leg.recost_entry_on_crossover:
                if leg.side == SIDE.SELL and leg.current_wait_and_trade > 0:
                    is_immidiate_reentry = True
                elif leg.side == SIDE.BUY and leg.current_wait_and_trade < 0:
                    is_immidiate_reentry = True
            leg.is_waiting_for_stop_loss_reentry = True
            contract_ohlc = None
            leg.status = LEGSTATUS.CONTRACTRIZED
        else:
            logger.error("Reentry type not supported")
        leg.stop_loss_reentry_remaining -= 1
    elif leg.status == LEGSTATUS.TAKE_PROFIT_REENTRY:
        leg.wait_in_time = (
            leg.take_profit_reentry.value.check_frequency
            - (trading_timestamp - strategy.entry_time)
            % leg.take_profit_reentry.value.check_frequency
        )
        leg.wait_in_time_devider = leg.take_profit_reentry.value.check_frequency
        leg.is_wait_in_time_updated = True
        if leg.take_profit_reentry.value.cutoff_time < trading_timestamp:
            leg.status = LEGSTATUS.EXITED
            return
        if leg.take_profit_reentry.type == REENTRYTYPE.IMMIDIATE:
            is_immidiate_reentry = True
            leg.status = LEGSTATUS.CONTRACTRIZED
        elif leg.take_profit_reentry.type == REENTRYTYPE.IMMIDIATE_NC:
            contractrize_leg(
                strategy.index,
                index_base_price,
                index_price,
                fix_vix,
                available_trading_dates,
                current_date,
                trading_timestamp,
                atm,
                strike_diff,
                exchange,
                leg,
                is_live,
                feed_source,
            )
            is_immidiate_reentry = True
        elif leg.take_profit_reentry.type == REENTRYTYPE.AS_ORIGINAL:
            contractrize_leg(
                strategy.index,
                index_base_price,
                index_price,
                fix_vix,
                available_trading_dates,
                current_date,
                trading_timestamp,
                atm,
                strike_diff,
                exchange,
                leg,
                is_live,
                feed_source,
            )
            leg.is_waiting_for_take_profit_reentry = True
        elif leg.take_profit_reentry.type == REENTRYTYPE.RE_COST:
            contract_ohlc = get_quote(
                feed_source,
                leg.contract.symbol,
                current_date,
                trading_timestamp,
                trading_timestamp,
                leg.contract.expiry_date,
                leg.contract.strike_price,
                leg.contract.option_type,
                True,
            )
            if not contract_ohlc:
                return
            if not leg.recost_entry_on_crossover:
                leg.current_wait_and_trade = (
                    leg.leg_entry_price - contract_ohlc.open / 100
                )
                leg.contract_initial_price = contract_ohlc.open / 100
            else:
                leg.current_wait_and_trade = leg.leg_entry_price - leg.contract.ltp
                leg.contract_initial_price = leg.contract.ltp

            if not leg.recost_entry_on_crossover:
                if leg.side == SIDE.SELL and leg.current_wait_and_trade < 0:
                    is_immidiate_reentry = True
                elif leg.side == SIDE.BUY and leg.current_wait_and_trade > 0:
                    is_immidiate_reentry = True
            leg.is_waiting_for_take_profit_reentry = True
            contract_ohlc = None
            leg.status = LEGSTATUS.CONTRACTRIZED
        else:
            logger.error("Reentry type not supported")
        leg.take_profit_reentry_remaining -= 1

    elif leg.status == LEGSTATUS.TRIGGER_REENTRY:
        leg.wait_in_time = (
            leg.triggered_reentry.value.check_frequency
            - (trading_timestamp - strategy.entry_time)
            % leg.triggered_reentry.value.check_frequency
        )
        leg.wait_in_time_devider = leg.triggered_reentry.value.check_frequency
        leg.is_wait_in_time_updated = True
        if leg.triggered_reentry.value.cutoff_time < trading_timestamp:
            leg.status = LEGSTATUS.EXITED
            return
        if leg.triggered_reentry.type == REENTRYTYPE.IMMIDIATE:
            is_immidiate_reentry = True
            leg.status = LEGSTATUS.CONTRACTRIZED
        elif leg.triggered_reentry.type == REENTRYTYPE.IMMIDIATE_NC:
            contractrize_leg(
                strategy.index,
                index_base_price,
                index_price,
                fix_vix,
                available_trading_dates,
                current_date,
                trading_timestamp,
                atm,
                strike_diff,
                exchange,
                leg,
                is_live,
                feed_source,
            )
            is_immidiate_reentry = True
        elif leg.triggered_reentry.type == REENTRYTYPE.AS_ORIGINAL:
            contractrize_leg(
                strategy.index,
                index_base_price,
                index_price,
                fix_vix,
                available_trading_dates,
                current_date,
                trading_timestamp,
                atm,
                strike_diff,
                exchange,
                leg,
                is_live,
                feed_source,
            )
            leg.is_waiting_for_triggered_reentry = True
        elif leg.triggered_reentry.type == REENTRYTYPE.RE_COST:
            contract_ohlc = get_quote(
                feed_source,
                leg.contract.symbol,
                current_date,
                trading_timestamp,
                trading_timestamp,
                leg.contract.expiry_date,
                leg.contract.strike_price,
                leg.contract.option_type,
                True,
            )
            if not contract_ohlc:
                return
            if not leg.recost_entry_on_crossover:
                leg.current_wait_and_trade = (
                    leg.leg_entry_price - contract_ohlc.open / 100
                )
                leg.contract_initial_price = contract_ohlc.open / 100
            else:
                leg.current_wait_and_trade = leg.leg_entry_price - leg.contract.ltp
                leg.contract_initial_price = leg.contract.ltp

            if not leg.recost_entry_on_crossover:
                if leg.side == SIDE.SELL and leg.current_wait_and_trade < 0:
                    is_immidiate_reentry = True
                elif leg.side == SIDE.BUY and leg.current_wait_and_trade > 0:
                    is_immidiate_reentry = True
            leg.is_waiting_for_triggered_reentry = True
            contract_ohlc = None
            leg.status = LEGSTATUS.CONTRACTRIZED
        else:
            logger.error("Reentry type not supported")
        leg.trigger_reentry_remaining -= 1

    if leg.oi_check and (leg.status == LEGSTATUS.CONTRACTRIZED):
        can_make_full_candle = (trading_timestamp - MARKET_START_TIME[exchange.name])%leg.oi_check.check_interval == 0
        if can_make_full_candle:
            if leg.oi_check.recontracterized:
                contractrize_leg(
                    strategy.index,
                    index_base_price,
                    index_price,
                    fix_vix,
                    available_trading_dates,
                    current_date,
                    trading_timestamp,
                    atm,
                    strike_diff,
                    exchange,
                    leg,
                    is_live,
                    feed_source,
                )
        else:
            return
    if (
        leg.status != LEGSTATUS.CONTRACTRIZED
        or strategy.place_order_after > trading_timestamp
    ):
        return
    if (
        leg.is_waiting_for_take_profit_reentry
        and leg.take_profit_reentry.value.cutoff_time < trading_timestamp
    ):
        leg.is_waiting_for_take_profit_reentry = False
        leg.status = LEGSTATUS.EXITED
        return
    if (
        leg.is_waiting_for_stop_loss_reentry
        and leg.stop_loss_reentry.value.cutoff_time < trading_timestamp
    ):
        leg.is_waiting_for_stop_loss_reentry = False
        leg.status = LEGSTATUS.EXITED
        return
    if (
        leg.is_waiting_for_triggered_reentry
        and leg.stop_loss_reentry.value.cutoff_time < trading_timestamp
    ):
        leg.is_waiting_for_triggered_reentry = False
        leg.status = LEGSTATUS.EXITED
        return

    contract_ohlc = get_quote(
        feed_source,
        leg.contract.symbol,
        current_date,
        trading_timestamp,
        trading_timestamp,
        leg.contract.expiry_date,
        leg.contract.strike_price,
        leg.contract.option_type,
        True,
    )
    if leg.oi_check:
        oi_candle = get_quote(
                        feed_source,
                        leg.contract.symbol,
                        current_date,
                        trading_timestamp - leg.oi_check.check_interval,
                        trading_timestamp - Config.BT_FREQUENCY,
                        leg.contract.expiry_date,
                        leg.contract.strike_price,
                        leg.contract.option_type,
                        True,
                    )
        if oi_candle.coi < leg.oi_check.value:
            return
    if leg.orb and leg.is_first_entry:
        if trading_timestamp > leg.orb.wait_till:
            if not leg.orb.is_set:
                orb_candle = get_quote(
                    feed_source,
                    leg.contract.symbol,
                    current_date,
                    leg.orb.wait_start,
                    trading_timestamp - Config.BT_FREQUENCY,
                    leg.contract.expiry_date,
                    leg.contract.strike_price,
                    leg.contract.option_type,
                    True,
                )
                leg.orb.high_range = orb_candle.high
                leg.orb.low_range = orb_candle.low
                leg.orb.is_set = True
            if leg.orb.is_set:
                if contract_ohlc is None:
                    return
                if leg.orb.entry_on == ORBBREAKOUTTYPE.HIGHBREAKOUT:
                    if contract_ohlc.high < leg.orb.high_range:
                        return
                    else:
                        leg.current_wait_and_trade = calculate_wait_points(
                            contract_ohlc.high / 100.0, leg.wait_and_trade
                        )
                        leg.contract_initial_price = contract_ohlc.high / 100.0
                        leg.is_first_entry = False
                if leg.orb.entry_on == ORBBREAKOUTTYPE.LOWBREAKOUT:
                    if contract_ohlc.low > leg.orb.low_range:
                        return
                    else:
                        leg.current_wait_and_trade = calculate_wait_points(
                            contract_ohlc.low / 100.0, leg.wait_and_trade
                        )
                        leg.contract_initial_price = contract_ohlc.low / 100.0
                        leg.is_first_entry = False
        else:
            return

    
    if contract_ohlc:
        initial_price = leg.contract_initial_price
        if not leg.contract_initial_price:
            initial_price = leg.leg_entry_price
        if leg.wait_and_trade.should_trail and ((-contract_ohlc.open/100*sign(leg.wait_and_trade.value) + initial_price*sign(leg.wait_and_trade.value)))> 0:
            leg.current_wait_and_trade = calculate_wait_points(
                            contract_ohlc.low / 100.0, leg.wait_and_trade
                        )
            leg.contract_initial_price = contract_ohlc.open/100
        if (
            is_waiting_is_over(
                contract_ohlc.open / 100.0, initial_price, leg.current_wait_and_trade
            )
            or is_immidiate_reentry
        ) and abs(leg.wait_in_time) % leg.wait_in_time_devider == 0:
            if leg.hedge:
                if leg.orb and leg.orb.new_selection is not None:  # finding atm again in orb variant as trade strike need to be calculated at wait_till time
                    if strategy.underlying == UNDERLYINGTYPE.FUTURE:
                        monthly_expiry = get_monthly_expiry_date(strategy.index, current_date, is_live)
                        old_index_ohlc = get_quote(feed_source, strategy.index, current_date, leg.orb.wait_till, leg.orb.wait_till, option_type=OPTIONTYPE.FUT, expiry=monthly_expiry)
                    elif strategy.underlying == UNDERLYINGTYPE.CASH:
                        old_index_ohlc = get_quote(feed_source, strategy.index, current_date, leg.orb.wait_till, leg.orb.wait_till)
                    contractrize_leg(
                        strategy.index,
                        index_base_price,
                        old_index_ohlc.open/100,
                        fix_vix,
                        available_trading_dates,
                        current_date,
                        leg.orb.wait_till,
                        round_to(old_index_ohlc.open/100, strike_diff),
                        strike_diff,
                        exchange,
                        leg.hedge,
                        is_live,
                        feed_source,
                    )
                else:
                    contractrize_leg(
                        strategy.index,
                        index_base_price,
                        index_price,
                        fix_vix,
                        available_trading_dates,
                        current_date,
                        trading_timestamp,
                        atm,
                        strike_diff,
                        exchange,
                        leg.hedge,
                        is_live,
                        feed_source,
                    )
                quote = get_quote(
                    feed_source,
                    leg.hedge.contract.symbol,
                    current_date,
                    trading_timestamp,
                    trading_timestamp,
                    leg.hedge.contract.expiry_date,
                    leg.hedge.contract.strike_price,
                    leg.hedge.contract.option_type,
                    True,
                )

                if not quote:
                    return
                leg.hedge.contract.ltp = quote.open / 100.0
                order = Order(
                    strategy.entry_number,
                    strategy.name,
                    leg.hedge.id,
                    leg.entry_number,
                    leg.stop_loss_entry_number,
                    leg.take_profit_entry_number,
                    leg.hedge.contract,
                    product_type,
                    order_type,
                    leg.hedge.side,
                    0,
                    0,
                    leg.quantity * leg.multiplier * strategy.multiplier,
                    TimeStamp(current_date, trading_timestamp),
                    index_price,
                    "Hedge Entry",
                )
                orders.append(order)
                broker_order_id = place_order(broker, client_id, order, None)
                order.broker_order_id = broker_order_id
                leg.hedge.entry_order = order
                leg.status = LEGSTATUS.WAITING_FOR_HEDGE_ENTRY
            else:
                leg.status = LEGSTATUS.WAITING_FOR_ENTRY
        if leg.status == LEGSTATUS.WAITING_FOR_HEDGE_ENTRY:
            if leg.hedge.entry_order.status == ORDERSTATUS.COMPLETE:
                leg.status = LEGSTATUS.WAITING_FOR_ENTRY
        if leg.status == LEGSTATUS.WAITING_FOR_ENTRY:
            stop_loss_entry_number = ""
            take_profit_entry_number = ""
            if leg.reentry_reason == "STOP_LOSS":
                stop_loss_entry_number = leg.stop_loss_entry_number
            elif leg.reentry_reason == "TAKE_PROFIT":
                take_profit_entry_number = leg.take_profit_entry_number

            if leg.recost_cascade:
                if leg.reentry_reason != "STOP_LOSS":
                    leg.leg_entry_price = contract_ohlc.open / 100
            else:
                if not leg.leg_entry_price:
                    if leg.wait_and_trade.value != 0:
                        leg.leg_entry_price = (
                            leg.contract_initial_price + leg.current_wait_and_trade
                        )
                    else:
                        leg.leg_entry_price = leg.contract_initial_price
            if leg.orb and leg.orb.new_selection is not None:
                if strategy.underlying == UNDERLYINGTYPE.FUTURE:
                    monthly_expiry = get_monthly_expiry_date(strategy.index, current_date, is_live)
                    index_ohlc = get_quote(feed_source, strategy.index, current_date, leg.orb.wait_till, leg.orb.wait_till, option_type=OPTIONTYPE.FUT, expiry=monthly_expiry)
                elif strategy.underlying == UNDERLYINGTYPE.CASH:
                    index_ohlc = get_quote(feed_source, strategy.index, current_date, leg.orb.wait_till, leg.orb.wait_till)
                
                # finding new strike again in orb variant as trade strike need to be calculated at wait_till time
                if leg.strike_selection.type == STRIKESELECTIONTYPE.BY_MIN_STRIKE_DIFF:
                    newatm = get_min_diff_strike_price(strategy.index, current_date, leg.orb.wait_till, leg.contract.expiry_date, leg.orb.new_selection, leg.option_type, is_live)
                else:
                    newatm = round_to(index_ohlc.open/100, strike_diff) 
                
                leg.contract.strike_price = newatm + leg.orb.new_selection * strike_diff * leg.option_type.value
                
                contract_ohlc = get_quote(
                    feed_source,
                    leg.contract.symbol,
                    current_date,
                    trading_timestamp,
                    trading_timestamp,
                    leg.contract.expiry_date,
                    leg.contract.strike_price,
                    leg.contract.option_type
                )
            order = Order(
                strategy.entry_number,
                strategy.name,
                leg.id,
                leg.entry_number,
                stop_loss_entry_number,
                take_profit_entry_number,
                leg.contract,
                product_type,
                order_type,
                leg.side,
                0,
                0,
                leg.quantity * leg.multiplier * strategy.multiplier,
                TimeStamp(current_date, trading_timestamp),
                index_price,
                "Entry",
            )
            orders.append(order)
            leg.orders.append(order)
            entry_price = None
            if leg.orb and leg.entry_number == 0 and leg.wait_and_trade.value == 0:
                if leg.orb.entry_on == ORBBREAKOUTTYPE.HIGHBREAKOUT:
                    entry_price = contract_ohlc.high / 100
                elif leg.orb.entry_on == ORBBREAKOUTTYPE.LOWBREAKOUT:
                    entry_price = contract_ohlc.low / 100
            broker_order_id = place_order(broker, client_id, order, entry_price)
            strategy.entry_combined_premium += order.average_price
            order.broker_order_id = broker_order_id

            leg.is_waiting_for_stop_loss_reentry = False
            leg.is_waiting_for_take_profit_reentry = False
            leg.is_waiting_for_triggered_reentry = False

            leg.status = LEGSTATUS.ENTERED
            strategy.status = STRATEGYSTATUS.RUNNING
            for condition in leg.on_entry:
                if condition == "squareoffall":
                    strategy.next_action_time = (
                        trading_timestamp + leg.on_entry[condition][0]["delay"]
                    )
                    # strategy.status = STRATEGYSTATUS.SQUAREOFF_ALL
                    if strategy.next_action_time == trading_timestamp:
                        for leg_ in strategy.legs:
                            if leg_.id != leg.id:
                                if leg_.status == LEGSTATUS.ENTERED:
                                    leg_.status = LEGSTATUS.EXIT_TRIGGERED
                                    _, _ = evaluate_leg_exit(strategy,  leg_, current_date, timestamp, trading_timestamp, exit_time, index_price, index_base_price, fix_vix, atm, strike_diff, monthly_expiry, available_trading_dates, strategy_profits, strategy_losses,order_type, product_type, broker, client_id, orders, exchange, feed_source, is_live, True)
                    continue
                exe_configs = leg.on_entry[condition]
                for exe_config in exe_configs:
                    leg_id = exe_config["id"]
                    leg_delay = exe_config.get("delay", 0)
                    for leg_ in strategy.legs:
                        if leg_id == leg_.id:
                            if condition == "execute":
                                leg_.entered_by_trigger = True
                                leg_.is_activated = True
                                if leg_delay == 0:
                                    evaluate_leg_entry(
                                        strategy,
                                        leg_,
                                        timestamp,
                                        exit_time,
                                        index_base_price,
                                        index_price,
                                        fix_vix,
                                        available_trading_dates,
                                        current_date,
                                        trading_timestamp,
                                        atm,
                                        strike_diff,
                                        exchange,
                                        is_live,
                                        feed_source,
                                        orders,
                                        broker,
                                        client_id,
                                        order_type,
                                        product_type,
                                    )
                            elif condition == "squareoff":
                                if leg_.status == LEGSTATUS.ENTERED:
                                    leg_.status = LEGSTATUS.EXIT_TRIGGERED
                            leg_.next_action_time = (
                                strategy.next_action_time + leg_delay
                            )


def evaluate_leg_exit(
    strategy: Strategy,
    leg: Leg,
    current_date: int,
    timestamp: int,
    trading_timestamp: int,
    exit_time,
    index_price: float,
    index_base_price,
    fix_vix,
    atm,
    strike_diff,
    monthly_expiry: int,
    available_trading_dates,
    strategy_profits,
    strategy_losses,
    order_type,
    product_type,
    broker,
    client_id,
    orders,
    exchange,
    feed_source: str,
    is_live,
    is_inter_trigger=False,
):
    is_stop_loss_check_time_update = False
    is_take_profit_check_time_update = False
    index_based_sl = False
    index_based_tp = False
    hedge_open_pnl = 0
    hedge_close_pnl = 0
    hedge_high_pnl = 0
    hedge_low_pnl = 0
    if leg.next_action_time > trading_timestamp:
        return is_stop_loss_check_time_update, is_take_profit_check_time_update
    if leg.status in [LEGSTATUS.ENTERED, LEGSTATUS.EXIT_TRIGGERED]:
        last_order = leg.orders[-1]
        if last_order.status == ORDERSTATUS.COMPLETE:
            if leg.hedge:
                if leg.hedge.entry_order:
                    hedge_ohlc = get_quote(
                        feed_source,
                        leg.hedge.entry_order.contract.symbol,
                        current_date,
                        strategy.entry_time,
                        trading_timestamp,
                        leg.hedge.entry_order.contract.expiry_date,
                        leg.hedge.entry_order.contract.strike_price,
                        leg.hedge.entry_order.contract.option_type,
                        is_hedge=True,
                    )
                    if hedge_ohlc:
                        hedge_open_pnl = calculate_current_pnl(
                            hedge_ohlc.open / 100.0,
                            leg.hedge.entry_order.average_price,
                            leg.hedge.entry_order.side,
                            leg.take_profit.type,
                        )

                        hedge_close_pnl = calculate_current_pnl(
                            hedge_ohlc.close / 100.0,
                            leg.hedge.entry_order.average_price,
                            leg.hedge.entry_order.side,
                            leg.take_profit.type,
                        )

                        hedge_high_pnl = calculate_current_pnl(
                            hedge_ohlc.high / 100.0,
                            leg.hedge.entry_order.average_price,
                            leg.hedge.entry_order.side,
                            leg.take_profit.type,
                        )

                        hedge_low_pnl = calculate_current_pnl(
                            hedge_ohlc.low / 100.0,
                            leg.hedge.entry_order.average_price,
                            leg.hedge.entry_order.side,
                            leg.take_profit.type,
                        )
            if not leg.current_stop_loss or not leg.current_take_profit:
                if leg.stop_loss.type != NUMBERTYPE.ABSOLUTE_DELTA:
                    leg.current_stop_loss = calculate_stop_loss_points(
                        index_price, last_order.average_price, leg.stop_loss
                    )
                if leg.take_profit.type != NUMBERTYPE.ABSOLUTE_DELTA:
                    leg.current_take_profit = calculate_take_profit_points(
                        index_price, last_order.average_price, leg.take_profit
                    )
                leg.current_trailing_stop_loss = calculate_trailing_stop_loss_points(
                    index_price, last_order.average_price, leg.trailing_stop_loss
                )

            minute_ohlc = get_quote(
                feed_source,
                last_order.contract.symbol,
                current_date,
                trading_timestamp,
                trading_timestamp,
                last_order.contract.expiry_date,
                last_order.contract.strike_price,
                last_order.contract.option_type,
            )
            profit_ohlc = get_quote(
                feed_source,
                last_order.contract.symbol,
                current_date,
                strategy.last_take_profit_check_time + Config.BT_FREQUENCY,
                trading_timestamp,
                last_order.contract.expiry_date,
                last_order.contract.strike_price,
                last_order.contract.option_type,
            )
            loss_ohlc = get_quote(
                feed_source,
                last_order.contract.symbol,
                current_date,
                strategy.last_stop_loss_check_time + Config.BT_FREQUENCY,
                trading_timestamp,
                last_order.contract.expiry_date,
                last_order.contract.strike_price,
                last_order.contract.option_type,
            )
            if strategy.underlying == UNDERLYINGTYPE.FUTURE:
                profit_index_ohlc = get_quote(
                    feed_source,
                    strategy.index,
                    current_date,
                    strategy.last_take_profit_check_time,
                    trading_timestamp,
                    option_type=OPTIONTYPE.FUT,
                    expiry=monthly_expiry,
                )
                loss_index_ohlc = get_quote(
                    feed_source,
                    strategy.index,
                    current_date,
                    strategy.last_stop_loss_check_time,
                    trading_timestamp,
                    option_type=OPTIONTYPE.FUT,
                    expiry=monthly_expiry,
                )
            elif strategy.underlying == UNDERLYINGTYPE.CASH:
                profit_index_ohlc = get_quote(
                    feed_source,
                    strategy.index,
                    current_date,
                    strategy.last_take_profit_check_time,
                    trading_timestamp,
                )
                loss_index_ohlc = get_quote(
                    feed_source,
                    strategy.index,
                    current_date,
                    strategy.last_stop_loss_check_time,
                    trading_timestamp,
                )

            if not minute_ohlc or not profit_ohlc or not loss_ohlc:
                return is_stop_loss_check_time_update, is_take_profit_check_time_update

            pnl_dict = get_pnl_dict(
                minute_ohlc,
                profit_index_ohlc,
                loss_index_ohlc,
                profit_ohlc,
                loss_ohlc,
                last_order,
                leg,
            )

            if strategy.exit_price_config.take_profit_based_on == "OPEN":
                if leg.take_profit.type in [
                    NUMBERTYPE.INDEX_POINTS,
                    NUMBERTYPE.INDEX_PERCENTAGE,
                ]:
                    tp_order_price = profit_ohlc.close / 100.0
                    current_profit = pnl_dict["index_open_profit"]
                    index_based_tp = True
                else:
                    tp_order_price = profit_ohlc.open / 100.0
                    current_profit = pnl_dict["open_profit"]
            elif strategy.exit_price_config.take_profit_based_on == "CLOSE":
                if leg.take_profit.type in [
                    NUMBERTYPE.INDEX_POINTS,
                    NUMBERTYPE.INDEX_PERCENTAGE,
                ]:
                    tp_order_price = profit_ohlc.close / 100.0
                    current_profit = pnl_dict["index_close_profit"]
                    index_based_tp = True
                else:
                    tp_order_price = profit_ohlc.close / 100.0
                    current_profit = pnl_dict["close_profit"]
            elif strategy.exit_price_config.take_profit_based_on not in [
                "OPEN",
                "CLOSE",
            ]:
                if leg.take_profit.type in [
                    NUMBERTYPE.INDEX_POINTS,
                    NUMBERTYPE.INDEX_PERCENTAGE,
                ]:
                    if last_order.side == SIDE.BUY:
                        tp_order_price = profit_ohlc.high / 100.0
                        current_profit = pnl_dict["index_high_profit"]
                        index_based_tp = True
                    else:
                        tp_order_price = profit_ohlc.low / 100.0
                        current_profit = pnl_dict["index_low_profit"]
                        index_based_tp = True
                else:
                    if last_order.side == SIDE.BUY:
                        tp_order_price = profit_ohlc.high / 100.0
                        current_profit = pnl_dict["high_profit"]
                    else:
                        tp_order_price = profit_ohlc.low / 100.0
                        current_profit = pnl_dict["low_profit"]

            if strategy.exit_price_config.stop_loss_based_on == "OPEN":
                if leg.stop_loss.type in [
                    NUMBERTYPE.INDEX_POINTS,
                    NUMBERTYPE.INDEX_PERCENTAGE,
                ]:
                    sl_order_price = loss_ohlc.close / 100.0
                    current_stop_loss = pnl_dict["index_open_loss"]
                    index_based_sl = True
                else:
                    sl_order_price = loss_ohlc.open / 100.0
                    current_stop_loss = pnl_dict["open_loss"]
            elif strategy.exit_price_config.stop_loss_based_on == "CLOSE":
                if leg.stop_loss.type in [
                    NUMBERTYPE.INDEX_POINTS,
                    NUMBERTYPE.INDEX_PERCENTAGE,
                ]:
                    sl_order_price = loss_ohlc.close / 100.0
                    current_stop_loss = pnl_dict["index_close_loss"]
                    index_based_sl = True
                else:
                    sl_order_price = loss_ohlc.close / 100.0
                    current_stop_loss = pnl_dict["close_loss"]
            elif strategy.exit_price_config.stop_loss_based_on not in ["OPEN", "CLOSE"]:
                if leg.stop_loss.type in [
                    NUMBERTYPE.INDEX_POINTS,
                    NUMBERTYPE.INDEX_PERCENTAGE,
                ]:
                    if last_order.side == SIDE.BUY:
                        sl_order_price = loss_ohlc.high / 100.0
                        current_stop_loss = pnl_dict["index_high_loss"]
                        index_based_sl = True
                    else:
                        sl_order_price = loss_ohlc.close / 100.0
                        current_stop_loss = pnl_dict["index_high_loss"]
                        index_based_sl = True
                else:
                    if last_order.side == SIDE.BUY:
                        sl_order_price = loss_ohlc.low / 100.0
                        current_stop_loss = pnl_dict["low_loss"]
                    else:
                        sl_order_price = loss_ohlc.high / 100.0
                        current_stop_loss = pnl_dict["high_loss"]

            if (
                pnl_dict["high_loss"] < 0
                and abs(pnl_dict["high_loss"]) > last_order.max_loss
            ):
                last_order.max_loss = abs(pnl_dict["high_loss"])
            elif (
                pnl_dict["high_profit"] > 0
                and pnl_dict["high_profit"] > last_order.max_profit
            ):
                last_order.max_profit = abs(pnl_dict["high_profit"])

            if (
                pnl_dict["low_loss"] < 0
                and abs(pnl_dict["low_loss"]) > last_order.max_loss
            ):
                last_order.max_loss = abs(pnl_dict["low_loss"])
            elif (
                pnl_dict["low_profit"] > 0
                and pnl_dict["low_profit"] > last_order.max_profit
            ):
                last_order.max_profit = abs(pnl_dict["low_profit"])

            sl_hit, delta_based_sl, is_stop_loss_check_time_update = is_sl_hit(
                strategy, 
                leg, 
                current_date, 
                trading_timestamp, 
                atm, 
                current_stop_loss, 
                last_order, 
                feed_source
            )

            tp_hit, delta_based_tp, is_take_profit_check_time_update = is_tp_hit(
                strategy, 
                leg, 
                current_date, 
                trading_timestamp, 
                atm, 
                current_profit, 
                last_order, 
                feed_source
            )

            if leg.status == LEGSTATUS.EXIT_TRIGGERED:
                if leg.hedge:
                    if leg.hedge.entry_order:
                        if leg.hedge.entry_order.status == ORDERSTATUS.COMPLETE:
                            place_hedge_exit_order(
                                strategy,
                                leg,
                                product_type,
                                order_type,
                                current_date,
                                trading_timestamp,
                                index_price,
                                broker,
                                client_id,
                                "Trigger Hedge Exit",
                                orders,
                            )
                        else:
                            leg.status = LEGSTATUS.WAITING_FOR_TRIGGER_EXIT
                else:
                    leg.status = LEGSTATUS.WAITING_FOR_TRIGGER_EXIT
                strategy.is_any_leg_exited = True
                strategy.is_any_leg_sl_hit = True
            if sl_hit:
                if leg.hedge:
                    if leg.hedge.entry_order:
                        if leg.hedge.entry_order.status == ORDERSTATUS.COMPLETE:
                            place_hedge_exit_order(
                                strategy,
                                leg,
                                product_type,
                                order_type,
                                current_date,
                                trading_timestamp,
                                index_price,
                                broker,
                                client_id,
                                "Stop Loss Hedge Exit",
                                orders,
                            )
                        else:
                            leg.status = LEGSTATUS.WAITING_FOR_STOP_LOSS_EXIT
                else:
                    leg.status = LEGSTATUS.WAITING_FOR_STOP_LOSS_EXIT
                strategy.is_any_leg_exited = True
                strategy.is_any_leg_sl_hit = True

            elif tp_hit:
                if leg.hedge:
                    if leg.hedge.entry_order:
                        if leg.hedge.entry_order.status == ORDERSTATUS.COMPLETE:
                            place_hedge_exit_order(
                                strategy,
                                leg,
                                product_type,
                                order_type,
                                current_date,
                                trading_timestamp,
                                index_price,
                                broker,
                                client_id,
                                "Take Profit Hedge Exit",
                                orders,
                            )
                        else:
                            leg.status = LEGSTATUS.WAITING_FOR_TAKE_PROFIT_EXIT
                else:
                    leg.status = LEGSTATUS.WAITING_FOR_TAKE_PROFIT_EXIT
                strategy.is_any_leg_exited = True

            elif is_time_for_exit(timestamp, exit_time) or (
                current_date == leg.contract.expiry_date
                and is_time_for_exit(
                    trading_timestamp, strategy.tv_expiry_day_exit_time
                )
            ):
                if leg.hedge:
                    if leg.hedge.entry_order:
                        if leg.hedge.entry_order.status == ORDERSTATUS.COMPLETE:
                            place_hedge_exit_order(
                                strategy,
                                leg,
                                product_type,
                                order_type,
                                current_date,
                                trading_timestamp,
                                index_price,
                                broker,
                                client_id,
                                "Time Hedge Exit",
                                orders,
                            )
                        else:
                            leg.status = LEGSTATUS.WIATING_FOR_TIME_EXIT
                else:
                    leg.status = LEGSTATUS.WIATING_FOR_TIME_EXIT
                strategy.is_any_leg_exited = True
            elif not is_inter_trigger:

                if strategy.pnl_calculation_from == "OPEN":
                    strategy_profits.append(
                        pnl_dict["minute_open_profit"] * last_order.quantity
                    )
                    strategy_losses.append(pnl_dict["minute_open_loss"] * last_order.quantity)
                    if leg.hedge_pnl_effect and hedge_open_pnl:
                        strategy_profits.append(
                            hedge_open_pnl * leg.hedge.entry_order.quantity
                        )
                        strategy_losses.append(hedge_open_pnl * leg.hedge.entry_order.quantity)

                elif strategy.pnl_calculation_from == "CLOSE":
                    strategy_profits.append(
                        pnl_dict["minute_close_profit"] * last_order.quantity
                    )
                    strategy_losses.append(pnl_dict["minute_close_loss"] * last_order.quantity)
                    if leg.hedge_pnl_effect and hedge_close_pnl:
                        strategy_profits.append(
                            hedge_close_pnl * leg.hedge.entry_order.quantity
                        )
                        strategy_losses.append(
                            hedge_close_pnl * leg.hedge.entry_order.quantity
                        )

                elif strategy.pnl_calculation_from == "HIGH":
                    strategy_profits.append(
                        pnl_dict["minute_high_profit"] * last_order.quantity
                    )
                    strategy_losses.append(pnl_dict["minute_high_loss"] * last_order.quantity)
                    if leg.hedge_pnl_effect and hedge_high_pnl:
                        strategy_profits.append(
                            hedge_high_pnl * leg.hedge.entry_order.quantity
                        )
                        strategy_losses.append(
                            hedge_high_pnl * leg.hedge.entry_order.quantity
                        )

                elif strategy.pnl_calculation_from == "LOW":
                    strategy_profits.append(
                        pnl_dict["minute_low_profit"] * last_order.quantity
                    )
                    strategy_losses.append(pnl_dict["minute_low_loss"] * last_order.quantity)
                    if leg.hedge_pnl_effect and hedge_low_pnl:
                        strategy_profits.append(
                            hedge_low_pnl * leg.hedge.entry_order.quantity
                        )
                        strategy_losses.append(
                            hedge_low_pnl * leg.hedge.entry_order.quantity
                        )

                elif strategy.pnl_calculation_from not in ["OPEN", "CLOSE", "HIGH", "LOW"]:
                    if last_order.side == SIDE.BUY:
                        strategy_profits.append(
                            pnl_dict["minute_high_profit"] * last_order.quantity
                        )
                        strategy_losses.append(
                            pnl_dict["minute_low_loss"] * last_order.quantity
                        )
                    else:
                        strategy_profits.append(
                            pnl_dict["minute_low_profit"] * last_order.quantity
                        )
                        strategy_losses.append(
                            pnl_dict["minute_high_loss"] * last_order.quantity
                        )

                    if leg.hedge_pnl_effect and hedge_low_pnl:
                        if leg.hedge.entry_order.side == SIDE.BUY:
                            strategy_profits.append(
                                hedge_high_pnl * leg.hedge.entry_order.quantity
                            )
                            strategy_losses.append(
                                hedge_low_pnl * leg.hedge.entry_order.quantity
                            )
                        else:
                            strategy_profits.append(
                                hedge_low_pnl * leg.hedge.entry_order.quantity
                            )
                            strategy_losses.append(
                                hedge_high_pnl * leg.hedge.entry_order.quantity
                            )
            if leg.current_stop_loss:
                trail_sl(
                    leg,
                    pnl_dict["index_open_profit"],
                    pnl_dict["open_profit"],
                    index_based_sl,
                    index_based_tp,
                    last_order,
                )
    if leg.status == LEGSTATUS.WAITING_FOR_HEDGE_EXIT:
        if leg.hedge.exit_order.status == ORDERSTATUS.COMPLETE:
            if leg.hedge_pnl_effect:
                hedge_pnl = (
                    calculate_current_pnl(
                        leg.hedge.exit_order.average_price,
                        leg.hedge.entry_order.average_price,
                        leg.hedge.side,
                        leg.take_profit.type,
                    )
                    * leg.quantity
                    * leg.multiplier
                    * strategy.multiplier
                )

                if leg.hedge.side == SIDE.BUY:
                    strategy_profits.append(hedge_pnl)
                    strategy_losses.append(hedge_pnl)
                    leg.realized_pnl += hedge_pnl
                    strategy.realized_pnl += hedge_pnl
                else:
                    strategy_profits.append(-hedge_pnl)
                    strategy_losses.append(-hedge_pnl)
                    leg.realized_pnl += hedge_pnl
                    strategy.realized_pnl += -hedge_pnl

            if leg.hedge.exit_order.reason == "Stop Loss Hedge Exit":
                leg.status = LEGSTATUS.WAITING_FOR_STOP_LOSS_EXIT
            elif leg.hedge.exit_order.reason == "Take Profit Hedge Exit":
                leg.status = LEGSTATUS.WAITING_FOR_TAKE_PROFIT_EXIT
            elif leg.hedge.exit_order.reason == "Trigger Hedge Exit":
                leg.status = LEGSTATUS.WAITING_FOR_TRIGGER_EXIT
            else:
                leg.status = LEGSTATUS.WIATING_FOR_TIME_EXIT

    if leg.status == LEGSTATUS.WAITING_FOR_TRIGGER_EXIT:
        reason = "Trigger exit"
        order = Order(
            strategy.entry_number,
            strategy.name,
            leg.id,
            leg.entry_number,
            leg.stop_loss_entry_number,
            leg.take_profit_entry_number,
            last_order.contract,
            product_type,
            order_type,
            reverse_side(leg.side),
            0,
            0,
            last_order.quantity,
            TimeStamp(current_date, trading_timestamp),
            index_price,
            reason,
        )
        leg.entry_number += 1
        leg.take_profit_entry_number += 1
        trigger_order_price = loss_ohlc.close / 100
        if strategy.exit_price_config.trade_file_exit_price_on_trigger != "TICK":
            if last_order.side == SIDE.BUY:
                trigger_order_price = last_order.average_price + leg.current_stop_loss
            else:
                trigger_order_price = last_order.average_price - leg.current_take_profit
        broker_order_id = place_order(broker, client_id, order, trigger_order_price)
        order.broker_order_id = broker_order_id
        orders.append(order)
        leg.orders.append(order)
        leg.status = LEGSTATUS.WAITING_FOR_TRIGGER_FILL

    if leg.status == LEGSTATUS.WAITING_FOR_TAKE_PROFIT_EXIT:
        if index_based_tp:
            reason = "Index Based Take Profit Hit"
        else:
            reason = "Take Profit Hit"
        order = Order(
            strategy.entry_number,
            strategy.name,
            leg.id,
            leg.entry_number,
            leg.stop_loss_entry_number,
            leg.take_profit_entry_number,
            last_order.contract,
            product_type,
            order_type,
            reverse_side(leg.side),
            0,
            0,
            last_order.quantity,
            TimeStamp(current_date, trading_timestamp),
            index_price,
            reason,
        )
        leg.entry_number += 1
        leg.take_profit_entry_number += 1
        if (
            strategy.exit_price_config.trade_file_exit_price_on_take_profit != "TICK"
            and not index_based_tp
            and not delta_based_tp
        ):
            if last_order.side == SIDE.BUY:
                tp_order_price = last_order.average_price + leg.current_take_profit
            else:
                tp_order_price = last_order.average_price - leg.current_take_profit
        broker_order_id = place_order(broker, client_id, order, tp_order_price)
        order.broker_order_id = broker_order_id
        orders.append(order)
        leg.orders.append(order)
        leg.status = LEGSTATUS.WAITING_FOR_TAKE_PROFIT_FILL
    if leg.status == LEGSTATUS.WAITING_FOR_STOP_LOSS_EXIT:
        if index_based_sl:
            exit_reason = "Index Based Stop Loss Hit"
            if leg.is_stop_loss_trailed:
                exit_reason = "Index Based Trailing Stop Loss Hit"
        else:
            exit_reason = "Stop Loss Hit"
            if leg.is_stop_loss_trailed:
                exit_reason = "Trailing Stop Loss Hit"
        order = Order(
            strategy.entry_number,
            strategy.name,
            leg.id,
            leg.entry_number,
            leg.stop_loss_entry_number,
            leg.take_profit_entry_number,
            last_order.contract,
            product_type,
            order_type,
            reverse_side(leg.side),
            0,
            0,
            last_order.quantity,
            TimeStamp(current_date, trading_timestamp),
            index_price,
            exit_reason,
        )
        leg.entry_number += 1
        leg.stop_loss_entry_number += 1
        if (
            strategy.exit_price_config.trade_file_exit_price_on_stop_loss != "TICK"
            and not index_based_sl
            and not delta_based_sl
        ):
            if last_order.side == SIDE.BUY:
                sl_order_price = last_order.average_price - leg.current_stop_loss
            else:
                sl_order_price = last_order.average_price + leg.current_stop_loss

        broker_order_id = place_order(broker, client_id, order, sl_order_price)
        order.broker_order_id = broker_order_id
        orders.append(order)
        leg.orders.append(order)
        leg.status = LEGSTATUS.WAITING_FOR_STOP_LOSS_FILL
    if leg.status == LEGSTATUS.WIATING_FOR_TIME_EXIT:
        booked_pnl = pnl_dict["open_loss"] * last_order.quantity
        order = Order(
            strategy.entry_number,
            strategy.name,
            leg.id,
            leg.entry_number,
            leg.stop_loss_entry_number,
            leg.take_profit_entry_number,
            last_order.contract,
            product_type,
            order_type,
            reverse_side(leg.side),
            0,
            0,
            last_order.quantity,
            TimeStamp(current_date, trading_timestamp),
            index_price,
            "Exit Time Hit",
        )
        broker_order_id = place_order(broker, client_id, order)
        leg.realized_pnl += booked_pnl
        strategy_profits.append(booked_pnl)
        strategy_losses.append(booked_pnl)
        strategy.realized_pnl += booked_pnl
        orders.append(order)
        leg.orders.append(order)
        order.broker_order_id = broker_order_id
        leg.status = LEGSTATUS.WAITING_FOR_TIME_EXIT_FILL

    leg_exit_fill = False
    if leg.status == LEGSTATUS.WAITING_FOR_TRIGGER_FILL:
        exit_order = leg.orders[-1]
        if exit_order.status == ORDERSTATUS.COMPLETE:
            entry_order = leg.orders[-2]
            booked_pnl = (
                calculate_current_pnl(
                    exit_order.average_price,
                    entry_order.average_price,
                    entry_order.side,
                    leg.take_profit.type,
                )
                * entry_order.quantity
            )
            leg.contract.ltp = exit_order.average_price
            leg.realized_pnl += booked_pnl
            strategy_profits.append(booked_pnl)
            strategy_losses.append(booked_pnl)
            strategy.realized_pnl += booked_pnl
            leg.current_stop_loss = None
            leg.current_take_profit = None
            leg.current_trailing_stop_loss = None
            leg.is_stop_loss_trailed = False

            # if leg.trigger_reentry_remaining > 0 and leg.triggered_reentry.value.cutoff_time > trading_timestamp:
            #     leg.status = LEGSTATUS.TRIGGER_REENTRY
            #     leg.reentry_reason = "Trigger Exit"
            # else:
            #     leg.status = LEGSTATUS.EXITED
            leg.status = LEGSTATUS.EXITED
            leg_exit_fill = True

    if leg.status == LEGSTATUS.WAITING_FOR_STOP_LOSS_FILL:
        exit_order = leg.orders[-1]
        if exit_order.status == ORDERSTATUS.COMPLETE:
            entry_order = leg.orders[-2]
            booked_pnl = (
                calculate_current_pnl(
                    exit_order.average_price,
                    entry_order.average_price,
                    entry_order.side,
                    leg.take_profit.type,
                )
                * entry_order.quantity
            )
            leg.contract.ltp = exit_order.average_price
            leg.realized_pnl += booked_pnl
            strategy_profits.append(booked_pnl)
            strategy_losses.append(booked_pnl)
            strategy.realized_pnl += booked_pnl
            leg.current_stop_loss = None
            leg.current_take_profit = None
            leg.current_trailing_stop_loss = None
            leg.is_stop_loss_trailed = False
            if (
                leg.stop_loss_reentry_remaining > 0
                and leg.stop_loss_reentry.value.cutoff_time > trading_timestamp
            ):
                leg.status = LEGSTATUS.STOP_LOSS_REENTRY
                leg.reentry_reason = "STOP_LOSS"
            else:
                leg.status = LEGSTATUS.EXITED

            leg_exit_fill = True
    if leg.status == LEGSTATUS.WAITING_FOR_TAKE_PROFIT_FILL:
        exit_order = leg.orders[-1]
        if exit_order.status == ORDERSTATUS.COMPLETE:
            entry_order = leg.orders[-2]
            booked_pnl = (
                calculate_current_pnl(
                    exit_order.average_price,
                    entry_order.average_price,
                    entry_order.side,
                    leg.take_profit.type,
                )
                * entry_order.quantity
            )
            leg.contract.ltp = exit_order.average_price
            leg.realized_pnl += booked_pnl
            strategy_profits.append(booked_pnl)
            strategy_losses.append(booked_pnl)
            strategy.realized_pnl += booked_pnl
            leg.current_stop_loss = None
            leg.current_take_profit = None
            leg.current_trailing_stop_loss = None
            leg.is_stop_loss_trailed = False
            if (
                leg.take_profit_reentry_remaining > 0
                and leg.take_profit_reentry.value.cutoff_time > trading_timestamp
            ):
                leg.status = LEGSTATUS.TAKE_PROFIT_REENTRY
                leg.reentry_reason = "TAKE_PROFIT"
            else:
                leg.status = LEGSTATUS.EXITED

            leg_exit_fill = True
    if leg.status == LEGSTATUS.WAITING_FOR_TIME_EXIT_FILL:
        exit_order = leg.orders[-1]
        if exit_order.status == ORDERSTATUS.COMPLETE:
            leg.status = LEGSTATUS.EXITED

    if leg_exit_fill and not is_inter_trigger:
        if leg.entered_by_trigger:
            leg.entered_by_trigger = False
            leg.is_activated = False
        for condition in leg.on_exit:
            if condition == "squareoffall":
                strategy.next_action_time = (
                    trading_timestamp + leg.on_exit[condition][0]["delay"]
                )
                # strategy.status = STRATEGYSTATUS.SQUAREOFF_ALL
                if strategy.next_action_time == trading_timestamp:
                    for leg_ in strategy.legs:
                        if leg_.id != leg.id:
                            if leg_.status == LEGSTATUS.ENTERED:
                                leg_.status = LEGSTATUS.EXIT_TRIGGERED
                                is_stop_loss_check_time_update, is_take_profit_check_time_update = evaluate_leg_exit(strategy,  leg_, current_date, timestamp, trading_timestamp, exit_time, index_price, index_base_price, fix_vix, atm, strike_diff, monthly_expiry, available_trading_dates, strategy_profits, strategy_losses,order_type, product_type, broker, client_id, orders, exchange, feed_source, is_live, True)
                continue
            exe_configs = leg.on_exit[condition]
            for exe_config in exe_configs:
                leg_id = exe_config["id"]
                leg_delay = exe_config.get("delay", 0)
                new_spawn = eval(exe_config.get("new_spawn", "False"))
                new_legs = []
                for leg_ in strategy.legs:
                    if leg_id == leg_.id:
                        if condition == "execute":
                            if new_spawn and not leg_.is_spawned:
                                new_leg = deepcopy(leg_)
                                reset_leg(new_leg)
                                new_leg.id = f"{leg_id}__{uuid.uuid4().hex}"
                                
                                new_leg.entered_by_trigger = True
                                new_leg.is_activated = True
                                new_leg.is_spawned = True
                                leg_.trigger_reentry_remaining -= 1
                                new_leg.trigger_reentry_remaining = leg_.trigger_reentry_remaining
                                if new_leg.trigger_reentry_remaining > 0:
                                    new_legs.append(new_leg)
                                    # logger.info(f"New spawn: {new_leg.trigger_reentry_remaining}")
                                    new_leg.status = LEGSTATUS.TRIGGER_REENTRY
                                    new_leg.entered_by_trigger = True
                                    new_leg.is_activated = True
                                    new_leg.next_action_time = trading_timestamp + leg_delay
                                    if leg_delay == 0:
                                        evaluate_leg_entry(
                                            strategy,
                                            new_leg,
                                            timestamp,
                                            exit_time,
                                            index_base_price,
                                            index_price,
                                            fix_vix,
                                            available_trading_dates,
                                            current_date,
                                            trading_timestamp,
                                            atm,
                                            strike_diff,
                                            exchange,
                                            is_live,
                                            feed_source,
                                            orders,
                                            broker,
                                            client_id,
                                            order_type,
                                            product_type,
                                        )
                                        
                                        if new_leg.is_spawned:
                                            leg_delay = Config.BT_FREQUENCY
                                            new_leg.next_action_time = trading_timestamp + leg_delay
                            else:
                                leg_.entered_by_trigger = True
                                leg_.is_activated = True
                                leg_.trigger_reentry_remaining -= 1
                                # logger.info("Here")
                                if leg_.trigger_reentry_remaining > 0:
                                    leg_.status = LEGSTATUS.TRIGGER_REENTRY
                                    leg_.entered_by_trigger = True
                                    leg_.is_activated = True
                                    leg_.next_action_time = trading_timestamp + leg_delay
                                    if leg_delay == 0:
                                        evaluate_leg_entry(
                                            strategy,
                                            leg_,
                                            timestamp,
                                            exit_time,
                                            index_base_price,
                                            index_price,
                                            fix_vix,
                                            available_trading_dates,
                                            current_date,
                                            trading_timestamp,
                                            atm,
                                            strike_diff,
                                            exchange,
                                            is_live,
                                            feed_source,
                                            orders,
                                            broker,
                                            client_id,
                                            order_type,
                                            product_type,
                                        )
                        elif condition == "squareoff":
                            if leg_.status == LEGSTATUS.ENTERED:
                                leg_.status = LEGSTATUS.EXIT_TRIGGERED
                                if leg_delay == 0:
                                    is_stop_loss_check_time_update, is_take_profit_check_time_update = evaluate_leg_exit(strategy,  leg_, current_date, timestamp, trading_timestamp, exit_time, index_price, index_base_price, fix_vix, atm, strike_diff, monthly_expiry, available_trading_dates, strategy_profits, strategy_losses,order_type, product_type, broker, client_id, orders, exchange, feed_source, is_live, True)
                        leg_.next_action_time = trading_timestamp + leg_delay
                strategy.legs.extend(new_legs)
    return is_stop_loss_check_time_update, is_take_profit_check_time_update