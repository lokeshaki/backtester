from app.commons.enums import NUMBERTYPE, ENUMELEMENT, SIDE, STRATEGYSTATUS, LEGSTATUS, ORDERSTATUS, REENTRYTYPE, OPTIONTYPE, UNDERLYINGTYPE, FORCEENTRYTYPE, RSIDIRECTION
from app.commons.models import TimeStamp
from app.commons.modules import logging, datetime
from app.commons.constants import MAX_INT
from app.commons.utils import reverse_side, get_strike_diff_for_index, round_to
from app.evaluator import utils as utils
from app.evaluator.utils import *
from app.parser.models import Strategy
from app.commons.models import Order
from app.broker import place_order
from app.feed import get_quote
from app.database.utils import get_monthly_expiry_date, get_previous_day_vix_value
from app.evaluator import utils

logger = logging.getLogger(__name__)

def evaluate_strategy(strategy: Strategy, current_date: int, trading_timestamp: int, index_base_price: float, fix_vix: float, broker: str, client_id: str, exchange: ENUMELEMENT, product_type: ENUMELEMENT, order_type: ENUMELEMENT, orders: list, available_trading_dates: list, feed_source: ENUMELEMENT, is_live: bool=False):
    if is_time_for_entry(trading_timestamp, strategy.entry_time):
        if strategy.status == STRATEGYSTATUS.CREATED or strategy.status == STRATEGYSTATUS.RUNNING:
            strike_diff = get_strike_diff_for_index(strategy.index)
            monthly_expiry = get_monthly_expiry_date(strategy.index, current_date, is_live)
            index_ohlc = get_underlying_ohlc(strategy, current_date, trading_timestamp, monthly_expiry, feed_source, is_live)
            
            index_open = index_ohlc.open/100.0
            index_price = index_open
            atm = round_to(index_open, strike_diff)
            
            if strategy.box:
                if not is_box_created(strategy, index_base_price, index_price, fix_vix, available_trading_dates, current_date, trading_timestamp, atm, strike_diff, exchange, feed_source, is_live):
                    return
            if strategy.entry_rsi:
                if not strategy.exit_rsi:
                    raise Exception("Exit RSI not defined")
                current_rs = get_current_rsi()
                if strategy.entry_rsi.direction == RSIDIRECTION.OUTSIDE:
                    if current_rs < strategy.entry_rsi.overbought_level and current_rs > strategy.entry_rsi.oversold_level:
                        ## GO Ahead
                        return
                elif strategy.entry_rsi.direction == RSIDIRECTION.INSIDE:
                    if current_rs > strategy.entry_rsi.overbought_level and current_rs < strategy.entry_rsi.oversold_level:
                        ## GO Ahead
                        return
            for leg in strategy.legs:
                if not leg.is_wait_in_time_updated:
                    leg.wait_in_time -= 60
                    leg.is_wait_in_time_updated = True
                is_immidiate_reentry = False
                if is_time_for_exit(trading_timestamp, strategy.exit_time):
                    leg.status == LEGSTATUS.EXITED
                    continue
                if leg.status == LEGSTATUS.ENTERED or leg.status == LEGSTATUS.EXITED:
                    continue
                if leg.status == LEGSTATUS.CREATED:
                    contractrize_leg(strategy.index, index_base_price, index_price, fix_vix, available_trading_dates, current_date, trading_timestamp, atm, strike_diff, exchange, leg, is_live, feed_source)
                if leg.status == LEGSTATUS.STOP_LOSS_REENTRY:
                    leg.wait_in_time = leg.stop_loss_reentry.value.check_frequency - (trading_timestamp - strategy.entry_time)%leg.stop_loss_reentry.value.check_frequency
                    leg.wait_in_time_devider = leg.stop_loss_reentry.value.check_frequency
                    leg.is_wait_in_time_updated = True
                    if leg.stop_loss_reentry.value.cutoff_time < trading_timestamp:
                        leg.status = LEGSTATUS.EXITED
                        continue
                    if leg.stop_loss_reentry.type == REENTRYTYPE.IMMIDIATE:
                        is_immidiate_reentry = True
                        leg.status = LEGSTATUS.CONTRACTRIZED
                    elif leg.stop_loss_reentry.type == REENTRYTYPE.IMMIDIATE_NC:
                        contractrize_leg(strategy.index, index_base_price, index_price, fix_vix, available_trading_dates, current_date, trading_timestamp, atm, strike_diff, exchange, leg, is_live, feed_source)
                        is_immidiate_reentry = True
                    elif leg.stop_loss_reentry.type == REENTRYTYPE.AS_ORIGINAL:
                        contractrize_leg(strategy.index, index_base_price, index_price, fix_vix, available_trading_dates, current_date, trading_timestamp, atm, strike_diff, exchange, leg, is_live, feed_source)
                        leg.is_waiting_for_stop_loss_reentry = True
                    elif leg.stop_loss_reentry.type == REENTRYTYPE.RE_COST:
                        contract_ohlc = get_quote(feed_source, leg.contract.symbol, current_date, trading_timestamp, trading_timestamp, leg.contract.expiry_date, leg.contract.strike_price, leg.contract.option_type, True)
                        if not contract_ohlc:
                            continue
                        # if leg.wait_and_trade.value == 0:
                        if not leg.recost_entry_on_crossover:
                            leg.current_wait_and_trade = leg.leg_entry_price - contract_ohlc.open/100
                            leg.contract_initial_price = contract_ohlc.open/100
                        else:
                            leg.current_wait_and_trade = leg.leg_entry_price - leg.contract.ltp
                            leg.contract_initial_price = leg.contract.ltp
                        
                        if not leg.recost_entry_on_crossover:
                            if leg.side == SIDE.SELL and leg.current_wait_and_trade > 0:
                                is_immidiate_reentry = True
                            elif leg.side == SIDE.BUY and leg.current_wait_and_trade < 0:
                                is_immidiate_reentry = True
                        leg.is_waiting_for_stop_loss_reentry = True
                        contract_ohlc = None
                        leg.status = LEGSTATUS.CONTRACTRIZED
                    else:
                        logger.error("Reentry type not supported")
                    leg.stop_loss_reentry_remaining -= 1
                elif leg.status == LEGSTATUS.TAKE_PROFIT_REENTRY:
                    leg.wait_in_time = leg.take_profit_reentry.value.check_frequency - (trading_timestamp - strategy.entry_time)%leg.take_profit_reentry.value.check_frequency
                    leg.wait_in_time_devider = leg.take_profit_reentry.value.check_frequency
                    leg.is_wait_in_time_updated = True
                    if leg.take_profit_reentry.value.cutoff_time < trading_timestamp:
                        leg.status = LEGSTATUS.EXITED
                        continue
                    if leg.take_profit_reentry.type == REENTRYTYPE.IMMIDIATE:
                        is_immidiate_reentry = True
                        leg.status = LEGSTATUS.CONTRACTRIZED
                    elif leg.take_profit_reentry.type == REENTRYTYPE.IMMIDIATE_NC:
                        contractrize_leg(strategy.index, index_base_price, index_price, fix_vix, available_trading_dates, current_date, trading_timestamp, atm, strike_diff, exchange, leg, is_live, feed_source)
                        is_immidiate_reentry = True
                    elif leg.take_profit_reentry.type == REENTRYTYPE.AS_ORIGINAL:
                        contractrize_leg(strategy.index, index_base_price, index_price, fix_vix, available_trading_dates, current_date, trading_timestamp, atm, strike_diff, exchange, leg, is_live, feed_source)
                        leg.is_waiting_for_take_profit_reentry = True
                    elif leg.take_profit_reentry.type == REENTRYTYPE.RE_COST:
                        contract_ohlc = get_quote(feed_source, leg.contract.symbol, current_date, trading_timestamp, trading_timestamp, leg.contract.expiry_date, leg.contract.strike_price, leg.contract.option_type, True)
                        if not contract_ohlc:
                            continue
                        if not leg.recost_entry_on_crossover:
                            leg.current_wait_and_trade = leg.leg_entry_price - contract_ohlc.open/100
                            leg.contract_initial_price = contract_ohlc.open/100
                        else:
                            leg.current_wait_and_trade = leg.leg_entry_price - leg.contract.ltp
                            leg.contract_initial_price = leg.contract.ltp

                        if not leg.recost_entry_on_crossover:
                            if leg.side == SIDE.SELL and leg.current_wait_and_trade < 0:
                                is_immidiate_reentry = True
                            elif leg.side == SIDE.BUY and leg.current_wait_and_trade > 0:
                                is_immidiate_reentry = True
                        leg.is_waiting_for_take_profit_reentry = True
                        contract_ohlc = None
                        leg.status = LEGSTATUS.CONTRACTRIZED
                    else:
                        logger.error("Reentry type not supported")
                    leg.take_profit_reentry_remaining -= 1
                

                if leg.status != LEGSTATUS.CONTRACTRIZED or strategy.place_order_after > trading_timestamp:
                    continue
                if leg.is_waiting_for_take_profit_reentry and leg.take_profit_reentry.value.cutoff_time < trading_timestamp:
                    leg.is_waiting_for_take_profit_reentry = False
                    leg.status = LEGSTATUS.EXITED
                    continue
                if leg.is_waiting_for_stop_loss_reentry and leg.stop_loss_reentry.value.cutoff_time < trading_timestamp:
                    leg.is_waiting_for_stop_loss_reentry = False
                    leg.status = LEGSTATUS.EXITED
                    continue
                contract_ohlc = get_quote(feed_source, leg.contract.symbol, current_date, trading_timestamp, trading_timestamp, leg.contract.expiry_date, leg.contract.strike_price, leg.contract.option_type, True)
                if contract_ohlc:
                    initial_price = leg.contract_initial_price
                    if not leg.contract_initial_price:
                        initial_price = leg.leg_entry_price
                    if((is_waiting_is_over(contract_ohlc.open/100.0, initial_price, leg.current_wait_and_trade) or is_immidiate_reentry) and abs(leg.wait_in_time)%leg.wait_in_time_devider == 0):
                        if leg.hedge:
                            contractrize_leg(strategy.index, index_base_price, index_price, fix_vix, available_trading_dates, current_date, trading_timestamp, atm, strike_diff, exchange, leg.hedge, is_live, feed_source)
                            quote = get_quote(feed_source, leg.hedge.contract.symbol, current_date, trading_timestamp, trading_timestamp, leg.hedge.contract.expiry_date, leg.hedge.contract.strike_price, leg.hedge.contract.option_type, True)
                            
                            if not quote:
                                continue
                            leg.hedge.contract.ltp = quote.open/100.0
                            order = Order(strategy.entry_number, strategy.name, leg.hedge.id, leg.entry_number, leg.stop_loss_entry_number, leg.take_profit_entry_number, leg.hedge.contract, product_type, order_type, leg.hedge.side, 0, 0, leg.quantity*leg.multiplier, TimeStamp(current_date, trading_timestamp), index_price, "Hedge Entry")
                            orders.append(order)
                            broker_order_id = place_order(broker, client_id, order, None)
                            order.broker_order_id = broker_order_id
                            leg.hedge.entry_order = order
                            leg.status = LEGSTATUS.WAITING_FOR_HEDGE_ENTRY
                        else:
                            leg.status = LEGSTATUS.WAITING_FOR_ENTRY
                    if leg.status == LEGSTATUS.WAITING_FOR_HEDGE_ENTRY:
                        if leg.hedge.entry_order.status == ORDERSTATUS.COMPLETE:
                            leg.status = LEGSTATUS.WAITING_FOR_ENTRY
                    if leg.status == LEGSTATUS.WAITING_FOR_ENTRY:
                        stop_loss_entry_number = ""
                        take_profit_entry_number = ""
                        if leg.reentry_reason == "STOP_LOSS":
                            stop_loss_entry_number = leg.stop_loss_entry_number
                        elif leg.reentry_reason == "TAKE_PROFIT":
                            take_profit_entry_number = leg.take_profit_entry_number
                            
                        if leg.recost_cascade:
                            if leg.reentry_reason != "STOP_LOSS":
                                leg.leg_entry_price = contract_ohlc.open/100
                        else:
                            if not leg.leg_entry_price:
                                if leg.wait_and_trade.value != 0:
                                    leg.leg_entry_price = leg.contract_initial_price + leg.current_wait_and_trade
                                else:
                                    leg.leg_entry_price = leg.contract_initial_price
                        order = Order(strategy.entry_number, strategy.name, leg.id, leg.entry_number, stop_loss_entry_number, take_profit_entry_number, leg.contract, product_type, order_type, leg.side, 0, 0, leg.quantity*leg.multiplier, TimeStamp(current_date, trading_timestamp), index_price, "Entry")
                        orders.append(order)
                        leg.orders.append(order)
                        broker_order_id = place_order(broker, client_id, order, None)
                        order.broker_order_id = broker_order_id
                        
                        leg.is_waiting_for_stop_loss_reentry = False
                        leg.is_waiting_for_take_profit_reentry = False
                        leg.status = LEGSTATUS.ENTERED
                        strategy.status = STRATEGYSTATUS.RUNNING
        if strategy.status == STRATEGYSTATUS.RUNNING:
            strategy_profit = 0
            strategy_loss = 0
            is_stop_loss_check_time_update = False
            is_take_profit_check_time_update = False
            for leg in strategy.legs:
                index_based_sl = False
                index_based_tp = False
                strategy_profit += leg.realized_pnl
                strategy_loss += leg.realized_pnl
                hedge_open_pnl = 0
                hedge_close_pnl = 0
                hedge_high_pnl = 0
                hedge_low_pnl = 0
                if leg.status == LEGSTATUS.ENTERED:
                    last_order = leg.orders[-1]
                    if last_order.status == ORDERSTATUS.COMPLETE:
                        if leg.hedge:
                            if leg.hedge.entry_order:
                                hedge_ohlc = get_quote(
                                    feed_source,
                                    leg.hedge.entry_order.contract.symbol,
                                    current_date,
                                    trading_timestamp,
                                    trading_timestamp,
                                    leg.hedge.entry_order.contract.expiry_date,
                                    leg.hedge.entry_order.contract.strike_price,
                                    leg.hedge.entry_order.contract.option_type
                                )
                                if hedge_ohlc:
                                    hedge_open_pnl = calculate_current_pnl(
                                        hedge_ohlc.open/100.0,
                                        leg.hedge.entry_order.average_price,
                                        leg.hedge.entry_order.side,
                                        leg.take_profit.type,
                                    )
                                    
                                    hedge_close_pnl = calculate_current_pnl(
                                        hedge_ohlc.close/100.0,
                                        leg.hedge.entry_order.average_price,
                                        leg.hedge.entry_order.side,
                                        leg.take_profit.type,
                                    )
                                    
                                    hedge_high_pnl = calculate_current_pnl(
                                        hedge_ohlc.high/100.0,
                                        leg.hedge.entry_order.average_price,
                                        leg.hedge.entry_order.side,
                                        leg.take_profit.type,
                                    )
                                    
                                    hedge_low_pnl = calculate_current_pnl(
                                        hedge_ohlc.low/100.0,
                                        leg.hedge.entry_order.average_price,
                                        leg.hedge.entry_order.side,
                                        leg.take_profit.type,
                                    )
                        if not leg.current_stop_loss:
                            if leg.stop_loss.type != NUMBERTYPE.ABSOLUTE_DELTA:
                                leg.current_stop_loss = calculate_stop_loss_points(index_price, last_order.average_price, leg.stop_loss)
                            if leg.take_profit.type != NUMBERTYPE.ABSOLUTE_DELTA:
                                leg.current_take_profit = calculate_take_profit_points(index_price, last_order.average_price, leg.take_profit)

                            leg.current_trailing_stop_loss = calculate_trailing_stop_loss_points(index_price, last_order.average_price, leg.trailing_stop_loss)
                        
                        minute_ohlc = get_quote(
                                    feed_source,
                                    last_order.contract.symbol,
                                    current_date,
                                    trading_timestamp,
                                    trading_timestamp,
                                    last_order.contract.expiry_date,
                                    last_order.contract.strike_price,
                                    last_order.contract.option_type,
                                )
                        profit_ohlc = get_quote(
                                    feed_source,
                                    last_order.contract.symbol,
                                    current_date,
                                    strategy.last_take_profit_check_time+60,
                                    trading_timestamp,
                                    last_order.contract.expiry_date,
                                    last_order.contract.strike_price,
                                    last_order.contract.option_type,
                                )
                        loss_ohlc = get_quote(
                                    feed_source,
                                    last_order.contract.symbol,
                                    current_date,
                                    strategy.last_stop_loss_check_time+60,
                                    trading_timestamp,
                                    last_order.contract.expiry_date,
                                    last_order.contract.strike_price,
                                    last_order.contract.option_type,
                                )
                        if strategy.underlying == UNDERLYINGTYPE.FUTURE:
                            profit_index_ohlc = get_quote(feed_source, strategy.index, current_date,strategy.last_take_profit_check_time,
                                    trading_timestamp, option_type=OPTIONTYPE.FUT, expiry=monthly_expiry)
                            loss_index_ohlc = get_quote(feed_source, strategy.index, current_date,strategy.last_stop_loss_check_time,
                                    trading_timestamp, option_type=OPTIONTYPE.FUT, expiry=monthly_expiry)
                        elif strategy.underlying == UNDERLYINGTYPE.CASH:
                            profit_index_ohlc = get_quote(feed_source, strategy.index, current_date, strategy.last_take_profit_check_time,
                                    trading_timestamp,)
                            loss_index_ohlc = get_quote(feed_source, strategy.index, current_date, strategy.last_stop_loss_check_time,
                                    trading_timestamp,)
                            
                        if not profit_ohlc or not loss_ohlc:
                            continue
                        
                        pnl_dict = get_pnl_dict(minute_ohlc, profit_index_ohlc, loss_index_ohlc, profit_ohlc, loss_ohlc, last_order, leg)
                        
                        if strategy.exit_price_config.take_profit_based_on == "OPEN":
                            if leg.take_profit.type in [NUMBERTYPE.INDEX_POINTS, NUMBERTYPE.INDEX_PERCENTAGE]:
                                tp_order_price = profit_ohlc.close/100.0
                                current_profit = pnl_dict["index_open_profit"]
                                index_based_tp = True
                            else:
                                tp_order_price = profit_ohlc.open/100.0
                                current_profit =  pnl_dict["open_profit"]
                        elif strategy.exit_price_config.take_profit_based_on == "CLOSE":
                            if leg.take_profit.type in [NUMBERTYPE.INDEX_POINTS, NUMBERTYPE.INDEX_PERCENTAGE]:
                                tp_order_price = profit_ohlc.close/100.0
                                current_profit = pnl_dict["index_close_profit"]
                                index_based_tp = True
                            else:
                                tp_order_price = profit_ohlc.close/100.0
                                current_profit = pnl_dict["close_profit"]
                        elif strategy.exit_price_config.take_profit_based_on not in ["OPEN", "CLOSE"]:
                            if leg.take_profit.type in [NUMBERTYPE.INDEX_POINTS, NUMBERTYPE.INDEX_PERCENTAGE]:
                                if last_order.side == SIDE.BUY:
                                    tp_order_price = profit_ohlc.high/100.0
                                    current_profit = pnl_dict["index_high_profit"]
                                    index_based_tp = True
                                else:
                                    tp_order_price = profit_ohlc.low/100.0
                                    current_profit = pnl_dict["index_low_profit"]
                                    index_based_tp = True
                            else:
                                if last_order.side == SIDE.BUY:
                                    tp_order_price = profit_ohlc.high/100.0
                                    current_profit = pnl_dict["high_profit"]
                                else:
                                    tp_order_price = profit_ohlc.low/100.0
                                    current_profit = pnl_dict["low_profit"]
                        
                        if strategy.exit_price_config.stop_loss_based_on == "OPEN":
                            if leg.stop_loss.type in [NUMBERTYPE.INDEX_POINTS, NUMBERTYPE.INDEX_PERCENTAGE]:
                                sl_order_price = loss_ohlc.close/100.0
                                current_stop_loss = pnl_dict["index__open_loss"]
                                index_based_sl = True
                            else:
                                sl_order_price = loss_ohlc.open/100.0
                                current_stop_loss = pnl_dict["open_loss"]
                        elif strategy.exit_price_config.stop_loss_based_on == "CLOSE":
                            if leg.stop_loss.type in [NUMBERTYPE.INDEX_POINTS, NUMBERTYPE.INDEX_PERCENTAGE]:
                                sl_order_price = loss_ohlc.close/100.0
                                current_stop_loss = pnl_dict["index_close_loss"]
                                index_based_sl = True
                            else:
                                sl_order_price = loss_ohlc.close/100.0
                                current_stop_loss = pnl_dict["close_loss"]
                        elif strategy.exit_price_config.stop_loss_based_on not in ["OPEN", "CLOSE"]:
                            if leg.stop_loss.type in [NUMBERTYPE.INDEX_POINTS, NUMBERTYPE.INDEX_PERCENTAGE]:
                                if last_order.side == SIDE.BUY:
                                    sl_order_price = loss_ohlc.high/100.0
                                    current_stop_loss = pnl_dict["index_high_loss"]
                                    index_based_sl = True
                                else:
                                    sl_order_price = loss_ohlc.close/100.0
                                    current_stop_loss = pnl_dict["index_high_loss"]
                                    index_based_sl = True
                            else:
                                if last_order.side == SIDE.BUY:
                                    sl_order_price = loss_ohlc.low/100.0
                                    current_stop_loss = pnl_dict["low_loss"]
                                else:
                                    sl_order_price = loss_ohlc.high/100.0
                                    current_stop_loss = pnl_dict["high_loss"]
                                    
                        if pnl_dict['high_loss'] < 0 and abs(pnl_dict['high_loss']) > last_order.max_loss:
                            last_order.max_loss = abs(pnl_dict['high_loss'])
                        elif pnl_dict['high_profit'] > 0 and pnl_dict['high_profit'] > last_order.max_profit:
                            last_order.max_profit = abs(pnl_dict['high_profit'])
                            
                        if pnl_dict['low_loss'] < 0 and abs(pnl_dict['low_loss']) > last_order.max_loss:
                            last_order.max_loss = abs(pnl_dict['low_loss'])
                        elif pnl_dict['low_profit'] > 0 and pnl_dict['low_profit'] > last_order.max_profit:
                            last_order.max_profit = abs(pnl_dict['low_profit'])          
                        
                        sl_hit, delta_based_sl, is_stop_loss_check_time_update = utils.is_sl_hit(strategy, leg, current_date, trading_timestamp, atm, current_stop_loss, last_order, feed_source)
                        
                        tp_hit, delta_based_tp, is_take_profit_check_time_update = utils.is_tp_hit(
                            strategy, leg, current_date, trading_timestamp, atm, current_profit, last_order, feed_source)
                        
                        if sl_hit:
                            if leg.hedge:
                                if leg.hedge.entry_order:
                                    if leg.hedge.entry_order.status == ORDERSTATUS.COMPLETE:
                                        utils.place_hedge_exit_order(strategy, leg, product_type, order_type, current_date, trading_timestamp, index_price, broker, client_id, "Stop Loss Hedge Exit", orders)
                                    else:
                                        leg.status = LEGSTATUS.WAITING_FOR_STOP_LOSS_EXIT
                            else:
                                leg.status = LEGSTATUS.WAITING_FOR_STOP_LOSS_EXIT
                        elif tp_hit:
                            if leg.hedge:
                                if leg.hedge.entry_order:
                                    if leg.hedge.entry_order.status == ORDERSTATUS.COMPLETE:
                                        utils.place_hedge_exit_order(strategy, leg, product_type, order_type, current_date, trading_timestamp, index_price, broker, client_id, "Take Profit Hedge Exit", orders)
                                    else:
                                        leg.status = LEGSTATUS.WAITING_FOR_TAKE_PROFIT_EXIT
                            else:
                                leg.status = LEGSTATUS.WAITING_FOR_TAKE_PROFIT_EXIT
                                        
                        elif is_time_for_exit(
                            trading_timestamp, strategy.exit_time
                        ):
                            if leg.hedge:
                                if leg.hedge.entry_order:
                                    if leg.hedge.entry_order.status == ORDERSTATUS.COMPLETE:
                                        utils.place_hedge_exit_order(strategy, leg, product_type, order_type, current_date, trading_timestamp, index_price, broker, client_id, "Time Hedge Exit", orders)
                                    else:
                                        leg.status = LEGSTATUS.WIATING_FOR_TIME_EXIT
                            else:
                                leg.status = LEGSTATUS.WIATING_FOR_TIME_EXIT
                        else:
                            if strategy.pnl_calculation_from == "OPEN":
                                strategy_profit += pnl_dict['minute_open_profit']*last_order.quantity
                                strategy_loss += pnl_dict['minute_open_loss']*last_order.quantity
                                if leg.hedge_pnl_effect and hedge_open_pnl:
                                    strategy_profit += hedge_open_pnl*leg.hedge.entry_order.quantity
                                    strategy_loss += hedge_open_pnl*leg.hedge.entry_order.quantity

                            elif strategy.pnl_calculation_from == "CLOSE":
                                strategy_profit += pnl_dict['minute_close_profit']*last_order.quantity
                                strategy_loss += pnl_dict['minute_high_loss']*last_order.quantity
                                if leg.hedge_pnl_effect and hedge_close_pnl:
                                    strategy_profit += hedge_close_pnl*leg.hedge.entry_order.quantity
                                    strategy_loss += hedge_close_pnl*leg.hedge.entry_order.quantity

                            elif strategy.pnl_calculation_from == "HIGH":
                                strategy_profit += pnl_dict['minute_high_profit']*last_order.quantity
                                strategy_loss += pnl_dict['minute_high_loss']*last_order.quantity
                                if leg.hedge_pnl_effect and hedge_high_pnl:
                                    strategy_profit += hedge_high_pnl*leg.hedge.entry_order.quantity
                                    strategy_loss += hedge_high_pnl*leg.hedge.entry_order.quantity

                            elif strategy.pnl_calculation_from == "LOW":
                                strategy_profit += pnl_dict['minute_low_profit']*last_order.quantity
                                strategy_loss += pnl_dict['minute_low_loss']*last_order.quantity
                                if leg.hedge_pnl_effect and hedge_low_pnl:
                                    strategy_profit += hedge_low_pnl*leg.hedge.entry_order.quantity
                                    strategy_loss += hedge_low_pnl*leg.hedge.entry_order.quantity

                            elif strategy.pnl_calculation_from not in ["OPEN", "CLOSE", "HIGH", "LOW"]:
                                if last_order.side == SIDE.BUY:
                                    strategy_profit += pnl_dict['minute_high_profit']*last_order.quantity
                                    strategy_loss += pnl_dict['minute_low_loss']*last_order.quantity
                                else:
                                    strategy_profit += pnl_dict['minute_low_profit']*last_order.quantity
                                    strategy_loss += pnl_dict['minute_high_loss']*last_order.quantity
                                
                                if leg.hedge_pnl_effect and hedge_low_pnl:
                                    if leg.hedge.entry_order.side == SIDE.BUY:
                                        strategy_profit += hedge_high_pnl*leg.hedge.entry_order.quantity
                                        strategy_loss += hedge_low_pnl*leg.hedge.entry_order.quantity
                                    else:
                                        strategy_profit += hedge_low_pnl*leg.hedge.entry_order.quantity
                                        strategy_loss += hedge_high_pnl*leg.hedge.entry_order.quantity
                        if leg.current_stop_loss:
                            stop_loss_move = calculate_how_much_stop_loss_should_move(pnl_dict['index_open_profit'] ,  pnl_dict['open_profit'], leg.current_trailing_stop_loss[0], leg.current_trailing_stop_loss[1], index_based_sl, index_based_tp)
                            new_stop_loss = stop_loss_update( calculate_stop_loss_points(last_order.index_price, last_order.average_price, leg.stop_loss, leg.side), leg.current_stop_loss, stop_loss_move)
                            if new_stop_loss:
                                leg.is_stop_loss_trailed = True
                                leg.current_stop_loss = new_stop_loss
                if leg.status == LEGSTATUS.WAITING_FOR_HEDGE_EXIT:
                    if leg.hedge.exit_order.status == ORDERSTATUS.COMPLETE:
                        if leg.hedge_pnl_effect:
                            hedge_pnl = calculate_current_pnl(leg.hedge.exit_order.average_price, leg.hedge.entry_order.average_price, leg.hedge.side, leg.take_profit.type)*leg.quantity*leg.multiplier

                            if leg.hedge.side == SIDE.BUY:
                                strategy_profit += hedge_pnl
                                strategy_loss += hedge_pnl          
                                leg.realized_pnl += hedge_pnl                  
                            else:
                                strategy_profit += -hedge_pnl
                                strategy_loss += -hedge_pnl
                                leg.realized_pnl += hedge_pnl
                        if leg.hedge.exit_order.reason == "Stop Loss Hedge Exit":
                            leg.status = LEGSTATUS.WAITING_FOR_STOP_LOSS_EXIT
                        elif leg.hedge.exit_order.reason == "Take Profit Hedge Exit":
                            leg.status = LEGSTATUS.WAITING_FOR_TAKE_PROFIT_EXIT
                        else:
                            leg.status = LEGSTATUS.WIATING_FOR_TIME_EXIT
                if leg.status == LEGSTATUS.WAITING_FOR_TAKE_PROFIT_EXIT:
                    if index_based_tp:
                        reason = "Index Based Take Profit Hit"
                    else:
                        reason = "Take Profit Hit"
                    order = Order(strategy.entry_number, strategy.name, leg.id, leg.entry_number, leg.stop_loss_entry_number, leg.take_profit_entry_number, last_order.contract, product_type, order_type, reverse_side(leg.side), 0, 0, last_order.quantity, TimeStamp(current_date, trading_timestamp), index_price, reason)
                    leg.entry_number += 1
                    leg.take_profit_entry_number += 1
                    if strategy.exit_price_config.trade_file_exit_price_on_take_profit != "TICK" and not index_based_tp and not delta_based_tp:
                        if last_order.side == SIDE.BUY:
                            tp_order_price = last_order.average_price + leg.current_take_profit
                        else:
                            tp_order_price = last_order.average_price - leg.current_take_profit
                    broker_order_id = place_order(broker, client_id, order, tp_order_price)
                    order.broker_order_id = broker_order_id
                    orders.append(order)
                    leg.orders.append(order)
                    leg.status = LEGSTATUS.WAITING_FOR_TAKE_PROFIT_FILL
                if leg.status == LEGSTATUS.WAITING_FOR_STOP_LOSS_EXIT:
                    if index_based_sl:
                        exit_reason = "Index Based Stop Loss Hit"
                        if leg.is_stop_loss_trailed:
                            exit_reason = "Index Based Trailing Stop Loss Hit"
                    else:
                        exit_reason = "Stop Loss Hit"
                        if leg.is_stop_loss_trailed:
                            exit_reason = "Trailing Stop Loss Hit"
                    order = Order(strategy.entry_number, strategy.name, leg.id, leg.entry_number, leg.stop_loss_entry_number, leg.take_profit_entry_number, last_order.contract, product_type, order_type, reverse_side(leg.side), 0, 0, last_order.quantity, TimeStamp(current_date, trading_timestamp), index_price, exit_reason)
                    leg.entry_number += 1
                    leg.stop_loss_entry_number += 1
                    if strategy.exit_price_config.trade_file_exit_price_on_stop_loss != "TICK" and not index_based_sl and not delta_based_sl:
                        if last_order.side == SIDE.BUY:
                            sl_order_price = last_order.average_price - leg.current_stop_loss
                        else:
                            sl_order_price = last_order.average_price + leg.current_stop_loss
                    
                    broker_order_id = place_order(broker, client_id, order, sl_order_price)
                    order.broker_order_id = broker_order_id
                    orders.append(order)
                    leg.orders.append(order)
                    leg.status = LEGSTATUS.WAITING_FOR_STOP_LOSS_FILL
                if leg.status == LEGSTATUS.WIATING_FOR_TIME_EXIT:
                    booked_pnl = pnl_dict['open_loss']*last_order.quantity
                    order = Order(strategy.entry_number, strategy.name, leg.id, leg.entry_number, leg.stop_loss_entry_number, leg.take_profit_entry_number, last_order.contract, product_type, order_type, reverse_side(leg.side), 0, 0, last_order.quantity, TimeStamp(current_date, trading_timestamp), index_price, "Exit Time Hit")
                    broker_order_id = place_order(broker, client_id, order)
                    leg.realized_pnl += booked_pnl
                    strategy_profit += booked_pnl
                    strategy_loss += booked_pnl
                    orders.append(order)
                    leg.orders.append(order)
                    order.broker_order_id = broker_order_id
                    leg.status = LEGSTATUS.WAITING_FOR_TIME_EXIT_FILL
                    
                if leg.status == LEGSTATUS.WAITING_FOR_STOP_LOSS_FILL:
                    exit_order = leg.orders[-1]
                    if exit_order.status == ORDERSTATUS.COMPLETE:
                        entry_order = leg.orders[-2]
                        booked_pnl = calculate_current_pnl(exit_order.average_price,entry_order.average_price,entry_order.side,leg.take_profit.type)*entry_order.quantity
                        leg.contract.ltp = exit_order.average_price
                        leg.realized_pnl += booked_pnl
                        strategy_profit += booked_pnl
                        strategy_loss += booked_pnl
                        leg.current_stop_loss = None
                        leg.current_take_profit = None
                        leg.current_trailing_stop_loss = None
                        leg.is_stop_loss_trailed = False
                        if leg.stop_loss_reentry_remaining > 0 and leg.stop_loss_reentry.value.cutoff_time > trading_timestamp:
                            leg.status = LEGSTATUS.STOP_LOSS_REENTRY
                            leg.reentry_reason = "STOP_LOSS"
                        else:
                            leg.status = LEGSTATUS.EXITED
                if leg.status == LEGSTATUS.WAITING_FOR_TAKE_PROFIT_FILL:
                    exit_order = leg.orders[-1]
                    if exit_order.status == ORDERSTATUS.COMPLETE:
                        entry_order = leg.orders[-2]
                        booked_pnl = calculate_current_pnl(exit_order.average_price,entry_order.average_price,entry_order.side,leg.take_profit.type)*entry_order.quantity
                        leg.contract.ltp = exit_order.average_price
                        leg.realized_pnl += booked_pnl
                        strategy_profit += booked_pnl
                        strategy_loss += booked_pnl
                        leg.current_stop_loss = None
                        leg.current_take_profit = None
                        leg.current_trailing_stop_loss = None
                        leg.is_stop_loss_trailed = False
                        if leg.take_profit_reentry_remaining > 0 and leg.take_profit_reentry.value.cutoff_time > trading_timestamp:
                            leg.status = LEGSTATUS.TAKE_PROFIT_REENTRY
                            leg.reentry_reason = "TAKE_PROFIT"
                        else:
                            leg.status = LEGSTATUS.EXITED
                if leg.status == LEGSTATUS.WAITING_FOR_TIME_EXIT_FILL:
                    exit_order = leg.orders[-1]
                    if exit_order.status == ORDERSTATUS.COMPLETE:
                        leg.status = LEGSTATUS.EXITED
                        
            if is_stop_loss_check_time_update:
                strategy.last_stop_loss_check_time = trading_timestamp
            if is_take_profit_check_time_update:
                strategy.last_take_profit_check_time = trading_timestamp
            if strategy.stop_loss.value != MAX_INT and strategy_loss < 0 and strategy_loss <= strategy.stop_loss.value:
                strategy.status = STRATEGYSTATUS.SL_HIT
                for leg in strategy.legs:
                    if leg.status == LEGSTATUS.ENTERED:
                        if leg.hedge:
                            if leg.hedge.entry_order:
                                if leg.hedge.entry_order.status == ORDERSTATUS.COMPLETE:
                                    if strategy.pnl_calculation_from == "OPEN":
                                        exit_price = hedge_ohlc.open/100.0
                                    elif strategy.pnl_calculation_from == "CLOSE":
                                        exit_price = hedge_ohlc.close/100.0
                                    else:
                                        exit_price = hedge_ohlc.low/100.0 if leg.hedge.side == SIDE.BUY else hedge_ohlc.high/100.0
                                    hedge_exit_order = Order(strategy.entry_number, strategy.name, leg.hedge.id, leg.entry_number, leg.stop_loss_entry_number, leg.take_profit_entry_number, leg.hedge.contract, product_type, order_type, reverse_side(leg.hedge.side), 0, 0, leg.quantity*leg.multiplier, TimeStamp(current_date, trading_timestamp), index_price, "Stg Stop Loss Hedge Exit")
                                    broker_order_id = place_order(broker, client_id, hedge_exit_order,exit_price)
                                    hedge_exit_order.broker_order_id = broker_order_id
                                    orders.append(hedge_exit_order)
                                    leg.hedge.exit_order = hedge_exit_order
                                    leg.status = LEGSTATUS.WAITING_FOR_HEDGE_EXIT
                                else:
                                    leg.status = LEGSTATUS.WAITING_FOR_STG_STOP_LOSS_EXIT
                        else:
                            leg.status = LEGSTATUS.WAITING_FOR_STG_STOP_LOSS_EXIT
                    
                    elif leg.status in [LEGSTATUS.CREATED, LEGSTATUS.CONTRACTRIZED]:
                        leg.status = LEGSTATUS.EXITED
                if strategy.stop_loss_reentry_remaining > 0:
                    strategy.entry_number += 1
                    strategy.stop_loss_reentry_remaining -= 1
                else:
                    strategy.is_first_entry = True
                    strategy.status = STRATEGYSTATUS.COMPLETED
                    
            if strategy.take_profit.value != MAX_INT and strategy_profit > 0 and strategy_profit >= strategy.take_profit.value:
                strategy.status = STRATEGYSTATUS.TP_HIT
                for leg in strategy.legs:
                    if leg.status == LEGSTATUS.ENTERED:
                        if leg.hedge:
                            if leg.hedge.entry_order:
                                if leg.hedge.entry_order.status == ORDERSTATUS.COMPLETE:
                                    if strategy.pnl_calculation_from == "OPEN":
                                        exit_price = hedge_ohlc.open/100.0
                                    elif strategy.pnl_calculation_from == "CLOSE":
                                        exit_price = hedge_ohlc.close/100.0
                                    else:
                                        exit_price = hedge_ohlc.low/100.0 if leg.hedge.side == SIDE.BUY else hedge_ohlc.high/100.0
                                    hedge_exit_order = Order(strategy.entry_number, strategy.name, leg.hedge.id, leg.entry_number, leg.stop_loss_entry_number, leg.take_profit_entry_number, leg.hedge.contract, product_type, order_type, reverse_side(leg.hedge.side), 0, 0, leg.quantity*leg.multiplier, TimeStamp(current_date, trading_timestamp), index_price, "Stg Take Profit Hedge Exit")
                                    broker_order_id = place_order(broker, client_id, hedge_exit_order,exit_price)
                                    hedge_exit_order.broker_order_id = broker_order_id
                                    orders.append(hedge_exit_order)
                                    leg.hedge.exit_order = hedge_exit_order
                                    leg.status = LEGSTATUS.WAITING_FOR_HEDGE_EXIT
                                else:
                                    leg.status = LEGSTATUS.WAITING_FOR_STG_TAKE_PROFIT_EXIT
                        else:
                            leg.status = LEGSTATUS.WAITING_FOR_STG_TAKE_PROFIT_EXIT
                    elif leg.status in [LEGSTATUS.CREATED, LEGSTATUS.CONTRACTRIZED]:
                        leg.status = LEGSTATUS.EXITED
                if strategy.take_profit_reentry_remaining > 0:
                    strategy.entry_number += 1
                    strategy.take_profit_reentry_remaining -= 1
                else:
                    strategy.status = STRATEGYSTATUS.COMPLETED
                
            is_all_legs_exited = True
            for leg in strategy.legs:
                if leg.status == LEGSTATUS.WAITING_FOR_HEDGE_EXIT:
                    if leg.hedge.exit_order.status == ORDERSTATUS.COMPLETE:
                        if leg.hedge_pnl_effect:
                            hedge_pnl = calculate_current_pnl(leg.hedge.exit_order.average_price, leg.hedge.entry_order.average_price, leg.hedge.side, leg.take_profit.type)*leg.quantity*leg.multiplier
                            if leg.hedge.side == SIDE.BUY:
                                leg.realized_pnl += hedge_pnl
                            else:
                                leg.realized_pnl += -hedge_pnl
                        if leg.hedge.exit_order.reason == "Stg Stop Loss Hedge Exit":
                            leg.status = LEGSTATUS.WAITING_FOR_STG_STOP_LOSS_EXIT
                        elif leg.hedge.exit_order.reason == "Stg Take Profit Hedge Exit":
                            leg.status = LEGSTATUS.WAITING_FOR_STG_TAKE_PROFIT_EXIT
                if leg.status == LEGSTATUS.WAITING_FOR_STG_STOP_LOSS_EXIT:
                    if leg.status == LEGSTATUS.ENTERED:
                        last_order = leg.orders[-1]
                        ohlc = get_quote(
                            feed_source,
                            last_order.contract.symbol,
                            current_date,
                            trading_timestamp,
                            trading_timestamp,
                            last_order.contract.expiry_date,
                            last_order.contract.strike_price,
                            last_order.contract.option_type,
                        )
                        if strategy.pnl_calculation_from == "OPEN":
                            exit_price = ohlc.open/100.0
                        elif strategy.pnl_calculation_from == "CLOSE":
                            exit_price = ohlc.close/100.0
                        else:
                            exit_price = ohlc.low/100.0 if last_order.side == SIDE.BUY else ohlc.high/100.0

                        order = Order(strategy.entry_number, strategy.name, leg.id, leg.entry_number, leg.stop_loss_entry_number, leg.take_profit_entry_number, last_order.contract, product_type, order_type, reverse_side(leg.side), 0, 0, last_order.quantity, TimeStamp(current_date, trading_timestamp), index_price, "Overall Stop Loss Hit")
                        broker_order_id = place_order(broker, client_id, order, exit_price)
                        order.broker_order_id = broker_order_id
                        orders.append(order)
                        leg.orders.append(order)
                        leg.status = LEGSTATUS.WAITING_FOR_STG_STOP_LOSS_FILL
                
                if leg.status == LEGSTATUS.WAITING_FOR_STG_TAKE_PROFIT_EXIT:
                    last_order = leg.orders[-1]
                    ohlc = get_quote(
                        feed_source,
                        last_order.contract.symbol,
                        current_date,
                        trading_timestamp,
                        trading_timestamp,
                        last_order.contract.expiry_date,
                        last_order.contract.strike_price,
                        last_order.contract.option_type,
                    )
                    if strategy.pnl_calculation_from == "OPEN":
                        exit_price = ohlc.open/100.0
                    elif strategy.pnl_calculation_from == "CLOSE":
                        exit_price = ohlc.close/100.0
                    else:
                        exit_price = ohlc.low/100.0 if last_order.side == SIDE.SELL else ohlc.high/100.0
                    order = Order(strategy.entry_number, strategy.name, leg.id, leg.entry_number, leg.stop_loss_entry_number, leg.take_profit_entry_number, last_order.contract, product_type, order_type, reverse_side(leg.side), 0, 0, last_order.quantity, TimeStamp(current_date, trading_timestamp), index_price, "Overall Take Profit Hit")
                    broker_order_id = place_order(broker, client_id, order, exit_price)
                    order.broker_order_id = broker_order_id
                    orders.append(order)
                    leg.orders.append(order)
                    leg.status = LEGSTATUS.WAITING_FOR_STG_TAKE_PROFIT_FILL
                
                if leg.status == LEGSTATUS.WAITING_FOR_STG_STOP_LOSS_FILL:
                    exit_order = leg.orders[-1]
                    if exit_order.status == ORDERSTATUS.COMPLETE:
                        entry_order = leg.orders[-2]
                        leg.realized_pnl += calculate_current_pnl(exit_order.average_price, entry_order.average_price, entry_order.side, leg.take_profit.type)*entry_order.quantity
                        leg.status = LEGSTATUS.EXITED
                    
                if leg.status == LEGSTATUS.WAITING_FOR_STG_TAKE_PROFIT_FILL:
                    exit_order = leg.orders[-1]
                    if exit_order.status == ORDERSTATUS.COMPLETE:
                        entry_order = leg.orders[-2]
                        leg.realized_pnl += calculate_current_pnl(exit_order.average_price, entry_order.average_price, entry_order.side, leg.take_profit.type)*entry_order.quantity
                        leg.status = LEGSTATUS.EXITED
                if leg.status not in [LEGSTATUS.EXITED, LEGSTATUS.STOP_LOSS_REENTRY, LEGSTATUS.TAKE_PROFIT_REENTRY]:
                    is_all_legs_exited = False
            if is_all_legs_exited and (strategy.take_profit_reentry_remaining > -1 or strategy.stop_loss_reentry_remaining > -1) and strategy.status in [STRATEGYSTATUS.SL_HIT, STRATEGYSTATUS.TP_HIT]:
                reset_strategy(strategy)
                strategy.status = STRATEGYSTATUS.RUNNING
            
    for leg in strategy.legs:   
        if leg.stop_loss.params.check_frequency == 60:
            strategy.last_stop_loss_check_time = trading_timestamp
        if leg.take_profit.params.check_frequency == 60:
            strategy.last_take_profit_check_time = trading_timestamp