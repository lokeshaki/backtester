from app.commons.enums import NUMBERTYPE, ENUMELEMENT, SIDE, STRATEGYSTATUS, LEGSTATUS, ORDERSTATUS, OPTIONTYPE, UNDERLYINGTYPE
from app.commons.models import TimeStamp
from app.commons.modules import logging
from app.commons.constants import MARKET_START_TIME, MIN_INT
from app.commons.utils import reverse_side, get_strike_diff_for_index, round_to
from app.evaluator import utils as utils
from app.evaluator.utils import *
from app.parser.models import VwapStrategy
from app.commons.models import Order
from app.broker import place_order
from app.feed import get_quote
from app.database.utils import get_monthly_expiry_date
from app.config import Config

logger = logging.getLogger(__name__)


def evaluate_heikin_strategy(strategy: VwapStrategy, current_date: int, trading_timestamp: int, index_base_price: float, fix_vix: float, broker: str, client_id: str, exchange: ENUMELEMENT, product_type: ENUMELEMENT, order_type: ENUMELEMENT, orders: list, available_trading_dates: list, feed_source: ENUMELEMENT, is_live: bool=False):
    
    can_make_full_candle = (trading_timestamp - MARKET_START_TIME[exchange.name])%strategy.checking_interval == 0
    
    if strategy.entry_date and strategy.exit_date:
        if (current_date < strategy.entry_date and current_date > strategy.exit_date):
            return
        else:
            entry_time = int(str(strategy.entry_date)+str(strategy.entry_time))
            exit_time = int(str(strategy.exit_date)+str(strategy.exit_time))
    else:
        entry_time = int(str(current_date)+str(strategy.entry_time))
        exit_time = int(str(current_date)+str(strategy.exit_time))
    
    timestamp = int(str(current_date)+str(trading_timestamp))
    tick_pnl = 0

    if is_time_for_entry(timestamp, entry_time):
        previous_date = available_trading_dates[available_trading_dates.index(current_date)-1]
        for leg in strategy.legs:
            leg.is_wait_in_time_updated = False
        if (strategy.status == STRATEGYSTATUS.CREATED or strategy.status == STRATEGYSTATUS.RUNNING) and strategy.next_reentry_check_time <= trading_timestamp:
            strategy.next_reentry_check_time = 0
            strike_diff = get_strike_diff_for_index(strategy.index)
            check_interval = 0
            if strategy.underlying == UNDERLYINGTYPE.FUTURE:
                monthly_expiry = get_monthly_expiry_date(strategy.index, current_date, is_live)
                index_ohlc = get_quote(feed_source, strategy.index, current_date,trading_timestamp - check_interval, trading_timestamp, option_type=OPTIONTYPE.FUT, expiry=monthly_expiry)
            elif strategy.underlying == UNDERLYINGTYPE.CASH:
                index_ohlc = get_quote(feed_source, strategy.index, current_date, trading_timestamp - check_interval, trading_timestamp)
            index_price = index_ohlc.open/100.0
            atm = round_to(index_price, strike_diff)
                        
            for leg in strategy.legs:
                if not leg.is_wait_in_time_updated:
                    leg.wait_in_time -= Config.BT_FREQUENCY
                    leg.is_wait_in_time_updated = True
                if is_time_for_exit(timestamp, exit_time):
                    leg.status == LEGSTATUS.EXITED
                    continue
                if leg.status == LEGSTATUS.ENTERED or leg.status == LEGSTATUS.EXITED:
                    continue
                
                if leg.status == LEGSTATUS.CREATED and (leg.refresh_contract_on_reentry or (not leg.refresh_contract_on_reentry and not leg.is_contracterized_before)):
                    contractrize_vwap_leg(strategy.index, index_base_price, index_price, fix_vix, available_trading_dates, current_date, trading_timestamp, atm, strike_diff, exchange, leg, is_live, feed_source)
                    leg.is_contracterized_before = True
                elif (not leg.refresh_contract_on_reentry and leg.is_contracterized_before):
                    leg.status = LEGSTATUS.CONTRACTRIZED

                if leg.status != LEGSTATUS.CONTRACTRIZED or strategy.place_order_after > trading_timestamp:
                    continue
            
            if can_make_full_candle and (not strategy.indicator_based_entry):
                if strategy.indicator_candle_based_on == "underlying":
                    normal_candles = get_candles(strategy.index, int(strategy.max_length*3), strategy.checking_interval, current_date, previous_date, trading_timestamp,0, 0, is_live)
                else:
                    normal_candles = get_combined_candle(strategy.index, strategy.legs, strategy.max_length, strategy.checking_interval, current_date, previous_date, trading_timestamp, is_live)
                heikin_ashi_candles = get_heikin_ashi(normal_candles)

                if (heikin_ashi_candles is not None) and len(heikin_ashi_candles) != 0:
                
                    if eval_indicators(strategy.entry_indicators, heikin_ashi_candles):
                        strategy.ready_to_enter = True
                        strategy.indicator_based_entry = True
                        if strategy.signal_candle_low == MAX_INT:
                            strategy.signal_candle_low = heikin_ashi_candles[-1].low
                    else:
                        strategy.ready_to_enter = False
                        strategy.indicator_based_entry = False
                        strategy.signal_candle_low = MAX_INT
                    
                    if strategy.ready_to_enter:
                        if heikin_ashi_candles[-1].close >= strategy.signal_candle_low:
                            strategy.ready_to_enter = False
                            strategy.indicator_based_entry = False
                
            if(strategy.ready_to_enter):
                if leg.status == LEGSTATUS.CONTRACTRIZED:
                    for leg in strategy.legs:
                        if is_time_for_exit(timestamp, exit_time):
                            leg.status == LEGSTATUS.EXITED
                            continue
                        contract_ohlc = get_quote(feed_source, leg.contract.symbol, current_date, strategy.entry_time, trading_timestamp, leg.contract.expiry_date, leg.contract.strike_price, leg.contract.option_type, True)
                        if not contract_ohlc:
                            continue
                        if leg.hedge:
                            contractrize_vwap_leg(strategy.index, index_base_price, index_price, fix_vix, available_trading_dates, current_date, trading_timestamp, atm, strike_diff, exchange, leg.hedge, is_live, feed_source)
                            quote = get_quote(feed_source, leg.hedge.contract.symbol, current_date, strategy.entry_time, trading_timestamp, leg.hedge.contract.expiry_date, leg.hedge.contract.strike_price, leg.hedge.contract.option_type, True)
                            
                            if not quote:
                                return
                            leg.hedge.contract.ltp = quote.open/100.0
                            order = Order(strategy.entry_number, strategy.name, leg.hedge.id, leg.entry_number, leg.stop_loss_entry_number, leg.take_profit_entry_number, leg.hedge.contract, product_type, order_type, leg.hedge.side, 0, 0, leg.quantity*leg.multiplier*strategy.multiplier, TimeStamp(current_date, trading_timestamp), index_price, "Hedge Entry")
                            orders.append(order)
                            broker_order_id = place_order(broker, client_id, order, None)
                            order.broker_order_id = broker_order_id
                            leg.hedge.entry_order = order
                            leg.status = LEGSTATUS.WAITING_FOR_HEDGE_ENTRY
                        else:
                            leg.status = LEGSTATUS.WAITING_FOR_ENTRY
                        if leg.status == LEGSTATUS.WAITING_FOR_HEDGE_ENTRY:
                            if leg.hedge.entry_order.status == ORDERSTATUS.COMPLETE:
                                leg.status = LEGSTATUS.WAITING_FOR_ENTRY
                        if leg.status == LEGSTATUS.WAITING_FOR_ENTRY:
                            stop_loss_entry_number = ""
                            take_profit_entry_number = ""
                            if leg.reentry_reason == "STOP_LOSS":
                                stop_loss_entry_number = leg.stop_loss_entry_number
                            elif leg.reentry_reason == "TAKE_PROFIT":
                                take_profit_entry_number = leg.take_profit_entry_number
                                
                            # leg.leg_entry_price = leg.contract_initial_price
                            order = Order(strategy.entry_number, strategy.name, leg.id, leg.entry_number, stop_loss_entry_number, take_profit_entry_number, leg.contract, product_type, order_type, leg.side, 0, 0, leg.quantity*leg.multiplier*strategy.multiplier, TimeStamp(current_date, trading_timestamp), index_price, "Entry")
                            orders.append(order)
                            leg.orders.append(order)
                            broker_order_id = place_order(broker, client_id, order, None)
                            strategy.entry_combined_premium += order.average_price
                            order.broker_order_id = broker_order_id
                            
                            leg.is_waiting_for_stop_loss_reentry = False
                            leg.is_waiting_for_take_profit_reentry = False
                            leg.status = LEGSTATUS.ENTERED
                            strategy.status = STRATEGYSTATUS.RUNNING
                            
        if strategy.status == STRATEGYSTATUS.RUNNING:
            strategy_profit = 0
            strategy_loss = 0
            is_stop_loss_check_time_update = False
            is_take_profit_check_time_update = False
            
            for leg in strategy.legs:
                index_based_sl = False
                index_based_tp = False
                strategy_profit += leg.realized_pnl
                strategy_loss += leg.realized_pnl
                hedge_open_pnl = 0
                hedge_close_pnl = 0
                hedge_high_pnl = 0
                hedge_low_pnl = 0
                if leg.status == LEGSTATUS.ENTERED:
                    last_order = leg.orders[-1]
                    if last_order.status == ORDERSTATUS.COMPLETE:
                        if leg.hedge:
                            if leg.hedge.entry_order:
                                hedge_ohlc = get_quote(
                                    feed_source,
                                    leg.hedge.entry_order.contract.symbol,
                                    current_date,
                                    strategy.entry_time,
                                    trading_timestamp,
                                    leg.hedge.entry_order.contract.expiry_date,
                                    leg.hedge.entry_order.contract.strike_price,
                                    leg.hedge.entry_order.contract.option_type,
                                    is_hedge=True
                                )
                                if hedge_ohlc:
                                    hedge_open_pnl = calculate_current_pnl(
                                        hedge_ohlc.open/100.0,
                                        leg.hedge.entry_order.average_price,
                                        leg.hedge.entry_order.side,
                                        NUMBERTYPE.POINT,
                                    )
                                    
                                    hedge_close_pnl = calculate_current_pnl(
                                        hedge_ohlc.close/100.0,
                                        leg.hedge.entry_order.average_price,
                                        leg.hedge.entry_order.side,
                                        NUMBERTYPE.POINT,
                                    )
                                    
                                    hedge_high_pnl = calculate_current_pnl(
                                        hedge_ohlc.high/100.0,
                                        leg.hedge.entry_order.average_price,
                                        leg.hedge.entry_order.side,
                                        NUMBERTYPE.POINT,
                                    )
                                    
                                    hedge_low_pnl = calculate_current_pnl(
                                        hedge_ohlc.low/100.0,
                                        leg.hedge.entry_order.average_price,
                                        leg.hedge.entry_order.side,
                                        NUMBERTYPE.POINT,
                                    )
                        if not leg.current_stop_loss or not leg.current_take_profit:
                            if leg.stop_loss.type != NUMBERTYPE.ABSOLUTE_DELTA:
                                leg.current_stop_loss = calculate_stop_loss_points(index_price, last_order.average_price, leg.stop_loss)
                            if leg.take_profit.type != NUMBERTYPE.ABSOLUTE_DELTA:
                                leg.current_take_profit = calculate_take_profit_points(index_price, last_order.average_price, leg.take_profit)
                            leg.current_trailing_stop_loss = calculate_trailing_stop_loss_points(index_price, last_order.average_price, leg.trailing_stop_loss)    
                        
                        minute_ohlc = get_quote(
                                    feed_source,
                                    last_order.contract.symbol,
                                    current_date,
                                    trading_timestamp,
                                    trading_timestamp,
                                    last_order.contract.expiry_date,
                                    last_order.contract.strike_price,
                                    last_order.contract.option_type,
                                )
                        profit_ohlc = get_quote(
                                    feed_source,
                                    last_order.contract.symbol,
                                    current_date,
                                    strategy.last_take_profit_check_time+Config.BT_FREQUENCY,
                                    trading_timestamp,
                                    last_order.contract.expiry_date,
                                    last_order.contract.strike_price,
                                    last_order.contract.option_type,
                                )
                        loss_ohlc = get_quote(
                                    feed_source,
                                    last_order.contract.symbol,
                                    current_date,
                                    strategy.last_stop_loss_check_time+Config.BT_FREQUENCY,
                                    trading_timestamp,
                                    last_order.contract.expiry_date,
                                    last_order.contract.strike_price,
                                    last_order.contract.option_type,
                                )
                        if strategy.underlying == UNDERLYINGTYPE.FUTURE:
                            profit_index_ohlc = get_quote(feed_source, strategy.index, current_date,strategy.last_take_profit_check_time,
                                    trading_timestamp, option_type=OPTIONTYPE.FUT, expiry=monthly_expiry)
                            loss_index_ohlc = get_quote(feed_source, strategy.index, current_date,strategy.last_stop_loss_check_time,
                                    trading_timestamp, option_type=OPTIONTYPE.FUT, expiry=monthly_expiry)
                        elif strategy.underlying == UNDERLYINGTYPE.CASH:
                            profit_index_ohlc = get_quote(feed_source, strategy.index, current_date, strategy.last_take_profit_check_time,
                                    trading_timestamp,)
                            loss_index_ohlc = get_quote(feed_source, strategy.index, current_date, strategy.last_stop_loss_check_time,
                                    trading_timestamp,)

                        if not minute_ohlc or not profit_ohlc or not loss_ohlc:
                            continue
                        
                        pnl_dict = get_pnl_dict(minute_ohlc, profit_index_ohlc, loss_index_ohlc, profit_ohlc, loss_ohlc, last_order, leg, "Vwap")
                        
                        if strategy.exit_price_config.take_profit_based_on == "OPEN":
                            if leg.take_profit.type in [NUMBERTYPE.INDEX_POINTS, NUMBERTYPE.INDEX_PERCENTAGE]:
                                tp_order_price = profit_ohlc.close/100.0
                                current_profit = pnl_dict["index_open_profit"]
                                index_based_tp = True
                            else:
                                tp_order_price = profit_ohlc.open/100.0
                                current_profit = pnl_dict["open_profit"]
                        elif strategy.exit_price_config.take_profit_based_on == "CLOSE":
                            if leg.take_profit.type in [NUMBERTYPE.INDEX_POINTS, NUMBERTYPE.INDEX_PERCENTAGE]:
                                tp_order_price = profit_ohlc.close/100.0
                                current_profit = pnl_dict["index_close_profit"] 
                                index_based_tp = True
                            else:
                                tp_order_price = profit_ohlc.close/100.0
                                current_profit = pnl_dict["close_profit"]
                        elif strategy.exit_price_config.take_profit_based_on not in ["OPEN", "CLOSE"]:
                            if leg.take_profit.type in [NUMBERTYPE.INDEX_POINTS, NUMBERTYPE.INDEX_PERCENTAGE]:
                                if last_order.side == SIDE.BUY:
                                    tp_order_price = profit_ohlc.high/100.0
                                    current_profit = pnl_dict["index_high_profit"]
                                    index_based_tp = True
                                else:
                                    tp_order_price = profit_ohlc.low/100.0
                                    current_profit = pnl_dict["index_low_profit"]
                                    index_based_tp = True
                            else:
                                if last_order.side == SIDE.BUY:
                                    tp_order_price = profit_ohlc.high/100.0
                                    current_profit = pnl_dict["high_profit"]
                                else:
                                    tp_order_price = profit_ohlc.low/100.0
                                    current_profit = pnl_dict["low_profit"]
                                
                        if strategy.exit_price_config.stop_loss_based_on == "OPEN":
                            if leg.stop_loss.type in [NUMBERTYPE.INDEX_POINTS, NUMBERTYPE.INDEX_PERCENTAGE]:
                                sl_order_price = loss_ohlc.close/100.0
                                current_stop_loss = pnl_dict["index_open_loss"]
                                index_based_sl = True
                            else:
                                sl_order_price = loss_ohlc.open/100.0
                                current_stop_loss = pnl_dict["open_loss"]
                        elif strategy.exit_price_config.stop_loss_based_on == "CLOSE":
                            if leg.stop_loss.type in [NUMBERTYPE.INDEX_POINTS, NUMBERTYPE.INDEX_PERCENTAGE]:
                                sl_order_price = loss_ohlc.close/100.0
                                current_stop_loss = pnl_dict["index_close_loss"]
                                index_based_sl = True
                            else:
                                sl_order_price = loss_ohlc.close/100.0
                                current_stop_loss = pnl_dict["close_loss"]
                        elif strategy.exit_price_config.stop_loss_based_on not in ["OPEN", "CLOSE"]:
                            if leg.stop_loss.type in [NUMBERTYPE.INDEX_POINTS, NUMBERTYPE.INDEX_PERCENTAGE]:
                                if last_order.side == SIDE.BUY:
                                    sl_order_price = loss_ohlc.high/100.0
                                    current_stop_loss = pnl_dict["index_high_loss"]
                                    index_based_sl = True
                                else:
                                    sl_order_price = loss_ohlc.close/100.0
                                    current_stop_loss = pnl_dict["index_high_loss"]
                                    index_based_sl = True
                            else:
                                if last_order.side == SIDE.BUY:
                                    sl_order_price = loss_ohlc.low/100.0
                                    current_stop_loss = pnl_dict["low_loss"]
                                else:
                                    sl_order_price = loss_ohlc.high/100.0
                                    current_stop_loss = pnl_dict["high_loss"]
                        
                        
                        if pnl_dict["high_loss"] < 0 and abs(pnl_dict["high_loss"]) > last_order.max_loss:
                            last_order.max_loss = abs(pnl_dict["high_loss"])
                        elif pnl_dict["high_profit"] > 0 and pnl_dict["high_profit"] > last_order.max_profit:
                            last_order.max_profit = abs(pnl_dict["high_profit"])
                            
                        if pnl_dict["low_loss"] < 0 and abs(pnl_dict["low_loss"]) > last_order.max_loss:
                            last_order.max_loss = abs(pnl_dict["low_loss"])
                        elif pnl_dict["low_profit"] > 0 and pnl_dict["low_profit"] > last_order.max_profit:
                            last_order.max_profit = abs(pnl_dict["low_profit"])
                        
                        sl_hit, delta_based_sl, is_stop_loss_check_time_update = is_sl_hit(strategy, leg, current_date, trading_timestamp, atm, current_stop_loss, last_order, feed_source)
                        
                        tp_hit, delta_based_tp, is_take_profit_check_time_update = is_tp_hit(strategy, leg, current_date, trading_timestamp, atm, current_profit, last_order, feed_source)
                        
                        if sl_hit:
                            if leg.hedge:
                                if leg.hedge.entry_order:
                                    if leg.hedge.entry_order.status == ORDERSTATUS.COMPLETE:
                                        place_hedge_exit_order(strategy, leg, product_type, order_type, current_date, trading_timestamp, index_price, broker, client_id, "Stop Loss Hedge Exit", orders)
                                    else:
                                        leg.status = LEGSTATUS.WAITING_FOR_STOP_LOSS_EXIT
                            else:
                                leg.status = LEGSTATUS.WAITING_FOR_STOP_LOSS_EXIT
                            strategy.is_any_leg_exited = True
                            strategy.is_any_leg_sl_hit = True
                            
                        elif tp_hit:
                            if leg.hedge:
                                if leg.hedge.entry_order:
                                    if leg.hedge.entry_order.status == ORDERSTATUS.COMPLETE:
                                        place_hedge_exit_order(strategy, leg, product_type, order_type, current_date, trading_timestamp, index_price, broker, client_id, "Take Profit Hedge Exit", orders)
                                    else:
                                        leg.status = LEGSTATUS.WAITING_FOR_TAKE_PROFIT_EXIT
                            else:
                                leg.status = LEGSTATUS.WAITING_FOR_TAKE_PROFIT_EXIT
                            strategy.is_any_leg_exited = True

                        if is_time_for_exit(timestamp, exit_time) or (current_date == leg.contract.expiry_date and is_time_for_exit(trading_timestamp, strategy.tv_expiry_day_exit_time)):
                            if leg.hedge:
                                if leg.hedge.entry_order:
                                    if leg.hedge.entry_order.status == ORDERSTATUS.COMPLETE:
                                        hedge_exit_order = Order(strategy.entry_number, strategy.name, leg.hedge.id, leg.entry_number, leg.stop_loss_entry_number, leg.take_profit_entry_number, leg.hedge.contract, product_type, order_type, reverse_side(leg.hedge.side), 0, 0, leg.quantity*leg.multiplier*strategy.multiplier, TimeStamp(current_date, trading_timestamp), index_price, "Time Hedge Exit")
                                        broker_order_id = place_order(broker, client_id, hedge_exit_order)
                                        hedge_exit_order.broker_order_id = broker_order_id
                                        orders.append(hedge_exit_order)
                                        leg.hedge.exit_order = hedge_exit_order
                                        leg.status = LEGSTATUS.WAITING_FOR_HEDGE_EXIT
                                    else:
                                        leg.status = LEGSTATUS.WIATING_FOR_TIME_EXIT
                            else:
                                leg.status = LEGSTATUS.WIATING_FOR_TIME_EXIT
                            strategy.is_any_leg_exited = True
                        else:

                            if strategy.pnl_calculation_from == "OPEN":
                                strategy_profit += pnl_dict["minute_open_profit"]*last_order.quantity
                                strategy_loss += pnl_dict["minute_open_loss"]*last_order.quantity
                                if leg.hedge_pnl_effect and hedge_open_pnl:
                                    strategy_profit += hedge_open_pnl*leg.hedge.entry_order.quantity
                                    strategy_loss += hedge_open_pnl*leg.hedge.entry_order.quantity

                            elif strategy.pnl_calculation_from == "CLOSE":
                                strategy_profit += pnl_dict["minute_close_profit"]*last_order.quantity
                                strategy_loss +=  pnl_dict["minute_close_loss"]*last_order.quantity
                                if leg.hedge_pnl_effect and hedge_close_pnl:
                                    strategy_profit += hedge_close_pnl*leg.hedge.entry_order.quantity
                                    strategy_loss += hedge_close_pnl*leg.hedge.entry_order.quantity

                            elif strategy.pnl_calculation_from == "HIGH":
                                strategy_profit += pnl_dict["minute_high_profit"]*last_order.quantity
                                strategy_loss += pnl_dict["minute_high_loss"]*last_order.quantity
                                if leg.hedge_pnl_effect and hedge_high_pnl:
                                    strategy_profit += hedge_high_pnl*leg.hedge.entry_order.quantity
                                    strategy_loss += hedge_high_pnl*leg.hedge.entry_order.quantity

                            elif strategy.pnl_calculation_from == "LOW":
                                strategy_profit += pnl_dict["minute_low_profit"]*last_order.quantity
                                strategy_loss += pnl_dict["minute_low_loss"]*last_order.quantity
                                if leg.hedge_pnl_effect and hedge_low_pnl:
                                    strategy_profit += hedge_low_pnl*leg.hedge.entry_order.quantity
                                    strategy_loss += hedge_low_pnl*leg.hedge.entry_order.quantity

                            elif strategy.pnl_calculation_from not in ["OPEN", "CLOSE", "HIGH", "LOW"]:
                                if last_order.side == SIDE.BUY:
                                    strategy_profit += pnl_dict["minute_high_profit"]*last_order.quantity
                                    strategy_loss += pnl_dict["minute_low_loss"]*last_order.quantity
                                else:
                                    strategy_profit += pnl_dict["minute_low_profit"]*last_order.quantity
                                    strategy_loss += pnl_dict["minute_high_loss"]*last_order.quantity
                                
                                if leg.hedge_pnl_effect and hedge_low_pnl:
                                    if leg.hedge.entry_order.side == SIDE.BUY:
                                        strategy_profit += hedge_high_pnl*leg.hedge.entry_order.quantity
                                        strategy_loss += hedge_low_pnl*leg.hedge.entry_order.quantity
                                    else:
                                        strategy_profit += hedge_low_pnl*leg.hedge.entry_order.quantity
                                        strategy_loss += hedge_high_pnl*leg.hedge.entry_order.quantity
                if leg.status == LEGSTATUS.WAITING_FOR_HEDGE_EXIT:
                    if leg.hedge.exit_order.status == ORDERSTATUS.COMPLETE:
                        if leg.hedge_pnl_effect:
                            hedge_pnl = calculate_current_pnl(leg.hedge.exit_order.average_price, leg.hedge.entry_order.average_price, leg.hedge.side, NUMBERTYPE.POINT)*leg.quantity*leg.multiplier*strategy.multiplier

                            if leg.hedge.side == SIDE.BUY:
                                strategy_profit += hedge_pnl
                                strategy_loss += hedge_pnl          
                                leg.realized_pnl += hedge_pnl   
                                strategy.realized_pnl += hedge_pnl               
                            else:
                                strategy_profit += -hedge_pnl
                                strategy_loss += -hedge_pnl
                                leg.realized_pnl += hedge_pnl
                                strategy.realized_pnl += -hedge_pnl
                            
                        if leg.hedge.exit_order.reason == "Stop Loss Hedge Exit":
                            leg.status = LEGSTATUS.WAITING_FOR_STOP_LOSS_EXIT
                        elif leg.hedge.exit_order.reason == "Take Profit Hedge Exit":
                            leg.status = LEGSTATUS.WAITING_FOR_TAKE_PROFIT_EXIT
                        else:
                            leg.status = LEGSTATUS.WIATING_FOR_TIME_EXIT
                if leg.status == LEGSTATUS.WAITING_FOR_TAKE_PROFIT_EXIT:
                    if index_based_tp:
                        reason = "Index Based Take Profit Hit"
                    else:
                        reason = "Take Profit Hit"
                    order = Order(strategy.entry_number, strategy.name, leg.id, leg.entry_number, leg.stop_loss_entry_number, leg.take_profit_entry_number, last_order.contract, product_type, order_type, reverse_side(leg.side), 0, 0, last_order.quantity, TimeStamp(current_date, trading_timestamp), index_price, reason)
                    leg.entry_number += 1
                    leg.take_profit_entry_number += 1
                    if strategy.exit_price_config.trade_file_exit_price_on_take_profit != "TICK" and not index_based_tp and not delta_based_tp:
                        if last_order.side == SIDE.BUY:
                            tp_order_price = last_order.average_price + leg.current_take_profit
                        else:
                            tp_order_price = last_order.average_price - leg.current_take_profit
                    broker_order_id = place_order(broker, client_id, order, tp_order_price)
                    order.broker_order_id = broker_order_id
                    orders.append(order)
                    leg.orders.append(order)
                    leg.status = LEGSTATUS.WAITING_FOR_TAKE_PROFIT_FILL
                if leg.status == LEGSTATUS.WAITING_FOR_STOP_LOSS_EXIT:
                    if index_based_sl:
                        exit_reason = "Index Based Stop Loss Hit"
                        if leg.is_stop_loss_trailed:
                            exit_reason = "Index Based Trailing Stop Loss Hit"
                    else:
                        exit_reason = "Stop Loss Hit"
                        if leg.is_stop_loss_trailed:
                            exit_reason = "Trailing Stop Loss Hit"
                    order = Order(strategy.entry_number, strategy.name, leg.id, leg.entry_number, leg.stop_loss_entry_number, leg.take_profit_entry_number, last_order.contract, product_type, order_type, reverse_side(leg.side), 0, 0, last_order.quantity, TimeStamp(current_date, trading_timestamp), index_price, exit_reason)
                    leg.entry_number += 1
                    leg.stop_loss_entry_number += 1
                    if strategy.exit_price_config.trade_file_exit_price_on_stop_loss != "TICK" and not index_based_sl and not delta_based_sl:
                        if last_order.side == SIDE.BUY:
                            sl_order_price = last_order.average_price - leg.current_stop_loss
                        else:
                            sl_order_price = last_order.average_price + leg.current_stop_loss
                    
                    broker_order_id = place_order(broker, client_id, order, sl_order_price)
                    order.broker_order_id = broker_order_id
                    orders.append(order)
                    leg.orders.append(order)
                    leg.status = LEGSTATUS.WAITING_FOR_STOP_LOSS_FILL
                if leg.status == LEGSTATUS.WAITING_FOR_STOP_LOSS_FILL:
                    exit_order = leg.orders[-1]
                    if exit_order.status == ORDERSTATUS.COMPLETE:
                        entry_order = leg.orders[-2]
                        booked_pnl = calculate_current_pnl(exit_order.average_price,entry_order.average_price,entry_order.side,leg.take_profit.type)*entry_order.quantity
                        leg.contract.ltp = exit_order.average_price
                        leg.realized_pnl += booked_pnl
                        strategy_profit += booked_pnl
                        strategy_loss += booked_pnl
                        strategy.realized_pnl += booked_pnl
                        leg.current_stop_loss = None
                        leg.current_take_profit = None
                        leg.status = LEGSTATUS.EXITED
                        strategy.status = STRATEGYSTATUS.INDICATOR_HIT
                        if strategy.indicator_based_reentry_remaining > 0:
                            strategy.entry_number += 1
                            strategy.indicator_based_reentry_remaining -= 1
                            strategy.indicator_based_entry = False
                        else:
                            strategy.status = STRATEGYSTATUS.COMPLETED
                if leg.status == LEGSTATUS.WAITING_FOR_TAKE_PROFIT_FILL:
                    exit_order = leg.orders[-1]
                    if exit_order.status == ORDERSTATUS.COMPLETE:
                        entry_order = leg.orders[-2]
                        booked_pnl = calculate_current_pnl(exit_order.average_price,entry_order.average_price,entry_order.side,leg.take_profit.type)*entry_order.quantity
                        leg.contract.ltp = exit_order.average_price
                        leg.realized_pnl += booked_pnl
                        strategy_profit += booked_pnl
                        strategy_loss += booked_pnl
                        strategy.realized_pnl += booked_pnl
                        leg.current_stop_loss = None
                        leg.current_take_profit = None
                        leg.status = LEGSTATUS.EXITED
                        strategy.status = STRATEGYSTATUS.INDICATOR_HIT
                        if strategy.indicator_based_reentry_remaining > 0:
                            strategy.entry_number += 1
                            strategy.indicator_based_reentry_remaining -= 1
                            strategy.indicator_based_entry = False
                        else:
                            strategy.status = STRATEGYSTATUS.COMPLETED
                if leg.status == LEGSTATUS.WIATING_FOR_TIME_EXIT:
                    booked_pnl = pnl_dict["open_loss"]*last_order.quantity
                    order = Order(strategy.entry_number, strategy.name, leg.id, leg.entry_number, leg.stop_loss_entry_number, leg.take_profit_entry_number, last_order.contract, product_type, order_type, reverse_side(leg.side), 0, 0, last_order.quantity, TimeStamp(current_date, trading_timestamp), index_price, "Exit Time Hit")
                    broker_order_id = place_order(broker, client_id, order)
                    leg.realized_pnl += booked_pnl
                    strategy_profit += booked_pnl
                    strategy_loss += booked_pnl
                    strategy.realized_pnl += booked_pnl
                    orders.append(order)
                    leg.orders.append(order)
                    order.broker_order_id = broker_order_id
                    leg.status = LEGSTATUS.WAITING_FOR_TIME_EXIT_FILL
                if leg.status == LEGSTATUS.WAITING_FOR_TIME_EXIT_FILL:
                    exit_order = leg.orders[-1]
                    if exit_order.status == ORDERSTATUS.COMPLETE:
                        leg.status = LEGSTATUS.EXITED
                        
            if is_stop_loss_check_time_update:
                strategy.last_stop_loss_check_time = trading_timestamp
            if is_take_profit_check_time_update:
                strategy.last_take_profit_check_time = trading_timestamp

            if strategy.lock_and_trail.lock:
                if not strategy.can_trail and is_lock_is_triggered(strategy_profit, strategy.lock_and_trail.lock):
                    strategy.is_lock_is_triggerd = True
                    strategy.current_stop_loss = strategy.lock_and_trail.trail
                    strategy.can_trail = True
            else:
                if not strategy.can_trail:
                    strategy.can_trail = True
            
            if strategy.can_trail:
                trail_stg_sl(strategy, strategy_profit)
                
             
            if is_stg_stop_loss_hit(strategy_loss, strategy.current_stop_loss):
                strategy.status = STRATEGYSTATUS.SL_HIT
                for leg in strategy.legs:
                    if leg.status == LEGSTATUS.ENTERED:
                        if leg.hedge:
                            if leg.hedge.entry_order:
                                if leg.hedge.entry_order.status == ORDERSTATUS.COMPLETE:
                                    if strategy.pnl_calculation_from == "OPEN":
                                        exit_price = hedge_ohlc.open/100.0
                                    elif strategy.pnl_calculation_from == "CLOSE":
                                        exit_price = hedge_ohlc.close/100.0
                                    else:
                                        exit_price = hedge_ohlc.low/100.0 if leg.hedge.side == SIDE.BUY else hedge_ohlc.high/100.0
                                    exit_reason = "Stg Stop Loss Hedge Exit"
                                    if strategy.is_lock_is_triggerd:
                                        if strategy.is_stop_loss_trailed:
                                            exit_reason = "Stg Stop Loss Trailing Hit"
                                        else:
                                            exit_reason = "Stg Minimum Profit Lock Hit"
                                    else:
                                        if strategy.is_stop_loss_trailed:
                                            exit_reason = "Stg Stop Loss Trailing Hit"
                                    hedge_exit_order = Order(strategy.entry_number, strategy.name, leg.hedge.id, leg.entry_number, leg.stop_loss_entry_number, leg.take_profit_entry_number, leg.hedge.contract, product_type, order_type, reverse_side(leg.hedge.side), 0, 0, leg.quantity*leg.multiplier*strategy.multiplier, TimeStamp(current_date, trading_timestamp), index_price, exit_reason)
                                    broker_order_id = place_order(broker, client_id, hedge_exit_order, exit_price)
                                    hedge_exit_order.broker_order_id = broker_order_id
                                    orders.append(hedge_exit_order)
                                    leg.hedge.exit_order = hedge_exit_order
                                    leg.status = LEGSTATUS.WAITING_FOR_HEDGE_EXIT
                                else:
                                    leg.status = LEGSTATUS.WAITING_FOR_STG_STOP_LOSS_EXIT
                        else:
                            leg.status = LEGSTATUS.WAITING_FOR_STG_STOP_LOSS_EXIT
                    
                    elif leg.status in [LEGSTATUS.CREATED, LEGSTATUS.CONTRACTRIZED]:
                        leg.status = LEGSTATUS.EXITED
                if strategy.stop_loss_reentry_remaining > 0:
                    strategy.entry_number += 1
                    strategy.stop_loss_reentry_remaining -= 1
                else:
                    strategy.is_first_entry = True
                    strategy.status = STRATEGYSTATUS.COMPLETED
                    
            if is_stg_profit_hit(strategy_profit, strategy.take_profit.value):
                strategy.status = STRATEGYSTATUS.TP_HIT
                for leg in strategy.legs:
                    if leg.status == LEGSTATUS.ENTERED:
                        if leg.hedge:
                            if leg.hedge.entry_order:
                                if leg.hedge.entry_order.status == ORDERSTATUS.COMPLETE:
                                    if strategy.pnl_calculation_from == "OPEN":
                                        exit_price = hedge_ohlc.open/100.0
                                    elif strategy.pnl_calculation_from == "CLOSE":
                                        exit_price = hedge_ohlc.close/100.0
                                    else:
                                        exit_price = hedge_ohlc.low/100.0 if leg.hedge.side == SIDE.BUY else hedge_ohlc.high/100.0
                                    hedge_exit_order = Order(strategy.entry_number, strategy.name, leg.hedge.id, leg.entry_number, leg.stop_loss_entry_number, leg.take_profit_entry_number, leg.hedge.contract, product_type, order_type, reverse_side(leg.hedge.side), 0, 0, leg.quantity*leg.multiplier*strategy.multiplier, TimeStamp(current_date, trading_timestamp), index_price, "Stg Take Profit Hedge Exit")
                                    broker_order_id = place_order(broker, client_id, hedge_exit_order,exit_price)
                                    hedge_exit_order.broker_order_id = broker_order_id
                                    orders.append(hedge_exit_order)
                                    leg.hedge.exit_order = hedge_exit_order
                                    leg.status = LEGSTATUS.WAITING_FOR_HEDGE_EXIT
                                else:
                                    leg.status = LEGSTATUS.WAITING_FOR_STG_TAKE_PROFIT_EXIT
                        else:
                            leg.status = LEGSTATUS.WAITING_FOR_STG_TAKE_PROFIT_EXIT
                    elif leg.status in [LEGSTATUS.CREATED, LEGSTATUS.CONTRACTRIZED]:
                        leg.status = LEGSTATUS.EXITED
                if strategy.take_profit_reentry_remaining > 0:
                    strategy.entry_number += 1
                    strategy.take_profit_reentry_remaining -= 1
                else:
                    strategy.status = STRATEGYSTATUS.COMPLETED
                        
            if can_make_full_candle and strategy.indicator_based_entry:
                if strategy.indicator_candle_based_on == "underlying":
                    normal_candles = get_candles(strategy.index, int(strategy.max_length*3), strategy.checking_interval, current_date, previous_date, trading_timestamp,0, 0, is_live)
                else:
                    normal_candles = get_combined_candle(strategy.index, strategy.legs, strategy.max_length, strategy.checking_interval, current_date, previous_date, trading_timestamp, is_live)
                heikin_ashi_candles = get_heikin_ashi(normal_candles)
                
                if (heikin_ashi_candles is not None) and len(heikin_ashi_candles) != 0:
                    if eval_indicators(strategy.exit_indicators, heikin_ashi_candles):
                        can_exit = True
                        if strategy.signal_candle_high == MIN_INT:
                            strategy.signal_candle_high = heikin_ashi_candles[-1].high
                    else:
                        can_exit = False
                        strategy.signal_candle_high = MIN_INT
                else:
                    can_exit = False

                if can_exit and heikin_ashi_candles[-1].close > strategy.signal_candle_high:
                    strategy.status = STRATEGYSTATUS.INDICATOR_HIT
                    for leg in strategy.legs:
                        if leg.status == LEGSTATUS.ENTERED:
                            if leg.hedge:
                                if leg.hedge.entry_order:
                                    if leg.hedge.entry_order.status == ORDERSTATUS.COMPLETE:
                                        if strategy.pnl_calculation_from == "OPEN":
                                            exit_price = hedge_ohlc.open/100.0
                                        elif strategy.pnl_calculation_from == "CLOSE":
                                            exit_price = hedge_ohlc.close/100.0
                                        else:
                                            exit_price = hedge_ohlc.low/100.0 if leg.hedge.side == SIDE.BUY else hedge_ohlc.high/100.0
                                        hedge_exit_order = Order(strategy.entry_number, strategy.name, leg.hedge.id, leg.entry_number, leg.stop_loss_entry_number, leg.take_profit_entry_number, leg.hedge.contract, product_type, order_type, reverse_side(leg.hedge.side), 0, 0, leg.quantity*leg.multiplier*strategy.multiplier, TimeStamp(current_date, trading_timestamp), index_price, "Indicator Based Exit")
                                        broker_order_id = place_order(broker, client_id, hedge_exit_order,exit_price)
                                        hedge_exit_order.broker_order_id = broker_order_id
                                        orders.append(hedge_exit_order)
                                        leg.hedge.exit_order = hedge_exit_order
                                        leg.status = LEGSTATUS.WAITING_FOR_HEDGE_EXIT
                                    else:
                                        leg.status = LEGSTATUS.WAITING_FOR_INDICATOR_EXIT
                            else:
                                leg.status = LEGSTATUS.WAITING_FOR_INDICATOR_EXIT
                        elif leg.status in [LEGSTATUS.CREATED, LEGSTATUS.CONTRACTRIZED]:
                            leg.status = LEGSTATUS.EXITED
                    if strategy.indicator_based_reentry_remaining > 0:
                        strategy.entry_number += 1
                        strategy.indicator_based_reentry_remaining -= 1
                        strategy.indicator_based_entry = False
                    else:
                        strategy.status = STRATEGYSTATUS.COMPLETED
                    

            is_all_legs_exited = True
            for leg in strategy.legs:
                if leg.status == LEGSTATUS.WAITING_FOR_HEDGE_EXIT:
                    if leg.hedge.exit_order.status == ORDERSTATUS.COMPLETE:
                        if leg.hedge_pnl_effect:
                            hedge_pnl = calculate_current_pnl(leg.hedge.exit_order.average_price, leg.hedge.entry_order.average_price, leg.hedge.side, NUMBERTYPE.POINT)*leg.quantity*leg.multiplier*strategy.multiplier
                            if leg.hedge.side == SIDE.BUY:
                                leg.realized_pnl += hedge_pnl
                                strategy.realized_pnl += hedge_pnl
                            else:
                                leg.realized_pnl += -hedge_pnl
                                strategy.realized_pnl += -hedge_pnl
                        if leg.hedge.exit_order.reason in ["Stg Stop Loss Hedge Exit", "Stg Stop Loss Trailing Hit", "Stg Minimum Profit Lock Hit"]:
                            leg.status = LEGSTATUS.WAITING_FOR_STG_STOP_LOSS_EXIT
                        elif leg.hedge.exit_order.reason == "Stg Take Profit Hedge Exit":
                            leg.status = LEGSTATUS.WAITING_FOR_STG_TAKE_PROFIT_EXIT
                        elif leg.hedge.exit_order.reason == "Stg Square Off All Legs Hedge Exit":
                            leg.status = LEGSTATUS.WAITING_FOR_SQUAREOFF_EXIT
                        elif leg.hedge.exit_order.reason == "Stg RSI Hedge Exit":
                            leg.status = LEGSTATUS.WAITING_FOR_STG_RSI_EXIT
                        elif leg.hedge.exit_order.reason == "Indicator Based Exit":
                            leg.status = LEGSTATUS.WAITING_FOR_INDICATOR_EXIT
                    
                if leg.status == LEGSTATUS.WAITING_FOR_STG_STOP_LOSS_EXIT:
                    last_order = leg.orders[-1]
                    ohlc = get_quote(
                        feed_source,
                        last_order.contract.symbol,
                        current_date,
                        strategy.entry_time,
                        trading_timestamp,
                        last_order.contract.expiry_date,
                        last_order.contract.strike_price,
                        last_order.contract.option_type,
                    )
                    if ohlc is None:
                        continue
                    if strategy.pnl_calculation_from == "OPEN":
                        exit_price = ohlc.open/100.0
                    elif strategy.pnl_calculation_from == "CLOSE":
                        exit_price = ohlc.close/100.0
                    else:
                        exit_price = ohlc.low/100.0 if last_order.side == SIDE.BUY else ohlc.high/100.0

                    exit_reason = "Overall Stop Loss Hit"
                    if strategy.is_lock_is_triggerd:
                        if strategy.is_stop_loss_trailed:
                            exit_reason = "Stg Stop Loss Trailing Hit"
                        else:
                            exit_reason = "Stg Minimum Profit Lock Hit"
                    else:
                        if strategy.is_stop_loss_trailed:
                            exit_reason = "Stg Stop Loss Trailing Hit"
                    order = Order(strategy.entry_number, strategy.name, leg.id, leg.entry_number, leg.stop_loss_entry_number, leg.take_profit_entry_number, last_order.contract, product_type, order_type, reverse_side(leg.side), 0, 0, last_order.quantity, TimeStamp(current_date, trading_timestamp), index_price, exit_reason)
                    broker_order_id = place_order(broker, client_id, order, exit_price)
                    order.broker_order_id = broker_order_id
                    orders.append(order)
                    leg.orders.append(order)
                    leg.status = LEGSTATUS.WAITING_FOR_STG_STOP_LOSS_FILL
            
                if leg.status == LEGSTATUS.WAITING_FOR_STG_TAKE_PROFIT_EXIT:
                    last_order = leg.orders[-1]
                    ohlc = get_quote(
                        feed_source,
                        last_order.contract.symbol,
                        current_date,
                        strategy.entry_time,
                        trading_timestamp,
                        last_order.contract.expiry_date,
                        last_order.contract.strike_price,
                        last_order.contract.option_type,
                    )
                    if ohlc is None:
                        continue
                    if strategy.pnl_calculation_from == "OPEN":
                        exit_price = ohlc.open/100.0
                    elif strategy.pnl_calculation_from == "CLOSE":
                        exit_price = ohlc.close/100.0
                    else:
                        exit_price = ohlc.low/100.0 if last_order.side == SIDE.SELL else ohlc.high/100.0
                    order = Order(strategy.entry_number, strategy.name, leg.id, leg.entry_number, leg.stop_loss_entry_number, leg.take_profit_entry_number, last_order.contract, product_type, order_type, reverse_side(leg.side), 0, 0, last_order.quantity, TimeStamp(current_date, trading_timestamp), index_price, "Overall Take Profit Hit")
                    broker_order_id = place_order(broker, client_id, order, exit_price)
                    order.broker_order_id = broker_order_id
                    orders.append(order)
                    leg.orders.append(order)
                    leg.status = LEGSTATUS.WAITING_FOR_STG_TAKE_PROFIT_FILL
                    
                if leg.status == LEGSTATUS.WAITING_FOR_INDICATOR_EXIT:
                    last_order = leg.orders[-1]
                    ohlc = get_quote(
                        feed_source,
                        last_order.contract.symbol,
                        current_date,
                        strategy.entry_time,
                        trading_timestamp,
                        last_order.contract.expiry_date,
                        last_order.contract.strike_price,
                        last_order.contract.option_type,
                    )
                    if ohlc is None:
                        continue
                    if strategy.pnl_calculation_from == "OPEN":
                        exit_price = ohlc.open/100.0
                    elif strategy.pnl_calculation_from == "CLOSE":
                        exit_price = ohlc.close/100.0
                    else:
                        exit_price = ohlc.low/100.0 if last_order.side == SIDE.SELL else ohlc.high/100.0
                    order = Order(strategy.entry_number, strategy.name, leg.id, leg.entry_number, leg.stop_loss_entry_number, leg.take_profit_entry_number, last_order.contract, product_type, order_type, reverse_side(leg.side), 0, 0, last_order.quantity, TimeStamp(current_date, trading_timestamp), index_price, "Indicator Hit")
                    broker_order_id = place_order(broker, client_id, order, exit_price)
                    order.broker_order_id = broker_order_id
                    orders.append(order)
                    leg.orders.append(order)
                    leg.status = LEGSTATUS.WAITING_FOR_INDICATOR_FILL
                
                if leg.status == LEGSTATUS.WAITING_FOR_STG_STOP_LOSS_FILL:
                    exit_order = leg.orders[-1]
                    if exit_order.status == ORDERSTATUS.COMPLETE:
                        entry_order = leg.orders[-2]
                        leg_pnl = calculate_current_pnl(exit_order.average_price, entry_order.average_price, entry_order.side, NUMBERTYPE.POINT)*entry_order.quantity
                        leg.realized_pnl += leg_pnl
                        strategy.realized_pnl += leg_pnl
                        leg.status = LEGSTATUS.EXITED
                    
                if leg.status == LEGSTATUS.WAITING_FOR_STG_TAKE_PROFIT_FILL:
                    exit_order = leg.orders[-1]
                    if exit_order.status == ORDERSTATUS.COMPLETE:
                        entry_order = leg.orders[-2]
                        leg_pnl = calculate_current_pnl(exit_order.average_price, entry_order.average_price, entry_order.side, NUMBERTYPE.POINT)*entry_order.quantity
                        leg.realized_pnl += leg_pnl
                        strategy.realized_pnl += leg_pnl
                        leg.status = LEGSTATUS.EXITED
                if leg.status == LEGSTATUS.WAITING_FOR_INDICATOR_FILL:
                    exit_order = leg.orders[-1]
                    if exit_order.status == ORDERSTATUS.COMPLETE:
                        entry_order = leg.orders[-2]
                        leg_pnl = calculate_current_pnl(exit_order.average_price, entry_order.average_price, entry_order.side, NUMBERTYPE.POINT)*entry_order.quantity
                        leg.realized_pnl += leg_pnl
                        strategy.realized_pnl += leg_pnl
                        leg.status = LEGSTATUS.EXITED
                if leg.status not in [LEGSTATUS.EXITED, LEGSTATUS.STOP_LOSS_REENTRY, LEGSTATUS.TAKE_PROFIT_REENTRY]:
                    is_all_legs_exited = False
                
            if is_all_legs_exited and  ((strategy.indicator_based_reentry_remaining > -1 and strategy.status == STRATEGYSTATUS.INDICATOR_HIT) or (strategy.stop_loss_reentry_remaining > -1 and strategy.status == STRATEGYSTATUS.SL_HIT) or (strategy.take_profit_reentry_remaining > -1 and strategy.status == STRATEGYSTATUS.TP_HIT)):
                vwap_strategy_reentry_reset(strategy)
                
            for leg in strategy.legs:
                if leg.status not in [ LEGSTATUS.CONTRACTRIZED, LEGSTATUS.CREATED, LEGSTATUS.EXITED, LEGSTATUS.STOP_LOSS_REENTRY, LEGSTATUS.TAKE_PROFIT_REENTRY]:
                    last_order = leg.orders[-1]
                    # if leg.hedge:
                        
                    if last_order.status == ORDERSTATUS.COMPLETE:
                        close_ohlc = get_quote(
                            feed_source,
                            leg.contract.symbol,
                            current_date,
                            strategy.entry_time,
                            trading_timestamp,
                            leg.contract.expiry_date,
                            leg.contract.strike_price,
                            leg.contract.option_type,
                            True
                        )
                        
                        if close_ohlc is None:
                            continue
                        pnl = calculate_current_pnl(
                                close_ohlc.close/100.0,
                                last_order.average_price,
                                last_order.side,
                                NUMBERTYPE.POINT,
                            )*last_order.quantity
                        tick_pnl += pnl
                    
    strategy.tick_profits[current_date] = strategy.tick_profits.get(current_date, {})
    strategy.tick_profits[current_date][trading_timestamp] =  tick_pnl+ strategy.realized_pnl
    strategy.tick_losses[current_date] = strategy.tick_losses.get(current_date, {})
    strategy.tick_losses[current_date][trading_timestamp] =  tick_pnl + strategy.realized_pnl