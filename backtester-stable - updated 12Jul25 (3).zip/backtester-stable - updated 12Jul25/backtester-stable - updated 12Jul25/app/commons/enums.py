class ENUMELEMENT:
    def __init__(self, value, name):
        self.value = value
        self.name = name

    def __eq__(self, other):
        return self.name == other.name

    def __repr__(self) -> str:
        return self.name

    def __str__(self) -> str:
        return self.name
    
    def __hash__(self) -> int:
        return hash(self.name)
    
class UNDERLYINGTYPE:
    CASH = ENUMELEMENT(1, "CASH")
    FUTURE = ENUMELEMENT(2, "FUTURE")
    
    @classmethod
    def choices(cls):
        return [cls.CASH.name, cls.FUTURE.name]


class STRIKESELECTIONTYPE:
    BY_CLOSEST_PREMIUM = ENUMELEMENT(1, "BY_PREMIUM")
    BY_ATM_STRIKE = ENUMELEMENT(2, "BY_ATM_STRIKE")
    BY_GE_PREMIUM = ENUMELEMENT(3, "BY_GE_PREMIUM")
    BY_LE_PREMIUM = ENUMELEMENT(4, "BY_LE_PREMIUM")
    BY_ATM_STRADDLE = ENUMELEMENT(5, "BY_ATM_STRADDLE")
    BY_DYNAMIC_FACTOR = ENUMELEMENT(6, "BY_DYNAMIC_FACTOR")
    BY_CLOSEST_DELTA = ENUMELEMENT(7, "BY_CLOSEST_DELTA")
    BY_GE_DELTA = ENUMELEMENT(8, "BY_GE_DELTA")
    BY_LE_DELTA = ENUMELEMENT(9, "BY_LE_DELTA")
    BY_MATCH_PREMIUM = ENUMELEMENT(10, "BY_MATCH_PREMIUM")
    BY_MIN_STRIKE_DIFF = ENUMELEMENT(11, "BY_MIN_STRIKE_DIFF")

    @classmethod
    def choices(cls):
        return [cls.BY_CLOSEST_PREMIUM.name, cls.BY_ATM_STRIKE.name, cls.BY_GE_PREMIUM.name, cls.BY_LE_PREMIUM.name, cls.BY_ATM_STRIKE.name, cls.BY_DYNAMIC_FACTOR.name, cls.BY_CLOSEST_DELTA.name, cls.BY_GE_DELTA.name, cls.BY_LE_DELTA.name, cls.BY_MATCH_PREMIUM.name]


class NUMBERTYPE:
    POINT = ENUMELEMENT(1, "POINT")
    PERCENTAGE = ENUMELEMENT(2, "PERCENTAGE")
    RUPEE = ENUMELEMENT(3, "RUPEE")
    INDEX_POINTS = ENUMELEMENT(4, "INDEX_POINTS")
    INDEX_PERCENTAGE = ENUMELEMENT(5, "INDEX_PERCENTAGE")
    ABSOLUTE_DELTA = ENUMELEMENT(6, "ABSOLUTE_DELTA")
    PREMIUM = ENUMELEMENT(6, "PREMIUM")

    @classmethod
    def choices(cls):
        return [cls.POINT.name, cls.PERCENTAGE.name, cls.RUPEE.name, cls.INDEX_POINTS.name, cls.INDEX_PERCENTAGE.name, cls.ABSOLUTE_DELTA.name, cls.PREMIUM.name]


class STRATEGYTYPE:
    INTRADAY = ENUMELEMENT(1, "INTRADAY")

    @classmethod
    def choices(cls):
        return [cls.INTRADAY.name]
    

class ORBBREAKOUTTYPE:
    LOWBREAKOUT = ENUMELEMENT(-1, "LOWBREAKOUT")
    HIGHBREAKOUT = ENUMELEMENT(1, "HIGHBREAKOUT")
    
    @classmethod
    def choices(cls):
        return [cls.LOWBREAKOUT.name, cls.HIGHBREAKOUT.name]


class NSEINDEX:
    BANKNIFTY = ENUMELEMENT(26000, "BANKNIFTY")
    NIFTY = ENUMELEMENT(26001, "NIFTY")
    FINNIFTY = ENUMELEMENT(26034, "FINNIFTY")
    MIDCPNIFTY = ENUMELEMENT(26002, "MIDCPNIFTY")
    SENSEX = ENUMELEMENT(26008, "SENSEX")
    BANKEX = ENUMELEMENT(26009, "BANKEX")
    COPPER = ENUMELEMENT(1, "COPPER")
    CRUDEOILM = ENUMELEMENT(1, "CRUDEOILM")
    CRUDEOIL = ENUMELEMENT(1, "CRUDEOIL")
    GOLDM = ENUMELEMENT(1, "GOLDM")
    GOLD = ENUMELEMENT(1, "GOLD")
    NATGASMINI = ENUMELEMENT(1, "NATGASMINI")
    NATURALGAS = ENUMELEMENT(1, "NATURALGAS")
    SILVERM = ENUMELEMENT(1, "SILVERM")
    SILVER = ENUMELEMENT(1, "SILVER")
    ZINC = ENUMELEMENT(1, "ZINC")
    QQQ = ENUMELEMENT(1, "QQQ")
    SPX = ENUMELEMENT(1, "SPX")
    SPY = ENUMELEMENT(1, "SPY")

    @classmethod
    def choices(cls):
        return [
            cls.BANKNIFTY.name, cls.NIFTY.name, cls.FINNIFTY.name, cls.MIDCPNIFTY.name, cls.SENSEX.name, cls.BANKEX.name, cls.COPPER.name, cls.CRUDEOILM.name,
            cls.CRUDEOIL.name, cls.GOLDM.name, cls.GOLD.name, cls.NATGASMINI.name, cls.NATURALGAS.name, cls.SILVERM.name, cls.SILVER.name, cls.ZINC.name,
            cls.QQQ.name, cls.SPX.name, cls.SPY.name
        ]
    
    @classmethod
    def values(cls):
        return [
            cls.BANKNIFTY.value, cls.NIFTY.value, cls.FINNIFTY.value, cls.MIDCPNIFTY.value, cls.SENSEX.value, cls.BANKEX.value, cls.COPPER.value, 
            cls.CRUDEOILM.value, cls.CRUDEOIL.value, cls.GOLDM.value, cls.GOLD.value, cls.NATGASMINI.value, cls.NATURALGAS.value, cls.SILVERM.value, 
            cls.SILVER.value, cls.ZINC.value, cls.QQQ.value, cls.SPX.value, cls.SPY.value
        ]
    
    @classmethod
    def get(cls, value):
        if value == cls.BANKNIFTY.value:
            return cls.BANKNIFTY.name
        elif value == cls.NIFTY.value:
            return cls.NIFTY.name
        elif value == cls.FINNIFTY.value:
            return cls.FINNIFTY.name
        elif value == cls.MIDCPNIFTY.value:
            return cls.MIDCPNIFTY.name
        elif value == cls.SENSEX.value:
            return cls.SENSEX.name
        elif value == cls.BANKEX.value:
            return cls.BANKEX.name
        elif value == cls.COPPER.value:
            return cls.COPPER.name
        elif value == cls.CRUDEOILM.value:
            return cls.CRUDEOILM.name
        elif value == cls.CRUDEOIL.value:
            return cls.CRUDEOIL.name
        elif value == cls.GOLDM.value:
            return cls.GOLDM.name
        elif value == cls.GOLD.value:
            return cls.GOLD.name
        elif value == cls.NATGASMINI.value:
            return cls.NATGASMINI.name
        elif value == cls.NATURALGAS.value:
            return cls.NATURALGAS.name
        elif value == cls.SILVERM.value:
            return cls.SILVERM.name
        elif value == cls.SILVER.value:
            return cls.SILVER.name
        elif value == cls.ZINC.value:
            return cls.ZINC.name
        elif value == cls.QQQ.value:
            return cls.QQQ.name
        elif value == cls.SPX.value:
            return cls.SPX.name
        elif value == cls.SPY.value:
            return cls.SPY.name
        else:
            return None
    
    @classmethod
    def get_exchange(cls, name):
        
        if name in [cls.BANKNIFTY.name, cls.NIFTY.name, cls.FINNIFTY.name, cls.MIDCPNIFTY.name]:
            return "NSE"
        elif name in [cls.SENSEX.name, cls.BANKEX.name]:
            return "BSE"
        elif name in [cls.COPPER.name, cls.CRUDEOILM.name, cls.CRUDEOIL.name, cls.GOLDM.name, cls.GOLD.name, cls.NATGASMINI.name, cls.NATURALGAS.name, cls.SILVERM.name, cls.SILVER.name, cls.ZINC.name]:
            return "MCX"
        elif name in [cls.QQQ.name, cls.SPX.name, cls.SPY.name]:
            return "US"
        
        return ""
    
    @classmethod
    def to_enum(cls, name):
        if name == cls.BANKNIFTY.name:
            return cls.BANKNIFTY
        elif name == cls.NIFTY.name:
            return cls.NIFTY
        elif name == cls.FINNIFTY.name:
            return cls.FINNIFTY
        elif name == cls.MIDCPNIFTY.name:
            return cls.MIDCPNIFTY
        elif name == cls.SENSEX.name:
            return cls.SENSEX
        elif name == cls.BANKEX.name:
            return cls.BANKEX
        elif name == cls.COPPER.name:
            return cls.COPPER
        elif name == cls.CRUDEOILM.name:
            return cls.CRUDEOILM
        elif name == cls.CRUDEOIL.name:
            return cls.CRUDEOIL
        elif name == cls.GOLDM.name:
            return cls.GOLDM
        elif name == cls.GOLD.name:
            return cls.GOLD
        elif name == cls.NATGASMINI.name:
            return cls.NATGASMINI
        elif name == cls.NATURALGAS.name:
            return cls.NATURALGAS
        elif name == cls.SILVERM.name:
            return cls.SILVERM
        elif name == cls.SILVER.name:
            return cls.SILVER
        elif name == cls.ZINC.name:
            return cls.ZINC
        elif name == cls.QQQ.name:
            return cls.QQQ
        elif name == cls.SPX.name:
            return cls.SPX
        elif name == cls.SPY.name:
            return cls.SPY
        else:
            return None
        


class OPTIONTYPE:
    PUT = ENUMELEMENT(-1, "PUT")
    CALL = ENUMELEMENT(1, "CALL")
    FUT = ENUMELEMENT(0, "FUT")

    @classmethod
    def choices(cls):
        return [cls.PUT.name, cls.CALL.name, cls.FUT.name]
    
class EXPIRYTYPE:
    WEEKLY = ENUMELEMENT(1, "WEEKLY")
    NEXT_WEEKLY = ENUMELEMENT(2, "NEXT_WEEKLY")
    MONTHLY = ENUMELEMENT(3, "MONTHLY")

    @classmethod
    def choices(cls):
        return [cls.WEEKLY.name, cls.NEXT_WEEKLY.name, cls.MONTHLY.name]
    
    
class REENTRYTYPE:
    IMMIDIATE = ENUMELEMENT(1, "IMMIDIATE")
    IMMIDIATE_NC = ENUMELEMENT(2, "IMMIDIATE_NC")
    AS_ORIGINAL = ENUMELEMENT(3, "AS_ORIGINAL")
    RE_COST = ENUMELEMENT(4, "RE_COST")
    
    @classmethod
    def choices(cls):
        return [cls.IMMIDIATE.name, cls.IMMIDIATE_NC.name, cls.AS_ORIGINAL.name, cls.RE_COST.name]
    
class FORCEENTRYTYPE:
    HIGHER_PREMIUM = ENUMELEMENT(1, "HIGHER_PREMIUM")
    LOWER_PREMIUM = ENUMELEMENT(2, "LOWER_PREMIUM")
    
    @classmethod
    def choices(cls):
        return [cls.HIGHER_PREMIUM.name, cls.LOWER_PREMIUM.name]


class RSIDIRECTION:
    INSIDE = ENUMELEMENT(1, "INSIDE")
    OUTSIDE = ENUMELEMENT(2, "OUTSIDE")
    
    @classmethod
    def choices(cls):
        return [cls.INSIDE.name, cls.OUTSIDE.name]
    
class EMADIRECTION:
    UPCROSS = ENUMELEMENT(1, "UPCROSS")
    DOWNCROSS = ENUMELEMENT(2, "DOWNCROSS")
    
    @classmethod
    def choices(cls):
        return [cls.UPCROSS.name, cls.DOWNCROSS.name]
    
    
class VWAPDIRECTION:
    UPCROSS = ENUMELEMENT(1, "UPCROSS")
    DOWNCROSS = ENUMELEMENT(2, "DOWNCROSS")
    
    @classmethod
    def choices(cls):
        return [cls.UPCROSS.name, cls.DOWNCROSS.name]


class LOCKTYPE:
    REGULAR  = ENUMELEMENT(1, "REGULAR")
    MAX_TILL_TIME = ENUMELEMENT(2, "MAX_TILL_TIME")
    MAX_POSSIBLE_PROFIT = ENUMELEMENT(3, "MAX_POSSIBLE_PROFIT")
    
    
class SIDE:
    SELL = ENUMELEMENT(-1, "SELL")
    BUY = ENUMELEMENT(1, "BUY")

    @classmethod
    def choices(cls):
        return [cls.SELL.name, cls.BUY.name]


class EXCHANGE:
    BACKTEST = ENUMELEMENT(1, "BACKTEST")
    PAPERTRADE = ENUMELEMENT(2, "PAPERTRADE")
    NSE = ENUMELEMENT(3, "NSE")
    NFO = ENUMELEMENT(4, "NFO")
    BSE = ENUMELEMENT(5, "BSE")
    BFO = ENUMELEMENT(6, "BFO")
    MCX = ENUMELEMENT(7, "MCX")
    US = ENUMELEMENT(8, "US")

    @classmethod
    def choices(cls):
        return [cls.BACKTEST.name, cls.PAPERTRADE.name, cls.NSE.name, cls.NFO.name, cls.NFO.name, cls.BSE.name, cls.BFO.name, cls.MCX.name, cls.US.name]


class ORDERTYPE:
    MARKET = ENUMELEMENT(1, "MARKET")
    LIMIT = ENUMELEMENT(2, "LIMIT")
    STOPLOSS = ENUMELEMENT(3, "STOPLOSS")
    UNKNOWN = ENUMELEMENT(4, "UNKNOWN")

    @classmethod
    def choices(cls):
        return [cls.MARKET.name, cls.LIMIT.name, cls.STOPLOSS.name]


class PRODUCTTYPE:
    MIS = ENUMELEMENT(1, "MIS")
    NRML = ENUMELEMENT(2, "NRML")

    @classmethod
    def choices(cls):
        return [cls.MIS.name, cls.NRML.name]


class ORDERSTATUS:
    CREATED = ENUMELEMENT(1, "CREATED")
    SENT = ENUMELEMENT(2, "SENT")
    PENDING = ENUMELEMENT(3, "PENDING")
    WORKING = ENUMELEMENT(3, "WORKING")
    OPEN = ENUMELEMENT(4, "OPEN")
    COMPLETE = ENUMELEMENT(5, "COMPLETE")
    CANCELLED = ENUMELEMENT(6, "CANCELLED")
    REJECTED = ENUMELEMENT(7, "REJECTED")

    @classmethod
    def choices(cls):
        return [
            cls.CREATED.name,
            cls.SENT.name,
            cls.PENDING.name,
            cls.WORKING.name,
            cls.OPEN.name,
            cls.COMPLETE.name,
            cls.CANCELLED.name,
            cls.REJECTED.name,
        ]
        
class STRATEGYSTATUS:
    CREATED = ENUMELEMENT(1, "CREATED")
    RUNNING = ENUMELEMENT(2, "RUNNING")
    PAUSED = ENUMELEMENT(3, "PAUSED")
    STOPPED = ENUMELEMENT(4, "STOPPED")
    SL_HIT = ENUMELEMENT(5, "SL_HIT")
    TP_HIT = ENUMELEMENT(6, "TP_HIT")
    RSI_HIT = ENUMELEMENT(7, "RSI_HIT")
    COMPLETED = ENUMELEMENT(8, "COMPLETED")
    FAILED = ENUMELEMENT(9, "FAILED")
    BOX_SL_HIT = ENUMELEMENT(10, "BOX_SL_HIT")
    BOX_TP_HIT = ENUMELEMENT(11, "BOX_TP_HIT")
    SQUAREOFF_ALL = ENUMELEMENT(12, "SQUAREOFF_ALL")
    INDICATOR_HIT = ENUMELEMENT(13, "INDICATOR_HIT")

    @classmethod
    def choices(cls):
        return [
            cls.CREATED.name,
            cls.RUNNING.name,
            cls.PAUSED.name,
            cls.STOPPED.name,
            cls.COMPLETED.name,
            cls.FAILED.name,
            cls.BOX_SL_HIT,
            cls.BOX_TP_HIT,
            cls.SQUAREOFF_ALL
        ]
        

class LEGSTATUS:
    CREATED = ENUMELEMENT(1, "CREATED")
    CONTRACTRIZED = ENUMELEMENT(2, "CONTRACTRIZED")
    ENTERED = ENUMELEMENT(2, "ENTERED")
    EXITED = ENUMELEMENT(3, "EXITED")
    STOP_LOSS_REENTRY = ENUMELEMENT(4, "STOP_LOSS_REENTRY")
    TAKE_PROFIT_REENTRY = ENUMELEMENT(5, "TAKE_PROFIT_REENTRY")
    WAITING_FOR_STOP_LOSS_FILL = ENUMELEMENT(6, "WAITING_FOR_STOP_LOSS_FILL")
    WAITING_FOR_TAKE_PROFIT_FILL = ENUMELEMENT(7, "WAITING_FOR_TAKE_PROFIT_FILL")
    WAITING_FOR_STG_STOP_LOSS_FILL = ENUMELEMENT(8, "WAITING_FOR_STG_STOP_LOSS_FILL")
    WAITING_FOR_STG_TAKE_PROFIT_FILL = ENUMELEMENT(9, "WAITING_FOR_STG_TAKE_PROFIT_FILL")
    WAITING_FOR_HEDGE_ENTRY = ENUMELEMENT(10, "WAITING_FOR_HEDGE_ENTRY")
    WAITING_FOR_HEDGE_EXIT = ENUMELEMENT(11, "WAITING_FOR_HEDGE_EXIT")
    WAITING_FOR_ENTRY = ENUMELEMENT(12, "WAITING_FOR_ENTRY")
    WAITING_FOR_STOP_LOSS_EXIT = ENUMELEMENT(13, "WAITING_FOR_STOP_LOSS_EXIT")
    WAITING_FOR_TAKE_PROFIT_EXIT = ENUMELEMENT(14, "WAITING_FOR_TAKE_PROFIT_EXIT")
    WIATING_FOR_TIME_EXIT = ENUMELEMENT(15, "WIATING_FOR_TIME_EXIT")
    WAITING_FOR_TIME_EXIT_FILL = ENUMELEMENT(16, "WAITING_FOR_TIME_EXIT_FILL")
    WAITING_FOR_STG_STOP_LOSS_EXIT = ENUMELEMENT(17, "WAITING_FOR_STG_STOP_LOSS_EXIT")
    WAITING_FOR_STG_TAKE_PROFIT_EXIT = ENUMELEMENT(18, "WAITING_FOR_STG_TAKE_PROFIT_EXIT")
    WAITING_FOR_STG_RSI_EXIT = ENUMELEMENT(19, "WAITING_FOR_STG_RSI_EXIT")
    WAITING_FOR_STG_RSI_EXIT_FILL = ENUMELEMENT(20, "WAITING_FOR_STG_RSI_EXIT_FILL")
    WAITING_FOR_BOX_STOP_LOSS_EXIT = ENUMELEMENT(21, "WAITING_FOR_BOX_STOP_LOSS_EXIT")
    WAITING_FOR_BOX_STOP_LOSS_FILL = ENUMELEMENT(22, "WAITING_FOR_BOX_STOP_LOSS_FILL")
    WAITING_FOR_BOX_TAKE_PROFIT_EXIT = ENUMELEMENT(23, "WAITING_FOR_BOX_TAKE_PROFIT_EXIT")
    WAITING_FOR_BOX_TAKE_PROFIT_FILL = ENUMELEMENT(24, "WAITING_FOR_BOX_TAKE_PROFIT_FILL")
    WAITING_FOR_SQUAREOFF_EXIT = ENUMELEMENT(25, "WAITING_FOR_SQUAREOFF_EXIT")
    WAITING_FOR_SQUAREOFF_FILL = ENUMELEMENT(26, "WAITING_FOR_SQUAREOFF_FILL")
    WAITING_FOR_INDICATOR_EXIT = ENUMELEMENT(27, "WAITING_FOR_INDICATOR_EXIT")
    WAITING_FOR_INDICATOR_FILL = ENUMELEMENT(28, "WAITING_FOR_INDICATOR_EXIT")
    WAITING_FOR_PORTFOLIO_STOP_LOSS_EXIT = ENUMELEMENT(29, "WAITING_FOR_PORTFOLIO_STOP_LOSS_EXIT")
    WAITING_FOR_PORTFOLIO_STOP_LOSS_FILL = ENUMELEMENT(30, "WAITING_FOR_PORTFOLIO_STOP_LOSS_FILL")
    WAITING_FOR_PORTFOLIO_TAKE_PROFIT_EXIT = ENUMELEMENT(31, "WAITING_FOR_PORTFOLIO_TAKE_PROFIT_EXIT")
    WAITING_FOR_PORTFOLIO_TAKE_PROFIT_FILL = ENUMELEMENT(32, "WAITING_FOR_PORTFOLIO_TAKE_PROFIT_FILL")
    EXIT_TRIGGERED = ENUMELEMENT(33, "EXIT_TRIGGERED")
    WAITING_FOR_TRIGGER_EXIT = ENUMELEMENT(34, "WAITING_FOR_TRIGGER_EXIT")
    WAITING_FOR_TRIGGER_FILL = ENUMELEMENT(35, "WAITING_FOR_TRIGGER_FILL")
    TRIGGER_REENTRY = ENUMELEMENT(36, "TRIGGER_REENTRY")
    
    @classmethod
    def choices(cls):
        return [
            cls.CREATED.name,
            cls.ENTERED.name,
            cls.EXITED.name,
            cls.STOP_LOSS_REENTRY.name,
            cls.TAKE_PROFIT_REENTRY.name,
            cls.WAITING_FOR_STOP_LOSS_FILL.name,
            cls.WAITING_FOR_TAKE_PROFIT_FILL.name,
            cls.WAITING_FOR_STG_STOP_LOSS_FILL.name,
            cls.WAITING_FOR_STG_TAKE_PROFIT_FILL.name,
            cls.WAITING_FOR_HEDGE_ENTRY.name,
            cls.WAITING_FOR_HEDGE_EXIT.name,
            cls.WAITING_FOR_ENTRY.name,
            cls.WAITING_FOR_STOP_LOSS_EXIT.name,
            cls.WAITING_FOR_TAKE_PROFIT_EXIT.name,
            cls.WIATING_FOR_TIME_EXIT.name,
            cls.WAITING_FOR_TIME_EXIT_FILL.name,
            cls.WAITING_FOR_STG_STOP_LOSS_EXIT.name,
            cls.WAITING_FOR_STG_TAKE_PROFIT_EXIT.name,
            cls.WAITING_FOR_STG_RSI_EXIT.name,
            cls.WAITING_FOR_STG_RSI_EXIT_FILL.name,
        ]
        

class BROKER:
    PAPER = ENUMELEMENT(1, "PAPER")
    JAINAMPRO = ENUMELEMENT(2, "JAINAMPRO")

    @classmethod
    def choices(cls):
        return [cls.PAPER.name, cls.JAINAMPRO.name]

class FEEDSOURCE:
    HISTORICAL = ENUMELEMENT(1, "HISTORICAL")
    SYMPHONY = ENUMELEMENT(2, "SYMPHONY")

    @classmethod
    def choices(cls):
        return [cls.HISTORICAL.name, cls.SYMPHONY.name]