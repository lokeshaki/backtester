from time import time
from app.config import Config
from app.commons.modules import logging, Dict, datetime
from app.commons.enums import (
    ENUMELEMENT,
    FEEDSOURCE,
    NSEINDEX,
    UNDERLYINGTYPE,
    OPTIONTYPE,
    LEGSTATUS,
    ORDERSTATUS,
    SIDE,
    NUMBERTYPE,
    LOCKTYPE,
    BROKER,
)
from app.commons.constants import MAX_INT
from app.parser.models import Portfolio
from app.database.utils import (
    get_available_trading_dates,
    get_trading_time_stamp,
    get_current_week_expiry_date,
    get_valid_trading_dates
)
from app.database.local import EXPIRIES_ON_DATE
from app.evaluator.vwap_ema import evaluate_vwap_strategy
from app.evaluator.heiken import evaluate_heikin_strategy
from app.evaluator.five_ema import evaluate_five_ema_strategy
from app.evaluator import evaluate_strategy
from app.evaluator.utils import tb_strategy_day_reset, vwap_strategy_day_reset, portfolio_day_reset, is_stg_stop_loss_hit, is_stg_profit_hit, place_exit_order, place_hedge_exit_order, get_monthly_expiry_date, get_quote, calculate_current_pnl, is_lock_is_triggered, trail_stg_sl
from app.backtester.utils import generate_backtest_result
from app.database.local import MCX_HALF_TRADING_DAYS
from app.commons.constants import MCX_HALF_TRADING_START_TIME

logger = logging.getLogger(__name__)


def run_portfolio(
    portfolio: Portfolio,
    start_date: int,
    end_date: int,
    fix_vix: float,
    broker_details: Dict,
    exchange: ENUMELEMENT,
    product_type: ENUMELEMENT,
    order_type: ENUMELEMENT,
    check_interval: int,
    feed_source: ENUMELEMENT,
    is_live: bool=False,
):
    """
    Run backtest for given strategy
    :param strategy: Strategy object
    :return: None
    """
    backtest_start_time = time()
    current_date = start_date
    orders = []
    broker = eval(broker_details.get("broker"))
    client_id = broker_details.get("client_id")
    trading_timestamps = get_trading_time_stamp(exchange=exchange.name)

    trading_dates_for_loop = get_valid_trading_dates(exchange=exchange, start_date=start_date, end_date=end_date)

    available_dates = {}
    for indicee in Config.LOAD_INDEXES:
        indicee = NSEINDEX.to_enum(indicee)
        available_dates[indicee.name] = get_available_trading_dates(index=indicee)

    portfolio_profits = {}
    portfolio_losses = {}
    for current_date in trading_dates_for_loop:
        if current_date in Config.EXCEPTION_DATES:
            continue
        portfolio_profits[current_date] = {}
        portfolio_losses[current_date] = {}
        try:
            for trading_timestamp in trading_timestamps:

                if (exchange.name == "MCX") and (current_date in MCX_HALF_TRADING_DAYS) and (trading_timestamp < MCX_HALF_TRADING_START_TIME):
                    continue

                pf_profit = 0
                pf_loss = 0
                for strategy in portfolio.strategies:

                    if (strategy.index.name not in available_dates) or (current_date not in available_dates[strategy.index.name]):
                        continue

                    if strategy.dte is not None:
                        # For both NSE/BSE and MCX: DTE represents days before expiry to execute
                        # The difference is NSE/BSE use weekly expiries, MCX uses monthly expiries
                        if strategy.index.name in ["COPPER", "CRUDEOIL", "CRUDEOILM", "GOLD", "GOLDM", "NATGASMINI", "NATURALGAS", "NICKEL", "SILVER", "SILVERM", "ZINC"]:
                            # MCX instruments: Use monthly expiry dates
                            try:
                                # If DTE >= 30, run on all days
                                if strategy.dte >= 30:
                                    pass  # Don't skip any days, run on all trading days
                                else:
                                    # If DTE < 30, run only on specific days (DTE days before expiry)
                                    # For MCX, use the first leg's expiry_type to determine which expiry
                                    if strategy.legs and len(strategy.legs) > 0:
                                        first_leg = strategy.legs[0]
                                        # MCX typically uses MONTHLY expiry, but check the leg's expiry_type
                                        if hasattr(first_leg, 'expiry_type') and first_leg.expiry_type.name == "NEXT_WEEKLY":
                                            # Use next month expiry
                                            expiries = sorted(list(EXPIRIES_ON_DATE[strategy.index.name][current_date]))
                                            target_expiry = expiries[1] if len(expiries) > 1 else expiries[0]
                                        else:
                                            # Default to current month expiry (WEEKLY or MONTHLY for MCX)
                                            target_expiry = sorted(list(EXPIRIES_ON_DATE[strategy.index.name][current_date]))[0]
                                    else:
                                        # Fallback to current month if no legs
                                        target_expiry = sorted(list(EXPIRIES_ON_DATE[strategy.index.name][current_date]))[0]
                                    
                                    # Calculate DTE: days between current_date and target_expiry
                                    date_index = available_dates[strategy.index.name].index(current_date)
                                    expiry_index = available_dates[strategy.index.name].index(target_expiry)
                                    
                                    if strategy.dte != (expiry_index - date_index):
                                        continue
                                    
                            except (KeyError, IndexError, ValueError):
                                continue  # Skip if no expiry data available or date not found
                        else:
                            # Original logic for NSE/BSE (weekly contracts)
                            weekly_expiry = get_current_week_expiry_date(strategy.index, current_date, False)
                            date_index = available_dates[strategy.index.name].index(current_date)
                            week_expiry_index = available_dates[strategy.index.name].index(weekly_expiry)
                        
                            if strategy.dte != (week_expiry_index - date_index):
                                continue

                    if strategy.acceptable_weekdays:
                        current_weekday = datetime.strptime(str(current_date), "%y%m%d").weekday() + 1
                        if current_weekday not in strategy.acceptable_weekdays:
                            continue

                    if available_dates[strategy.index.name].index(current_date) == 0:
                        continue

                    if strategy.type == "Vwap":
                        evaluate_vwap_strategy(
                            strategy,
                            current_date,
                            trading_timestamp,
                            strategy.index_base_price,
                            fix_vix,
                            broker,
                            client_id,
                            exchange,
                            product_type,
                            order_type,
                            orders,
                            available_dates[strategy.index.name],
                            FEEDSOURCE.HISTORICAL,
                        )
                    elif strategy.type == "Heikin":
                        evaluate_heikin_strategy(
                            strategy,
                            current_date,
                            trading_timestamp,
                            strategy.index_base_price,
                            fix_vix,
                            broker,
                            client_id,
                            exchange,
                            product_type,
                            order_type,
                            orders,
                            available_dates[strategy.index.name],
                            FEEDSOURCE.HISTORICAL,
                        )
                    elif strategy.type == "five_ema":
                        evaluate_five_ema_strategy(
                            strategy,
                            current_date,
                            trading_timestamp,
                            strategy.index_base_price,
                            fix_vix,
                            broker,
                            client_id,
                            exchange,
                            product_type,
                            order_type,
                            orders,
                            available_dates[strategy.index.name],
                            FEEDSOURCE.HISTORICAL,
                        )
                    else:
                        evaluate_strategy(
                            strategy,
                            current_date,
                            trading_timestamp,
                            strategy.index_base_price,
                            fix_vix,
                            broker,
                            client_id,
                            exchange,
                            product_type,
                            order_type,
                            orders,
                            available_dates[strategy.index.name],
                            FEEDSOURCE.HISTORICAL,
                        )
                    if len(strategy.tick_profits) > 0 and current_date in strategy.tick_profits and trading_timestamp in strategy.tick_profits[current_date]:
                        pf_profit += strategy.tick_profits[current_date][trading_timestamp]
                        portfolio_profits[current_date][trading_timestamp] = pf_profit
                    if len(strategy.tick_losses) > 0 and current_date in strategy.tick_losses and trading_timestamp in strategy.tick_losses[current_date]:
                        pf_loss += strategy.tick_losses[current_date][trading_timestamp]
                        portfolio_losses[current_date][trading_timestamp] = pf_loss
                        
                
                if (portfolio.lock_and_trail.type == LOCKTYPE.MAX_TILL_TIME) and (len(portfolio_profits[current_date].values()) > 0) and (portfolio.lock_and_trail.lock_time == trading_timestamp) and (portfolio.lock_and_trail.lock==0):
                    max_till =  max(portfolio_profits[current_date].values())
                    if max_till > 0:
                        portfolio.lock_and_trail.lock = max_till
                        portfolio.current_stop_loss = portfolio.lock_and_trail.lock*portfolio.lock_and_trail.trail/100
                        portfolio.can_trail = True
                if (portfolio.lock_and_trail.type == LOCKTYPE.MAX_POSSIBLE_PROFIT) and (portfolio.lock_and_trail.lock_time == trading_timestamp) and (portfolio.lock_and_trail.lock==0):
                    max_possible_profit =  0
                    for strategy in portfolio.strategies:
                        for leg in strategy.legs:
                            if leg.status == LEGSTATUS.ENTERED:
                                max_possible_profit += -leg.orders[-1].average_price*leg.side.value*leg.quantity
                    if max_possible_profit > 0:
                        portfolio.lock_and_trail.lock = max_possible_profit
                        portfolio.current_take_profit = portfolio.lock_and_trail.lock*portfolio.lock_and_trail.trail/100
                
                if portfolio.lock_and_trail.lock:
                    if portfolio.lock_and_trail.type == LOCKTYPE.MAX_POSSIBLE_PROFIT:
                        if trading_timestamp == portfolio.lock_and_trail.next_check_time:
                            if portfolio.lock_and_trail.final_trail != MAX_INT:
                                portfolio.current_take_profit = portfolio.lock_and_trail.lock*portfolio.lock_and_trail.final_trail/100
                            else:
                                portfolio.current_take_profit = portfolio.take_profit.value
                        if trading_timestamp >= portfolio.lock_and_trail.final_trail_time:
                            portfolio.current_take_profit = portfolio.take_profit.value
                            
                    if not portfolio.can_trail and is_lock_is_triggered(pf_profit, portfolio.lock_and_trail.lock):
                        portfolio.is_lock_is_triggerd = True
                        if portfolio.lock_and_trail.type == LOCKTYPE.MAX_TILL_TIME:
                            # portfolio.current_stop_loss = portfolio.lock_and_trail.lock*portfolio.lock_and_trail.trail/100
                            # logger.info(f"Max: {portfolio.current_stop_loss}")
                            ## I suugest it should cross MAX to first trail
                            ...
                        else:
                            portfolio.current_stop_loss = portfolio.lock_and_trail.trail
                        portfolio.can_trail = True
                elif portfolio.lock_and_trail.type != LOCKTYPE.MAX_TILL_TIME:
                    if not portfolio.can_trail:
                        portfolio.can_trail = True
                if portfolio.can_trail:
                    trail_stg_sl(portfolio, pf_profit, portfolio.lock_and_trail.type)
                    
                if is_stg_profit_hit(pf_profit, portfolio.current_take_profit):
                    for strategy in portfolio.strategies:
                        if strategy.underlying == UNDERLYINGTYPE.FUTURE:
                            monthly_expiry = get_monthly_expiry_date(strategy.index, current_date, is_live)
                            index_ohlc = get_quote(feed_source, strategy.index, current_date,trading_timestamp - check_interval, trading_timestamp, option_type=OPTIONTYPE.FUT, expiry=monthly_expiry)
                        elif strategy.underlying == UNDERLYINGTYPE.CASH:
                            index_ohlc = get_quote(feed_source, strategy.index, current_date, trading_timestamp - check_interval, trading_timestamp)
                        index_price = index_ohlc.open/100.0
                        for leg in strategy.legs:
                            if leg.status == LEGSTATUS.ENTERED:
                                if leg.hedge and leg.hedge.entry_order and leg.hedge.entry_order.status == ORDERSTATUS.COMPLETE:
                                    place_hedge_exit_order(strategy, leg, product_type, order_type, current_date, trading_timestamp, index_price, broker, client_id, "Portfolio Take Profit Hedge Exit", orders)
                                else:
                                    leg.status = LEGSTATUS.WAITING_FOR_PORTFOLIO_TAKE_PROFIT_EXIT
                            elif leg.status in [LEGSTATUS.CREATED, LEGSTATUS.CONTRACTRIZED]:
                                leg.status = LEGSTATUS.EXITED
                    portfolio.is_exit_hit = True
                if is_stg_stop_loss_hit(pf_loss, portfolio.current_stop_loss):
                    for strategy in portfolio.strategies:
                        if strategy.underlying == UNDERLYINGTYPE.FUTURE:
                            monthly_expiry = get_monthly_expiry_date(strategy.index, current_date, is_live)
                            index_ohlc = get_quote(feed_source, strategy.index, current_date,trading_timestamp - check_interval, trading_timestamp, option_type=OPTIONTYPE.FUT, expiry=monthly_expiry)
                        elif strategy.underlying == UNDERLYINGTYPE.CASH:
                            index_ohlc = get_quote(feed_source, strategy.index, current_date, trading_timestamp - check_interval, trading_timestamp)
                        index_price = index_ohlc.open/100.0
                        for leg in strategy.legs:
                            if leg.status == LEGSTATUS.ENTERED:
                                if leg.hedge and leg.hedge.entry_order and leg.hedge.entry_order.status == ORDERSTATUS.COMPLETE:
                                    exit_reason = "Portfolio Stop Loss Hedge Exit"
                                    if portfolio.is_lock_is_triggerd:
                                        if portfolio.is_stop_loss_trailed:
                                            exit_reason = "Portfolio Stop Loss Trailing Hit"
                                        else:
                                            exit_reason = "Portfolio Minimum Profit Lock Hit"
                                    else:
                                        if portfolio.is_stop_loss_trailed:
                                            exit_reason = "Portfolio Stop Loss Trailing Hit"
                                    place_hedge_exit_order(strategy, leg, product_type, order_type, current_date, trading_timestamp, index_price, broker, client_id, exit_reason, orders)
                                else:
                                    leg.status = LEGSTATUS.WAITING_FOR_PORTFOLIO_STOP_LOSS_EXIT
                            elif leg.status in [LEGSTATUS.CREATED, LEGSTATUS.CONTRACTRIZED]:
                                leg.status = LEGSTATUS.EXITED
                    portfolio.is_exit_hit = True
                                
                is_all_legs_exited = True
                for strategy in portfolio.strategies:
                    for leg in strategy.legs:
                        if leg.status == LEGSTATUS.WAITING_FOR_HEDGE_EXIT:
                            if leg.hedge.exit_order.status == ORDERSTATUS.COMPLETE:
                                if leg.hedge_pnl_effect:
                                    pnl_type = NUMBERTYPE.POINT
                                    if strategy.type != "Vwap":
                                        pnl_type = leg.take_profit.type
                                    hedge_pnl = calculate_current_pnl(leg.hedge.exit_order.average_price, leg.hedge.entry_order.average_price, leg.hedge.side, pnl_type)*leg.quantity*leg.multiplier
                                    if leg.hedge.side == SIDE.BUY:
                                        leg.realized_pnl += hedge_pnl
                                        strategy.realized_pnl += hedge_pnl
                                    else:
                                        leg.realized_pnl += -hedge_pnl
                                        strategy.realized_pnl += -hedge_pnl
                                if leg.hedge.exit_order.reason == "Portfolio Take Profit Hedge Exit":
                                    leg.status = LEGSTATUS.WAITING_FOR_PORTFOLIO_TAKE_PROFIT_EXIT
                                elif leg.hedge.exit_order.reason in ["Portfolio Stop Loss Hedge Exit", "Portfolio Stop Loss Trailing Hit", "Portfolio Minimum Profit Lock Hit", "Portfolio Stop Loss Trailing Hit"]:
                                    leg.status = LEGSTATUS.WAITING_FOR_PORTFOLIO_STOP_LOSS_EXIT
                                    
                        if leg.status == LEGSTATUS.WAITING_FOR_PORTFOLIO_TAKE_PROFIT_EXIT:
                            last_order = leg.orders[-1]
                            ohlc = get_quote(
                                feed_source,
                                last_order.contract.symbol,
                                current_date,
                                trading_timestamp,
                                trading_timestamp,
                                last_order.contract.expiry_date,
                                last_order.contract.strike_price,
                                last_order.contract.option_type,
                            )
                            if ohlc is None:
                                continue
                            if strategy.pnl_calculation_from == "OPEN":
                                exit_price = ohlc.open/100.0
                            elif strategy.pnl_calculation_from == "CLOSE":
                                exit_price = ohlc.close/100.0
                            else:
                                exit_price = ohlc.low/100.0 if last_order.side == SIDE.BUY else ohlc.high/100.0
                            place_exit_order(strategy, leg, last_order, product_type, order_type, current_date, trading_timestamp, index_price, "Portfolio Take Profit Exit", broker, client_id, exit_price, orders, LEGSTATUS.WAITING_FOR_PORTFOLIO_TAKE_PROFIT_FILL)
                        
                        if leg.status == LEGSTATUS.WAITING_FOR_PORTFOLIO_STOP_LOSS_EXIT:
                            last_order = leg.orders[-1]
                            ohlc = get_quote(
                                feed_source,
                                last_order.contract.symbol,
                                current_date,
                                trading_timestamp,
                                trading_timestamp,
                                last_order.contract.expiry_date,
                                last_order.contract.strike_price,
                                last_order.contract.option_type,
                            )
                            if ohlc is None:
                                continue
                            if strategy.pnl_calculation_from == "OPEN":
                                exit_price = ohlc.open/100.0
                            elif strategy.pnl_calculation_from == "CLOSE":
                                exit_price = ohlc.close/100.0
                            else:
                                exit_price = ohlc.low/100.0 if last_order.side == SIDE.BUY else ohlc.high/100.0

                            exit_reason = "Portfolio Stop Loss Exit"
                            if portfolio.is_lock_is_triggerd:
                                if portfolio.is_stop_loss_trailed:
                                    exit_reason = "Portfolio Stop Loss Trailing Hit"
                                else:
                                    exit_reason = "Portfolio Minimum Profit Lock Hit"
                            else:
                                if portfolio.is_stop_loss_trailed:
                                    exit_reason = "Portfolio Stop Loss Trailing Hit"
                            place_exit_order(strategy, leg, last_order, product_type, order_type, current_date, trading_timestamp, index_price, exit_reason, broker, client_id, exit_price, orders, LEGSTATUS.WAITING_FOR_PORTFOLIO_STOP_LOSS_FILL)
                                
                        if leg.status in [LEGSTATUS.WAITING_FOR_PORTFOLIO_STOP_LOSS_FILL, LEGSTATUS.WAITING_FOR_PORTFOLIO_TAKE_PROFIT_FILL]:
                            exit_order = leg.orders[-1]
                            if exit_order.status == ORDERSTATUS.COMPLETE:
                                entry_order = leg.orders[-2]
                                pnl_type = NUMBERTYPE.POINT
                                if strategy.type not in ["Vwap", "Heikin", "five_ema"]:
                                    pnl_type = leg.take_profit.type
                                leg_pnl = calculate_current_pnl(exit_order.average_price, entry_order.average_price, entry_order.side, pnl_type)*entry_order.quantity
                                leg.realized_pnl += leg_pnl
                                strategy.realized_pnl += leg_pnl
                                leg.status = LEGSTATUS.EXITED
                        if leg.status not in [LEGSTATUS.EXITED, LEGSTATUS.CREATED]:
                            is_all_legs_exited = False
                if is_all_legs_exited and portfolio.is_exit_hit:
                    if strategy.exit_date and strategy.exit_date != current_date:
                        continue
                    if strategy.type not in ["Vwap", "Heikin", "five_ema"]:
                        tb_strategy_day_reset(strategy)
                    else:
                        
                        vwap_strategy_day_reset(strategy)
                    break

        except Exception as ex:
            logger.info(
                "Exception occured while backtesting, for date %s", current_date
            )
            logger.exception(ex)
        
        for strategy in portfolio.strategies:
            if strategy.exit_date and  strategy.exit_date !=current_date:
                continue
            if strategy.type in ["Vwap", "Heikin", "five_ema"]:
                vwap_strategy_day_reset(strategy)
            else:
                tb_strategy_day_reset(strategy)
        
        portfolio_day_reset(portfolio)

    return {"strategies": generate_backtest_result(backtest_start_time, orders, portfolio_profits, portfolio_losses).to_json()}

    # results = {"strategies": []}
    # for strategy in portfolio.strategies:
    #     result = generate_backtest_result(
    #         backtest_start_time, orders, strategy.tick_profits, strategy.tick_losses
    #     )
    #     results["strategies"].append(result.to_json())

    return results
