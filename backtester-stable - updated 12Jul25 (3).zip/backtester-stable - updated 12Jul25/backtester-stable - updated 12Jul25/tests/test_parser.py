import unittest
from app.commons.enums import NUMBERTYPE, STRIKESELECTIONTYPE, SIDE, STRATEGYTYPE, OPTIONTYPE, NSEINDEX
from app.parser.models import (
    StrikeSelection,
    StopLoss,
    TakeProfit,
    ProfitMove,
    StopLossMove,
    TrailingStopLoss,
    Leg,
    Strategy,
)
from app.parser.utils import (
    parse_strike_selection_json,
    parse_stop_loss_json,
    parse_take_profit_json,
    parse_profit_move_json,
    parse_stop_loss_move_json,
    parse_trailing_stop_loss_json,
    parse_leg_json,
    parse_strategy_json,
)


class TestParser(unittest.TestCase):
    def test_parse_strike_selection_json(self):
        strike_selection = parse_strike_selection_json(
            {"type": "STRIKESELECTIONTYPE.BY_PREMIUM", "value": 0.1}
        )
        strike_selection_expected = StrikeSelection(STRIKESELECTIONTYPE.BY_PREMIUM, 0.1)
        self.assertEqual(strike_selection.type, strike_selection_expected.type)
        self.assertEqual(strike_selection.value, strike_selection_expected.value)

    def test_parse_stop_loss_json(self):
        stop_loss = parse_stop_loss_json(
            {"type": "NUMBERTYPE.PERCENTAGE", "value": 0.1}
        )
        stop_loss_expected = StopLoss(NUMBERTYPE.PERCENTAGE, 0.1)
        self.assertEqual(stop_loss.type, stop_loss_expected.type)
        self.assertEqual(stop_loss.value, stop_loss_expected.value)

    def test_parse_take_profit_json(self):
        take_profit = parse_take_profit_json(
            {"type": "NUMBERTYPE.PERCENTAGE", "value": 0.1}
        )
        take_profit_expected = TakeProfit(NUMBERTYPE.PERCENTAGE, 0.1)
        self.assertEqual(take_profit.type, take_profit_expected.type)
        self.assertEqual(take_profit.value, take_profit_expected.value)

    def test_parse_profit_move_json(self):
        profit_move = parse_profit_move_json(
            {"type": "NUMBERTYPE.PERCENTAGE", "value": 0.1}
        )
        profit_move_expected = ProfitMove(NUMBERTYPE.PERCENTAGE, 0.1)
        self.assertEqual(profit_move.type, profit_move_expected.type)
        self.assertEqual(profit_move.value, profit_move_expected.value)

    def test_parse_stop_loss_move_json(self):
        stop_loss_move = parse_stop_loss_move_json(
            {"type": "NUMBERTYPE.PERCENTAGE", "value": 0.1}
        )
        stop_loss_move_expected = StopLossMove(NUMBERTYPE.PERCENTAGE, 0.1)
        self.assertEqual(stop_loss_move.type, stop_loss_move_expected.type)
        self.assertEqual(stop_loss_move.value, stop_loss_move_expected.value)

    def test_parse_trailing_stop_loss_json(self):
        trailing_stop_loss = parse_trailing_stop_loss_json(
            {
                "profit_move": {"type": "NUMBERTYPE.PERCENTAGE", "value": 0.1},
                "stop_loss_move": {"type": "NUMBERTYPE.PERCENTAGE", "value": 0.1},
            }
        )
        trailing_stop_loss_expected = TrailingStopLoss(
            ProfitMove(NUMBERTYPE.PERCENTAGE, 0.1),
            StopLossMove(NUMBERTYPE.PERCENTAGE, 0.1),
        )
        self.assertEqual(
            trailing_stop_loss.profit_move.type,
            trailing_stop_loss_expected.profit_move.type,
        )
        self.assertEqual(
            trailing_stop_loss.profit_move.value,
            trailing_stop_loss_expected.profit_move.value,
        )
        self.assertEqual(
            trailing_stop_loss.stop_loss_move.type,
            trailing_stop_loss_expected.stop_loss_move.type,
        )
        self.assertEqual(
            trailing_stop_loss.stop_loss_move.value,
            trailing_stop_loss_expected.stop_loss_move.value,
        )

    def test_parse_leg_json(self):
        leg = parse_leg_json(
            {
                "option_type": "OPTIONTYPE.CALL",
                "side": "SIDE.BUY",
                "strike_selection": {
                    "type": "STRIKESELECTIONTYPE.BY_PREMIUM",
                    "value": 0.1,
                },
                "stop_loss": {"type": "NUMBERTYPE.PERCENTAGE", "value": 0.1},
                "take_profit": {"type": "NUMBERTYPE.PERCENTAGE", "value": 0.1},
                "trailing_stop_loss": {
                    "profit_move": {"type": "NUMBERTYPE.PERCENTAGE", "value": 0.1},
                    "stop_loss_move": {"type": "NUMBERTYPE.PERCENTAGE", "value": 0.1},
                },
                "quantity": 25,
                "multiplier": 1,
            }
        )
        leg_expected = Leg(
            OPTIONTYPE.CALL,
            SIDE.BUY,
            StrikeSelection(STRIKESELECTIONTYPE.BY_PREMIUM, 0.1),
            StopLoss(NUMBERTYPE.PERCENTAGE, 0.1),
            TakeProfit(NUMBERTYPE.PERCENTAGE, 0.1),
            TrailingStopLoss(
                ProfitMove(NUMBERTYPE.PERCENTAGE, 0.1),
                StopLossMove(NUMBERTYPE.PERCENTAGE, 0.1),
            ),
            25,
            1,
        )
        self.assertEqual(leg.strike_selection.type, leg_expected.strike_selection.type)
        self.assertEqual(
            leg.strike_selection.value, leg_expected.strike_selection.value
        )
        self.assertEqual(leg.stop_loss.type, leg_expected.stop_loss.type)
        self.assertEqual(leg.stop_loss.value, leg_expected.stop_loss.value)
        self.assertEqual(leg.take_profit.type, leg_expected.take_profit.type)
        self.assertEqual(leg.take_profit.value, leg_expected.take_profit.value)
        self.assertEqual(
            leg.trailing_stop_loss.profit_move.type,
            leg_expected.trailing_stop_loss.profit_move.type,
        )
        self.assertEqual(
            leg.trailing_stop_loss.profit_move.value,
            leg_expected.trailing_stop_loss.profit_move.value,
        )
        self.assertEqual(
            leg.trailing_stop_loss.stop_loss_move.type,
            leg_expected.trailing_stop_loss.stop_loss_move.type,
        )
        self.assertEqual(
            leg.trailing_stop_loss.stop_loss_move.value,
            leg_expected.trailing_stop_loss.stop_loss_move.value,
        )

    def test_parse_strategy_json(self):
        strategy = parse_strategy_json(
            {
                "name": "Test Strategy",
                "type": "STRATEGYTYPE.INTRADAY",
                "index": "NSEINDEX.NIFTY",
                "entry_time": 910,
                "exit_time": 1530,
                "legs": [
                    {
                        "option_type": "OPTIONTYPE.CALL",
                        "side": "SIDE.BUY",
                        "strike_selection": {
                            "type": "STRIKESELECTIONTYPE.BY_PREMIUM",
                            "value": 0.1,
                        },
                        "stop_loss": {"type": "NUMBERTYPE.PERCENTAGE", "value": 0.1},
                        "take_profit": {"type": "NUMBERTYPE.PERCENTAGE", "value": 0.1},
                        "trailing_stop_loss": {
                            "profit_move": {
                                "type": "NUMBERTYPE.PERCENTAGE",
                                "value": 0.1,
                            },
                            "stop_loss_move": {
                                "type": "NUMBERTYPE.PERCENTAGE",
                                "value": 0.1,
                            },
                        },
                        "quantity": 25,
                        "multiplier": 1,
                    }
                ],
            }
        )

        strategy_expected = Strategy(
            "Test Strategy",
            STRATEGYTYPE.INTRADAY,
            NSEINDEX.NIFTY,
            910,
            1530,
            [
                Leg(
                    OPTIONTYPE.CALL,
                    SIDE.BUY,
                    StrikeSelection(STRIKESELECTIONTYPE.BY_PREMIUM, 0.1),
                    StopLoss(NUMBERTYPE.PERCENTAGE, 0.1),
                    TakeProfit(NUMBERTYPE.PERCENTAGE, 0.1),
                    TrailingStopLoss(
                        ProfitMove(NUMBERTYPE.PERCENTAGE, 0.1),
                        StopLossMove(NUMBERTYPE.PERCENTAGE, 0.1),
                    ),
                    25,
                    1,
                )
            ],
        )

        self.assertEqual(strategy.name, strategy_expected.name)
        self.assertEqual(strategy.type, strategy_expected.type)
        self.assertEqual(strategy.entry_time, strategy_expected.entry_time)
        self.assertEqual(strategy.exit_time, strategy_expected.exit_time)
        self.assertEqual(strategy.legs[0].side, strategy_expected.legs[0].side)
        self.assertEqual(
            strategy.legs[0].strike_selection.type,
            strategy_expected.legs[0].strike_selection.type,
        )
        self.assertEqual(
            strategy.legs[0].strike_selection.value,
            strategy_expected.legs[0].strike_selection.value,
        )
        self.assertEqual(
            strategy.legs[0].stop_loss.type, strategy_expected.legs[0].stop_loss.type
        )
        self.assertEqual(
            strategy.legs[0].stop_loss.value, strategy_expected.legs[0].stop_loss.value
        )
        self.assertEqual(
            strategy.legs[0].take_profit.type,
            strategy_expected.legs[0].take_profit.type,
        )
        self.assertEqual(
            strategy.legs[0].take_profit.value,
            strategy_expected.legs[0].take_profit.value,
        )
        self.assertEqual(
            strategy.legs[0].trailing_stop_loss.profit_move.type,
            strategy_expected.legs[0].trailing_stop_loss.profit_move.type,
        )
        self.assertEqual(
            strategy.legs[0].trailing_stop_loss.profit_move.value,
            strategy_expected.legs[0].trailing_stop_loss.profit_move.value,
        )
        self.assertEqual(
            strategy.legs[0].trailing_stop_loss.stop_loss_move.type,
            strategy_expected.legs[0].trailing_stop_loss.stop_loss_move.type,
        )
        self.assertEqual(
            strategy.legs[0].trailing_stop_loss.stop_loss_move.value,
            strategy_expected.legs[0].trailing_stop_loss.stop_loss_move.value,
        )
        self.assertEqual(strategy.legs[0].quantity, strategy_expected.legs[0].quantity)
        self.assertEqual(
            strategy.legs[0].multiplier, strategy_expected.legs[0].multiplier
        )
