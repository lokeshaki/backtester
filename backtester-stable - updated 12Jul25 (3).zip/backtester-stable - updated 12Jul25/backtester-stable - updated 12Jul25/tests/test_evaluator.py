import unittest
from app.commons.enums import NUMBERTYPE, ENUMELEMENT, SIDE
from app.parser.models import StopLoss, TakeProfit, WaitIn

from app.evaluator.utils import (
    is_time_for_entry,
    is_time_for_exit,
    calculate_current_pnl,
    calculate_stop_loss_points,
    calculate_take_profit_points,
    is_stop_loss_hit,
    is_take_profit_hit,
    calculate_wait_points,
    is_waiting_is_over
)


class TestEvaluator(unittest.TestCase):
    def test_is_time_for_entry(self):
        self.assertTrue(is_time_for_entry(104523, 100000))
        self.assertTrue(is_time_for_entry(104523, 104523))

    def test_not_time_for_entry(self):
        self.assertFalse(is_time_for_entry(100000, 104523))

    def test_is_time_for_exit(self):
        self.assertTrue(is_time_for_exit(104523, 100000))
        self.assertTrue(is_time_for_exit(104523, 104523))

    def test_not_time_for_exit(self):
        self.assertFalse(is_time_for_exit(100000, 104523))

    def test_calculate_current_pnl(self):
        ltp = 110
        trade_price = 100
        trade_side = SIDE.BUY
        pnl_type = NUMBERTYPE.POINT
        pnl = calculate_current_pnl(ltp, trade_price, trade_side, pnl_type)

        self.assertEqual(pnl, 10)

        ltp = 110
        trade_price = 100
        trade_side = SIDE.SELL
        pnl_type = NUMBERTYPE.POINT
        pnl = calculate_current_pnl(ltp, trade_price, trade_side, pnl_type)

        self.assertEqual(pnl, -10)

        ltp = 110
        trade_price = 100
        trade_side = SIDE.BUY
        pnl_type = NUMBERTYPE.PERCENTAGE
        pnl = calculate_current_pnl(ltp, trade_price, trade_side, pnl_type)

        self.assertEqual(pnl, 10)

        ltp = 110
        trade_price = 100
        trade_side = SIDE.SELL
        pnl_type = NUMBERTYPE.PERCENTAGE
        pnl = calculate_current_pnl(ltp, trade_price, trade_side, pnl_type)

        self.assertEqual(pnl, -10)

    def test_calculate_current_pnl_invalid_trade_side(self):
        ltp = 110
        trade_price = 100
        trade_side = ENUMELEMENT(0, "INVALID")
        pnl_type = NUMBERTYPE.POINT

        with self.assertRaises(ValueError):
            calculate_current_pnl(ltp, trade_price, trade_side, pnl_type)

    def test_calculate_current_pnl_invalid_pnl_type(self):
        ltp = 110
        trade_price = 100
        trade_side = SIDE.BUY
        pnl_type = ENUMELEMENT(0, "INVALID")

        with self.assertRaises(ValueError):
            calculate_current_pnl(ltp, trade_price, trade_side, pnl_type)

    def test_calculate_stop_loss_points(self):
        trade_price = 100
        stop_loss = StopLoss(NUMBERTYPE.POINT, 10)
        stop_loss_points = calculate_stop_loss_points(trade_price, stop_loss)

        self.assertEqual(stop_loss_points, 10)

        trade_price = 100
        stop_loss = StopLoss(NUMBERTYPE.PERCENTAGE, 10)
        stop_loss_points = calculate_stop_loss_points(trade_price, stop_loss)

        self.assertEqual(stop_loss_points, 10)
        
    def test_calculate_stop_loss_points_invalid_stop_loss_type(self):
        trade_price = 100
        stop_loss = StopLoss(ENUMELEMENT(0, "INVALID"), 10)

        with self.assertRaises(ValueError):
            calculate_stop_loss_points(trade_price, stop_loss)
            
    def test_calculate_take_profit_points(self):
        trade_price = 100
        take_profit = TakeProfit(NUMBERTYPE.POINT, 10)
        take_profit_points = calculate_take_profit_points(trade_price, take_profit)

        self.assertEqual(take_profit_points, 10)

        trade_price = 100
        take_profit = TakeProfit(NUMBERTYPE.PERCENTAGE, 10)
        take_profit_points = calculate_take_profit_points(trade_price, take_profit)

        self.assertEqual(take_profit_points, 10)
        
    def test_calculate_take_profit_points_invalid_take_profit_type(self):
        trade_price = 100
        take_profit = TakeProfit(ENUMELEMENT(0, "INVALID"), 10)

        with self.assertRaises(ValueError):
            calculate_take_profit_points(trade_price, take_profit)
            
    def test_is_stop_loss_hit(self):
        trade_price = 100
        trade_side = SIDE.BUY
        stop_loss = StopLoss(NUMBERTYPE.POINT, 10)
        ltp = 90
        pnl = calculate_current_pnl(ltp, trade_price, trade_side, stop_loss.type)
        stop_loss_points = calculate_stop_loss_points(trade_price, stop_loss)
        
        self.assertTrue(is_stop_loss_hit(pnl, stop_loss_points))
        
        trade_price = 100
        trade_side = SIDE.SELL
        stop_loss = StopLoss(NUMBERTYPE.POINT, 10)
        ltp = 110
        pnl = calculate_current_pnl(ltp, trade_price, trade_side, stop_loss.type)
        stop_loss_points = calculate_stop_loss_points(trade_price, stop_loss)
        
        self.assertTrue(is_stop_loss_hit(pnl, stop_loss_points))
        
    def test_is_take_profit_hit(self):
        trade_price = 100
        trade_side = SIDE.BUY
        take_profit = TakeProfit(NUMBERTYPE.POINT, 10)
        ltp = 110
        pnl = calculate_current_pnl(ltp, trade_price, trade_side, take_profit.type)
        take_profit_points = calculate_take_profit_points(trade_price, take_profit)
        
        self.assertTrue(is_take_profit_hit(pnl, take_profit_points))
        
        trade_price = 100
        trade_side = SIDE.SELL
        take_profit = TakeProfit(NUMBERTYPE.POINT, 10)
        ltp = 90
        pnl = calculate_current_pnl(ltp, trade_price, trade_side, take_profit.type)
        take_profit_points = calculate_take_profit_points(trade_price, take_profit)
        
        self.assertTrue(is_take_profit_hit(pnl, take_profit_points))
        
    def test_calculate_wait_points(self):
        trade_price = 100
        wait_in = WaitIn(NUMBERTYPE.POINT, -10)
        wait_in_points = calculate_wait_points(trade_price, wait_in)

        self.assertEqual(wait_in_points, -10)

        trade_price = 100
        wait_in = WaitIn(NUMBERTYPE.PERCENTAGE, 10)
        wait_in_points = calculate_wait_points(trade_price, wait_in)

        self.assertEqual(wait_in_points, 10)
        
    def test_is_waiting_is_over(self):
        wait_in = WaitIn(NUMBERTYPE.POINT, -10)
        initial_price = 100
        ltp = 90
        wait_in_points = calculate_wait_points(initial_price, wait_in)
        result = is_waiting_is_over(ltp, initial_price, wait_in_points)
        self.assertTrue(result)
        
        wait_in = WaitIn(NUMBERTYPE.POINT, 10)
        initial_price = 100
        ltp = 110
        wait_in_points = calculate_wait_points(initial_price, wait_in)
        result = is_waiting_is_over(ltp, initial_price, wait_in_points)
        self.assertTrue(result)
        
        wait_in = WaitIn(NUMBERTYPE.PERCENTAGE, 10)
        initial_price = 100
        ltp = 110
        wait_in_points = calculate_wait_points(initial_price, wait_in)
        result = is_waiting_is_over(ltp, initial_price, wait_in_points)
        self.assertTrue(result)
        
        wait_in = WaitIn(NUMBERTYPE.PERCENTAGE, -10)
        initial_price = 100
        ltp = 90
        wait_in_points = calculate_wait_points(initial_price, wait_in)
        result = is_waiting_is_over(ltp, initial_price, wait_in_points)
        self.assertTrue(result)
        