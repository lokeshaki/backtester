import unittest

from app.backtester import run_backtest
from app.backtester.models import BacktestResult
from app.parser.models import (
    Strategy,
    Leg,
    StrikeSelection,
    StopLoss,
    TakeProfit,
    TrailingStopLoss,
    StopLossMove,
    ProfitMove,
)
from app.commons.enums import (
    SIDE,
    NSEINDEX,
    EXCHANGE,
    OPTIONTYPE,
    PRODUCTTYPE,
    ORDERTYPE,
    STRATEGYTYPE,
    STRIKESELECTIONTYPE,
    NUMBERTYPE,
    BROKER
)


class TestBacktester(unittest.TestCase):
    def test_run_backtest(self):
        leg = Leg(
            OPTIONTYPE.CALL,
            SIDE.BUY,
            StrikeSelection(STRIKESELECTIONTYPE.BY_ATM_STRIKE, 0.0),
            StopLoss(NUMBERTYPE.POINT, 100000),
            TakeProfit(NUMBERTYPE.POINT, 20),
            TrailingStopLoss(
                ProfitMove(NUMBERTYPE.POINT, 20), StopLossMove(NUMBERTYPE.POINT, 10)
            ),
            25,
            1,
        )
        strategy = Strategy(
            "1st_test",
            STRATEGYTYPE.INTRADAY,
            NSEINDEX.BANKNIFTY,
            33300,
            55700,
            [leg]
        )
        
        result = run_backtest(strategy, 200101, 200121, BROKER.PAPER, EXCHANGE.NSE, PRODUCTTYPE.NRML, ORDERTYPE.MARKET)
        
        self.assertIsInstance(result, BacktestResult)
        
        
