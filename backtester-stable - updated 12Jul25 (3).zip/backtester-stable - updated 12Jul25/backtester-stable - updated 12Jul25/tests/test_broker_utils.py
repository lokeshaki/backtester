import unittest

from app.commons.enums import SIDE, NSEINDEX, EXCHANGE, OPTIONTYPE, PRODUCTTYPE, ORDERTYPE
from app.commons.models import TimeStamp
from app.broker.models import  Trade
from app.commons.models import Contract
from app.broker.utils import write_to_trade_file, create_order


class TestBrokerUtils(unittest.TestCase):
    def test_create_order(self):
        order = create_order(
            EXCHANGE.NSE,
            PRODUCTTYPE.MIS,
            ORDERTYPE.LIMIT,
            SIDE.BUY,
            NSEINDEX.BANKNIFTY,
            20230804,
            45000,
            OPTIONTYPE.CALL,
            455.0,
            0.0,
            30,
            TimeStamp(20230729, 343221),
        )
        self.assertEqual(order.side, SIDE.BUY)
        self.assertEqual(order.contract.symbol, NSEINDEX.BANKNIFTY)
        self.assertEqual(order.contract.expiry_date, 20230804)
        self.assertEqual(order.contract.strike_price, 45000)
        self.assertEqual(order.contract.option_type, OPTIONTYPE.CALL)
        self.assertEqual(order.product_type, PRODUCTTYPE.MIS)
        self.assertEqual(order.order_type, ORDERTYPE.LIMIT)
        self.assertEqual(order.limit_price, 455.0)
        self.assertEqual(order.trigger_price, 0.0)
        self.assertEqual(order.quantity, 30)
        self.assertEqual(order.creation_time, TimeStamp(20230729, 343221))
        
    def test_write_to_trade_file(self):
        contract = Contract(
            EXCHANGE.NSE, NSEINDEX.BANKNIFTY, 20230804, 45000, OPTIONTYPE.CALL
        )
        trade = Trade(contract, SIDE.BUY, 455.0, 30, TimeStamp(20230729, 343221))

        write_to_trade_file(trade)
        with open("trades.txt", "r") as f:
            lines = f.readlines()
            self.assertEqual(
                lines[1],
                "20230729,343221,NSE,BANKNIFTY,20230804,45000,CALL,BUY,455.0,30\n",
            )
