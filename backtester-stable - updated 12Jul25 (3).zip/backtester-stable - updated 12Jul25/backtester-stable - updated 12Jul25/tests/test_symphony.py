import unittest
from app.api_providers.symphony import login_to_market_data

class TestSymphony(unittest.TestCase):
    def test_market_data_login(self):
        base_url = "http://122.160.137.209:13000"
        api_key = "73184f2eafc5d61cb9a940"
        api_secret = "Pwyq131$vW"
        response = login_to_market_data(base_url, api_key, api_secret)
        if response:
            self.assertTrue(True)