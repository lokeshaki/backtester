Old Backtester used for TBS,IBS,ORB and TV strategies
