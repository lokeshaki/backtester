############################################################################## importing libraries
from dateutil.relativedelta import relativedelta
from datetime import datetime, timedelta
import mysql.connector as mysql
import pandas as pd
import torch
import simplejson
import subprocess
import traceback
import warnings
import requests
import logging
import shutil
import config
import math
import time
import json
import os
import numpy as np

LOG_FILE_PATH = os.path.join(config.LOG_FILE_FOLDER, datetime.now().strftime("%d%m%Y, %H%M%S")+".log")

os.makedirs(config.LOG_FILE_FOLDER, exist_ok=True)
logging.basicConfig(filename=LOG_FILE_PATH, format="%(asctime)s: [BTRUN] %(message)s", level=logging.INFO)

pd.set_option('mode.chained_assignment', None)
warnings.simplefilter('ignore')

# Configure PyTorch to use GPU if available
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
torch.set_default_device(device)

class Util:

    COLUMN_RENAME_MAPPING = {
        'leg_id': "ID", 'index_entry_price':'Index At Entry', 'index_exit_price':'Index At Exit', 'entry_date':"Entry Date", 'entry_time' : "Enter On", 
        'entry_day': "Entry Day", 'exit_date':"Exit Date", 'exit_time': "Exit at", 'exit_day':"Exit Day", 'symbol':"Index", 'expiry':"Expiry", 
        'strike':"Strike", 'instrument_type':"CE/PE", 'side':"Trade", 'filled_quantity':"Qty", 'entry_price':"Entry at", 'exit_price':"Exit at", 
        'pnl':"PNL", 'pnlAfterSlippage':"AfterSlippage", 'expenses':"Taxes", 'netPnlAfterExpenses':"Net PNL", 're_entry_no':"Re-entry No", 
        'reason':"Reason", 'max_profit':"MaxProfit", 'max_loss': "MaxLoss", "strategy_entry_number": "Strategy Entry No", "strategy": "Strategy Name",
        "stop_loss_entry_number": "SL Re-entry No", "take_profit_entry_number": "TGT Re-entry No", "points": "Points", "pointsAfterSlippage": 'Points After Slippage',
        "portfolio_name": "Portfolio Name"
    }
    COLUMN_ORDER = [
        'portfolio_name', 'strategy', 'leg_id', 'entry_date', 'entry_time', 'entry_day', 'exit_date', 'exit_time', 'exit_day', 'symbol', 'expiry', 'strike', 
        'instrument_type', 'side', 'filled_quantity', 'entry_price', 'exit_price', 'points', 'pointsAfterSlippage', 'pnl', 'pnlAfterSlippage', 'expenses', 
        'netPnlAfterExpenses', 're_entry_no', 'stop_loss_entry_number', 'take_profit_entry_number', 'reason', 'strategy_entry_number', 'index_entry_price', 
        'index_exit_price', 'max_profit', 'max_loss'
    ]
    EXPIRY_ALIAS = {
        "CURRENT": "WEEKLY", "NEXT": "NEXT_WEEKLY", "MONTHLY": "MONTHLY"
    }
    RE_ENTRY_ALIAS = {
        "INSTANT SAME STRIKE": "IMMIDIATE", "ORIGINAL": "AS_ORIGINAL", "COST": "RE_COST", "INSTANT NEW STRIKE": "IMMIDIATE_NC"
    }
    TGT_SL_ALIAS = {
        "POINT": "POINT", "POINTS": "POINT", "PERCENT": "PERCENTAGE", "PERCENTAGE": "PERCENTAGE", "INDEX POINT": "INDEX_POINTS", 
        "INDEX PERCENTAGE": "INDEX_PERCENTAGE", "ABSOLUTE": "PREMIUM", "DELTA": "ABSOLUTE_DELTA"
    }
    UNDERLYING_ALIAS = {
        "SPOT": "CASH", "FUTURE": "FUTURE"
    }
    STGY_STR_PARA_COLUMN_NAME_UPPER = [
        "StrategyName", "Index", "TgtTrackingFrom", "TgtRegisterPriceFrom", "SlTrackingFrom", "SlRegisterPriceFrom", "PnLCalculationFrom", 
        "ConsiderHedgePnLForStgyPnL", "CheckPremiumDiffCondition", "PremiumDiffType", "PremiumDiffChangeStrike", "PremiumDiffDoForceEntry", 
        "PremiumDiffForceEntryConsiderPremium", "Underlying", "Tradertype", "MoveSlToCost", "ChangeStrikeForIndicatorBasedReEntry", 
        "OnExpiryDayTradeNextExpiry", "ConsiderVwapForEntry", "ConsiderVwapForExit", "ConsiderEMAForEntry", "ConsiderEMAForExit", "ConsiderSTForEntry", 
        "ConsiderSTForExit", "ConsiderRSIForEntry", "ConsiderRSIForExit", "ConsiderVolSmaForEntry", "ConsiderVolSmaForExit", "StrategyType"
    ]
    STGY_STR_PARA_COLUMN_NAME_LOWER = [
        "EntryCombination", 'ExitCombination', "VwapEntryCondition", "VwapExitCondition", "EmaEntryCondition", "EmaExitCondition", "StEntryCondition",
        "StExitCondition", "RsiEntryCondition", "RsiExitCondition", "VolSmaEntryCondition", "VolSmaExitCondition", "StrategyTrailingType"
    ]
    LEG_IDS_COLUMN_NAME = [
        'LegID', 'OnEntry_OpenTradeOn', 'OnEntry_SqOffTradeOff', 'OnExit_OpenTradeOn', 'OnExit_SqOffTradeOff', 
    ]
    LEG_STR_PARA_COLUMN_NAME = [
        'StrategyName', 'Instrument', 'Transaction', 'W&Type', 'StrikeMethod', 'MatchPremium', 'SLType', 'TGTType', 'TrailSLType', 'Expiry', 'SL_ReEntryType', 
        'TGT_ReEntryType', 'OpenHedge', 'HedgeStrikeMethod', 'IsIdle', 'OnEntry_SqOffAllLegs', 'OnExit_SqOffAllLegs', 'ReEntryType', 'TrailW&T', 'OnExit_OpenAllLegs'
    ]
    MARGIN_REQ_HEADERS = {
        "authority": "margin-calc-arom-prod.angelbroking.com", "origin": "https://www.angelone.in", "referer": "https://www.angelone.in/",
        "user-agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_0) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.5 Safari/605.1.15", 
        "content-type": "application/json", "path": "/margin-calculator/SPAN"
    }
    VALID_BT_TYPE_FOR_USER = [
        "TBS", "ORB", "VWAP", "HEIKIN_RSI_EMA", "HEIKIN_RSI_ST", "5_EMA", "OI"
    ]
    USER_BT_TYPE_ENGINE_MAPPING = {
        "TBS": "Tbs", "ORB": "Orb", "VWAP": "Vwap", "HEIKIN_RSI_EMA": "Heikin", "HEIKIN_RSI_ST": "Heikin", "5_EMA": "five_ema", "INDICATOR": "INDICATOR", 
        "OI": "Tbs"
    }
    FIELDS_TO_MULTIPLY_BY_PORTFOLIO_MULTIPLIER = {
        "GeneralParameter": ["StrategyProfit", "StrategyLoss", "ProfitReaches", "LockMinProfitAt", "IncreaseInProfit", "TrailMinProfitBy"],
        "LegParameter": ["Lots"]
    }
    MCX_SYMBOLS = [
        'COPPER', 'CRUDEOIL', 'CRUDEOILM', 'GOLD', 'GOLDM', 'NATGASMINI', 'NATURALGAS', 'NICKEL', 'SILVER', 'SILVERM', 'ZINC'
    ]
    US_SYMBOLS = [
        "QQQ", "SPX", "SPY"
    ]
    NON_MCX_SYMBOLS = [
        "NIFTY", "BANKNIFTY", "FINNIFTY", "MIDCPNIFTY", "SENSEX", "BANKEX"
    ]

    MARGIN_SYMBOL_INFO_FILE_PATH = "marginSymbolInfo.json"
    MARGIN_INFO = {}

    LOTSIZE_FILE_PATH = "LOTSIZE.csv"

    BT_FIELDS = {
        'VwapExitCondition', 'TgtTrackingFrom', 'StartTime', 'OnExpiryDayTradeNextExpiry', 'EntryCombination', 'ConsiderVolSmaForEntry', 'Expiry', 
        'ConsiderSTForExit', 'EmaEntryCondition', 'TGT_ReEntryNo', 'LockMinProfitAt', 'StrategyLossReExecuteNo', 'StrikeSelectionTime', 
        'HedgeStrikePremiumCondition', 'StrikeMethod', 'MatchPremium', 'StrategyTrailingType', 'Timeframe', 'SL_TrailBy', 'ConsiderHedgePnLForStgyPnL', 
        'OrbRangeEnd', 'StrategyID', 'Underlying', 'PortfolioTarget', 'EndTime', 'RsiExitCondition', 'LegID', 'TGTValue', 'Tradertype', 'Index', 
        'PortfolioTrailingType', 'PnLCalculationFrom', 'PortfolioID', 'EndDate', 'StrategyName', 'StrategiesSetting', 'LastEntryTime', 'HedgeStrikeValue', 
        'STPeriod', 'VolSmaEntryCondition', 'SLType', 'ConsiderEMAForEntry', 'Instrument', 'Transaction', 'ChangeStrikeForIndicatorBasedReEntry', 
        'TrailMinProfitBy', 'ConsiderVwapForEntry', 'SL_ReEntryType', 'StoplossCheckingInterval', 'StrategyType', 'EMAPeriod', 'LegsSettings', 'SlTrackingFrom', 
        'OrbRangeStart', 'SL_TrailAt', 'PortfolioStoploss', 'ConsiderRSIForEntry', 'ProfitReaches', 'TGTType', 'Lots', 'ConsiderSTForEntry', 'DTE', 
        'StrategyProfitReExecuteNo', 'StartDate', 'TrailSLType', 'SL_ReEntryNo', 'IndicatorBasedReEntry', 'TgtRegisterPriceFrom', 'ExitCombination', 
        'PortfolioName', 'StrikePremiumCondition', 'ConsiderVwapForExit', 'STMultiplier', 'SLValue', 'IncreaseInProfit', 'SlRegisterPriceFrom', 
        'ReEntryCheckingInterval', 'EmaExitCondition', 'Weekdays', 'StrategyLoss', 'StrikeValue', 'TradeStrikeValue', 'ConsiderVolSmaForExit', 
        'TargetCheckingInterval', 'RsiPeriod', 'VolSMAPeriod', 'StrategyProfit', 'StEntryCondition', 'TGT_ReEntryType', 'W&Type', 'MoveSlToCost', 
        'ConsiderEMAForExit', 'HedgeStrikeMethod', 'VwapEntryCondition', 'RsiEntryCondition', 'VolSmaExitCondition', 'W&TValue', 'OpenHedge', 'StExitCondition', 
        'ConsiderRSIForExit', 'IsIdle', 'ReEnteriesCount', 'OnEntry_SqOffAllLegs', 'OnExit_SqOffAllLegs', 'isTickBt', 'TrailW&T', 'PnLCalTime', 'LockPercent', 
        'TrailPercent', 'SqOff1Time', 'SqOff1Percent', 'SqOff2Time', 'SqOff2Percent', 'MaxOpenPositions', 'OiThreshold', 'OnExit_OpenAllLegs'
    }
    BT_FIELDS = {__i.lower(): __i for __i in BT_FIELDS}

    METRICS_KEY_NAME = {
        'Backtest Start Date': 'backteststartdate', 'Backtest End Date': 'backtestenddate', 'Margin Required': 'marginrequired', 
        'Number of Trading Days': 'nooftradingdays', 'Number of +ve days': 'noofpositivetradingdays', 'Number of -ve days': 'noofnegativetradingdays', 
        'Total PnL': 'totalpnl', 'Average Profit': 'averageprofit', 'Average Loss': 'averageloss', 'Maximum Trade Profit': 'maximumtradeprofit', 
        'Maximum Trade Loss': 'maximumtradeloss', 'Median Trade': 'mediantrade', 'Consecutive Wins': 'consecutivewins', 
        'Consecutive Losses': 'consecutivelosses', 'Win Rate': 'winrate', 'Expectancy': 'expectancy', 'Sharpe Ratio': 'sharperatio', 
        'Sortino Ratio': 'sortinoratio', 'Calmar': 'calmar', 'CAGR': 'cagr', 'Max Drawdown': 'maxdrawdown', 'Max Drawdown Percent': 'maxdrawdownpercentage', 
        'Days Taken to Recover From Drawdown': 'daystakentorecoverfromdrawdown', 'Profit Factor (Amount of Profit per unit of Loss)': 'profitfactor', 
        'Outlier Adjusted Profit Factor': 'outlieradjustedprofitfactor'
    }
    
    @staticmethod
    def runNeccesaryFunctionsBeforeStartingBT():
        
        Util.populateSymbolInfoForMargin()
        Util.populateLotSize()
    
    @staticmethod
    def to_tensor(data):
        """Convert numpy arrays or pandas objects to PyTorch tensors on GPU if available."""
        if isinstance(data, pd.DataFrame):
            return torch.tensor(data.values, dtype=torch.float32, device=device)
        elif isinstance(data, pd.Series):
            return torch.tensor(data.values, dtype=torch.float32, device=device)
        elif isinstance(data, np.ndarray):
            return torch.tensor(data, dtype=torch.float32, device=device)
        elif isinstance(data, (int, float)):
            return torch.tensor([data], dtype=torch.float32, device=device)
        elif isinstance(data, list):
            return torch.tensor(data, dtype=torch.float32, device=device)
        elif isinstance(data, torch.Tensor):
            return data.to(device)
        else:
            raise TypeError(f"Unsupported data type for tensor conversion: {type(data)}")
    
    @staticmethod
    def from_tensor(tensor):
        """Convert PyTorch tensor back to numpy array."""
        if isinstance(tensor, torch.Tensor):
            return tensor.cpu().numpy()
        return tensor
    
    @staticmethod
    def populateLotSize() -> None:

        if not os.path.exists(Util.LOTSIZE_FILE_PATH):
            logging.error(f"Unable to get lot size file path. File path: {Util.LOTSIZE_FILE_PATH}")
            raise ValueError(f"Unable to get lot size file path. File path: {Util.LOTSIZE_FILE_PATH}")
        
        lotsizedf = pd.read_csv(Util.LOTSIZE_FILE_PATH)
        if lotsizedf.empty:
            logging.error("Empty file content from lot size file path.")
            raise ValueError("Empty file content from lot size file path.")
        
        lotsizedf = lotsizedf[~pd.isnull(lotsizedf['underlyingname'])]
        if lotsizedf.empty:
            logging.error("Empty file content from lot size file path.")
            raise ValueError("Empty file content from lot size file path.")
        
        lotsizedf['underlyingname'] = lotsizedf['underlyingname'].str.upper()
        config.LOT_SIZE = lotsizedf.set_index("underlyingname").to_dict()["lotsize"]
    
    @staticmethod
    def getTVMainParametersFromFrontendTV(inputJson: dict) -> dict:

        return {
            "StartDate": datetime.strptime(str(int(inputJson['startdate'])), "%y%m%d").strftime('%d_%m_%Y'), 
            "EndDate": datetime.strptime(str(int(inputJson['enddate'])), "%y%m%d").strftime('%d_%m_%Y'),  
            "Name": inputJson['name'], "SignalDateFormat": inputJson['signaldatetimeformat'], "ManualTradeEntryTime": inputJson['manualtradeentrytime'],
            "ManualTradeLots": inputJson["manualtradelots"],
            "FirstTradeEntryTime": inputJson['firsttradeentrytime'], "TvExitApplicable": inputJson['tvexitapplicable'].upper() == "YES", 
            "IncreaseEntrySignalTimeBy": inputJson['increaseentrysignaltimeby'], "IncreaseExitSignalTimeBy": inputJson['increaseexitsignaltimeby'], 
            "IntradaySqOffApplicable": inputJson['intradaysqoffapplicable'].upper() == "YES", "IntradayExitTime": inputJson['intradayexittime'], 
            "ExpiryDayExitTime": inputJson['expirydayexittime'], "DoRollover": inputJson['dorollover'].upper() == "YES", "RolloverTime": ['rollovertime']
        }
    
    @staticmethod
    def copyFilesIntoMergeFolder(filePath: list) -> None:
        
        mergeFolder = os.path.join(os.getcwd(), "merge")
        if not os.path.exists(mergeFolder):
            logging.info(f"Unable to get merge folder, folder path: {mergeFolder}")
            return
        
        pyOutputFolder = os.path.join(mergeFolder, "py_output")
        if not os.path.exists(pyOutputFolder):
            logging.info(f"Unable to get py_output folder, folder path: {pyOutputFolder}")
            return
        
        shutil.rmtree(pyOutputFolder)
        os.mkdir(pyOutputFolder)

        [shutil.copy(filetocopy, os.path.join(pyOutputFolder, os.path.basename(filetocopy))) for filetocopy in filePath]

        os.chdir(mergeFolder)
        subprocess.run(os.path.join(mergeFolder, "run_me.bat"))

    @staticmethod
    def getDateInfoForRollver(indexTraded: str) -> dict:

        for __delay in range(1,6):

            try:
        
                mydb = mysql.connect(host="106.51.63.60", user="ajay", password="master76", database="historicaldb")
                cursorObj = mydb.cursor()

                cursorObj.execute(f"select * from {indexTraded.lower()}_expiry")

                expiryDict = cursorObj.fetchall()
                expiryDict = {expiryEntry[0]: [expDate for expDate in expiryEntry[1:] if expDate is not None] for expiryEntry in expiryDict}

                return {"expirys": expiryDict, "tradingdates": sorted(expiryDict.keys())}
            
            except Exception:
                logging.error(traceback.format_exc())
                time.sleep(__delay)
        
        return {}

    @staticmethod
    def writeParametersToTvOutputFile(tvMainPara: dict, mainParaColumnName: list, outputExcelFilePath: str, tvSignalsDf: pd.DataFrame) -> dict:

        toReturn, settingToDump = {}, {}
        
        tvmainparadf = pd.DataFrame(tvMainPara).transpose()
        settingToDump['tvsetting'] = tvmainparadf.copy()
        
        del tvmainparadf

        if tvMainPara['LongPortfolioFilePath'] != "":
            settingToDump["long"] = Util.getPortfolioJson(excelFilePath=tvMainPara['LongPortfolioFilePath'])[1]
        
        if tvMainPara['ShortPortfolioFilePath'] != "":
            settingToDump["short"] = Util.getPortfolioJson(excelFilePath=tvMainPara['ShortPortfolioFilePath'])[1]
        
        if tvMainPara['ManualPortfolioFilePath'] != "":
            settingToDump["manual"] = Util.getPortfolioJson(excelFilePath=tvMainPara['ManualPortfolioFilePath'])[1]

        excelObjj = pd.ExcelWriter(outputExcelFilePath, engine='openpyxl', mode="w")
        with excelObjj as writer:
            settingToDump['tvsetting'].to_excel(writer, sheet_name="Tv Setting", index=False)
            tvSignalsDf.to_excel(writer, sheet_name="Tv Signals", index=False)

            for porttype in ["long", "short", "manual"]:
                if porttype not in settingToDump:
                    continue

                toReturn[porttype] = {}

                for shtName in ["PortfolioParameter", "GeneralParameter", "LegParameter"]:
                    
                    toDump = pd.DataFrame()
                    for keyy in settingToDump[porttype]:
                        
                        if shtName not in settingToDump[porttype][keyy]:
                            continue

                        toDump = pd.concat([toDump, settingToDump[porttype][keyy][shtName]])
                        toDump = toDump.reset_index(drop=True)
                    
                    if toDump.empty:
                        continue

                    if shtName == "GeneralParameter":
                        toReturn[porttype].update({"index": sorted(toDump['Index'].str.lower().unique())})

                    toDump.to_excel(writer, sheet_name=f"{porttype.title()}{shtName}", index=False)
        
        del settingToDump

        return toReturn

    @staticmethod
    def reFormatFrontendDict(input_dict: dict) -> dict:
        
        result = {}
        for key, value in input_dict.items():

            formatted_key = Util.BT_FIELDS.get(key.lower())
            if formatted_key is None:
                continue

            if isinstance(value, dict):
                result[formatted_key] = Util.reFormatFrontendDict(value)
            elif isinstance(value, list):
                result[formatted_key] = Util.reFormatFrontendList(value)
            elif value is not None:
                result[formatted_key] = value

        return result

    @staticmethod
    def reFormatFrontendList(input_list: list) -> list:

        result = []
        for item in input_list:

            if isinstance(item, dict):
                result.append(Util.reFormatFrontendDict(item))
            elif isinstance(item, list):
                result.append(Util.reFormatFrontendList(item))
        
        return result

    @staticmethod
    def reFormatFrontendJson(jsonToFormat: dict) -> dict:
        
        result = {}
        for key, value in jsonToFormat.items():

            formatted_key = Util.BT_FIELDS.get(key.lower())
            if formatted_key is None:
                continue

            if isinstance(value, dict):
                result[formatted_key] = Util.reFormatFrontendDict(value)
            elif isinstance(value, list):
                result[formatted_key] = Util.reFormatFrontendList(value)
            elif value is not None:
                result[formatted_key] = value

        return result
    
    @staticmethod
    def getFormattedId(userInputtedId: str) -> str:

        if pd.isnull(userInputtedId):
            return ""
        
        try:
            return str(int(userInputtedId))
        except Exception:
            return str(userInputtedId) 
    
    @staticmethod
    def convertFrontendJsonToBtRequiredJson(inputJson: dict, tvSignalInfoo: dict={}) -> dict:

        inputJson = Util.reFormatFrontendJson(jsonToFormat=inputJson)
        isTickBt = inputJson['isTickBt']
        checkfreq = 1 if isTickBt else 60
        isTvBasedPortfolio = len(tvSignalInfoo) != 0

        stgysJson = []
        for stgySetting in inputJson['StrategiesSetting']:

            for __col in stgySetting: # formating frontend input

                if __col in ['StartTime', 'StrikeSelectionTime', 'EndTime', 'LastEntryTime']:
                    stgySetting[__col] = f"{stgySetting[__col]}00"
                
                if isTvBasedPortfolio and (__col in ['StrikeSelectionTime', 'StartTime', 'LastEntryTime', 'EndTime']):
                    stgySetting[__col] = tvSignalInfoo['entrytime'] if __col in ['StrikeSelectionTime', 'StartTime'] else tvSignalInfoo['exittime']
            
                if __col in Util.STGY_STR_PARA_COLUMN_NAME_LOWER:
                    stgySetting[__col] = stgySetting[__col].lower()
                
                if __col in Util.STGY_STR_PARA_COLUMN_NAME_UPPER:
                    stgySetting[__col] = stgySetting[__col].upper()
                    
            stgySetting.update({
                "evaluator": Util.USER_BT_TYPE_ENGINE_MAPPING[stgySetting['StrategyType']], 
                "ExpiryDayExitTime": tvSignalInfoo['ExpiryDayExitTime'] if isTvBasedPortfolio else stgySetting['EndTime'], "isTickBt": isTickBt
            })

            parsedLegInfo, validLegIds = [], []

            for __legPara in stgySetting['LegsSettings']:

                for __col in __legPara:
                    if __col in Util.LEG_STR_PARA_COLUMN_NAME:
                        __legPara[__col] = str(__legPara[__col]).upper()
                    elif __col in Util.LEG_IDS_COLUMN_NAME:
                        __legPara[__col] = Util.getFormattedId(userInputtedId=__col)
                    
                    if __col == "LegID":
                        validLegIds.append(__legPara[__col])
                    elif isTvBasedPortfolio and (__col == "Lots"):
                        __legPara[__col] = tvSignalInfoo['lots']
            
            for __legPara in stgySetting['LegsSettings']:

                legparaaa = Util.getBackendLegJson(isTickBt=isTickBt, frontendLegParameters=__legPara.copy(), frontendStgyParameters=stgySetting.copy(), isRolloverTrade=False, validLegIds=validLegIds)
                if len(legparaaa) == 0:
                    continue

                parsedLegInfo.append(legparaaa)
            
            if len(parsedLegInfo) == 0:
                continue

            stgyJsonToAdd = Util.getBackendStrategyJson(isTickBt=isTickBt, frontendStgyParameters=stgySetting.copy(), parsedLegInfo=parsedLegInfo)
            if not stgyJsonToAdd:
                continue

            if isTvBasedPortfolio:
                stgyJsonToAdd.update({"entry_date": tvSignalInfoo['entrydate'], "exit_date": tvSignalInfoo['exitdate']})

            stgysJson.append(stgyJsonToAdd)
        
        if len(stgysJson) == 0:
            return {}
        
        indicesForStgyJson = set([__settingDict['index'].split(".")[-1] for __settingDict in stgysJson])
        
        isMcxSymbol = any([ss in Util.MCX_SYMBOLS for ss in indicesForStgyJson])
        isNonMcxSymbol = any([ss in Util.NON_MCX_SYMBOLS for ss in indicesForStgyJson])
        isUsSymbol = any([ss in Util.US_SYMBOLS for ss in indicesForStgyJson])
        
        if sum([isMcxSymbol, isNonMcxSymbol, isUsSymbol]) > 1:
            logging.info("Please run either US or MCX or NSE&BSE indices.")
            return {}
        
        if isUsSymbol:
            exchange = "EXCHANGE.US"
        elif isMcxSymbol:
            exchange = "EXCHANGE.MCX"
        else:
            exchange = "EXCHANGE.NSE"
        
        toReturn = {
            "istickbt": isTickBt,
            "slippage_percent": 0.0,
            "start_date": tvSignalInfoo['entrydate'] if isTvBasedPortfolio else inputJson['StartDate'],
            "end_date": tvSignalInfoo['exitdate'] if isTvBasedPortfolio else inputJson['EndDate'],
            "broker_details": {"broker": "BROKER.PAPER"},
            "exchange": exchange,
            "order_type": "ORDERTYPE.MARKET",
            "product_type": "PRODUCTTYPE.NRML",
            "fix_vix": config.FIXED_VALUE_FOR_DYNAMIC_FACTOR.get("vix", 0), 
            "check_interval": checkfreq, 
            "feed_source": "FEEDSOURCE.HISTORICAL",
            "portfolio": {
                "id": inputJson['PortfolioID'],
                "name": inputJson['PortfolioName'],
                "stop_loss": {
                    "type": "NUMBERTYPE.POINT", 
                    "value": float(inputJson["PortfolioStoploss"])*-1, 
                    "params": {
                        "check_frequency": checkfreq
                    }
                },
                "take_profit": {
                    "type": "NUMBERTYPE.POINT", 
                    "value": float(inputJson["PortfolioTarget"]), 
                    "params": {
                        "check_frequency": checkfreq
                    }
                },
                "trailing_stop_loss": {
                    "profit_move": {
                        "type": "NUMBERTYPE.POINT","value": 0
                    }, 
                    "stop_loss_move": {
                        "type": "NUMBERTYPE.POINT", "value": 0
                    }
                },
                "lock_and_trail": {
                    "Type": "LOCKTYPE.REGULAR", "lock": 0, "trail": 0
                },
                "strategies": stgysJson
            }
        }

        if inputJson['PortfolioTrailingType'].lower() == 'trail profits':
            toReturn['portfolio'].update({
                "trailing_stop_loss": {
                    "profit_move": {
                        "type": "NUMBERTYPE.POINT", "value": float(inputJson['IncreaseInProfit'])
                    },
                    "stop_loss_move": {
                        "type": "NUMBERTYPE.POINT", "value": float(inputJson['TrailMinProfitBy'])
                    }
                },
                "lock_and_trail": {
                    "Type": "LOCKTYPE.REGULAR", "lock": float(inputJson['IncreaseInProfit']), "trail": float(inputJson['TrailMinProfitBy'])
                }
            })

        elif inputJson['PortfolioTrailingType'].lower() == 'lock minimum profit':
            toReturn['portfolio'].update({
                "lock_and_trail": {
                    "Type": "LOCKTYPE.REGULAR", "lock": float(inputJson['ProfitReaches']), "trail": float(inputJson['LockMinProfitAt'])
                }
            })

        elif inputJson['PortfolioTrailingType'].lower() == 'lock & trail profits':
            toReturn['portfolio'].update({
                "trailing_stop_loss": {
                    "profit_move": {
                        "type": "NUMBERTYPE.POINT","value": float(inputJson['IncreaseInProfit'])
                    },
                    "stop_loss_move": {
                        "type": "NUMBERTYPE.POINT", "value": float(inputJson['TrailMinProfitBy'])
                    }
                },
                "lock_and_trail": {
                    "Type": "LOCKTYPE.REGULAR", "lock": float(inputJson['ProfitReaches']), "trail": float(inputJson['LockMinProfitAt'])
                }
            })
        
        elif inputJson['PortfolioTrailingType'].lower() == 'portfolio lock trail':
            toReturn['portfolio'].update({
                "lock_and_trail": {
                    "Type": "LOCKTYPE.MAX_TILL_TIME", "lock_time": Util.getSeconds(timesting=inputJson["PnLCalTime"]), 
                    "lock": float(inputJson['LockPercent']), "trail": float(inputJson['TrailPercent'])
                }
            })
        
        elif inputJson['PortfolioTrailingType'].lower() == 'max possible profit':
            toReturn['portfolio'].update({
                "lock_and_trail": {
                    "Type": "LOCKTYPE.MAX_POSSIBLE_PROFIT", "lock_time": Util.getSeconds(timesting=inputJson["PnLCalTime"]), 
                    "lock": 0, "next_check_time": Util.getSeconds(timesting=inputJson["SqOff1Time"]), "trail": float(inputJson['SqOff1Percent']),
                    "final_trail_time": Util.getSeconds(timesting=inputJson["SqOff2Time"]), "final_trail": float(inputJson['SqOff2Percent'])
                }
            })
        
        return toReturn

    @staticmethod
    def populateSymbolInfoForMargin() -> dict:

        if not os.path.exists(Util.MARGIN_SYMBOL_INFO_FILE_PATH):
            fetchLatest = True
        else:
            fetchLatest = (datetime.strptime(time.ctime(os.path.getmtime(Util.MARGIN_SYMBOL_INFO_FILE_PATH)), "%a %b %d %H:%M:%S %Y").date() != datetime.now().date())
        
        if fetchLatest:

            for ii in range(1,6):

                try:
                    
                    r1 = requests.get("https://margin-calc-arom-prod.angelbroking.com/exchange/BFO/product/OPTION/contract")
                    r1 = pd.DataFrame(r1.json()['contract'])
                    r1 = r1[r1['symbol'].str.contains("SENSEX-|BANKEX-")]
                    r1['exchange'] = "BFO"

                    r2 = requests.get("https://margin-calc-arom-prod.angelbroking.com/exchange/NFO/product/OPTION/contract")
                    r2 = pd.DataFrame(r2.json()['contract'])
                    r2 = r2[r2['symbol'].str.contains("NIFTY-")]
                    r2['exchange'] = "NFO"

                    r3 = requests.get("https://margin-calc-arom-prod.angelbroking.com/exchange/MCX/product/OPTION/contract")
                    r3 = pd.DataFrame(r3.json()['contract'])
                    r3['exchange'] = "MCX"

                    r0 = pd.concat([r1, r2, r3])
                    r0 = r0.reset_index(drop=True)

                    r0['underlyingname'] = r0['symbol'].apply(lambda x: x.split("-")[0])
                    r0['expiry'] = r0['symbol'].apply(lambda x: x.split("-")[-1])
                    r0 = r0[['symbol', 'instrumentType', 'underlyingname', 'expiry', 'exchange']]
                    r0['expiry'] = pd.to_datetime(r0['expiry'], format="%d%b%y")

                    toReturn = {}
                    for underlyingName in r0['underlyingname'].unique():
                        underlyingSymbol = r0[r0['underlyingname'] == underlyingName]
                        underlyingSymbol = underlyingSymbol.sort_values(by=['expiry'])
                        toReturn[underlyingName] = {ii: {"contract": underlyingSymbol['symbol'].iloc[ii], "exchange": underlyingSymbol['exchange'].iloc[ii]} for ii in range(underlyingSymbol.shape[0])}
                    
                    with open(Util.MARGIN_SYMBOL_INFO_FILE_PATH, "+w") as f:
                        f.write(json.dumps(toReturn, indent=4))

                    Util.MARGIN_INFO = toReturn
                    return
                
                except Exception:
                    logging.error(traceback.format_exc())
                    time.sleep(ii)
                    
        else:

            with open(Util.MARGIN_SYMBOL_INFO_FILE_PATH, "+r") as f:
                dtaa = json.loads(f.read())
            
            Util.MARGIN_INFO = {indice: {int(jj): dtaa[indice][jj] for jj in dtaa[indice]} for indice in dtaa}
            return 
        
    @staticmethod
    def getTVSignalsInDf(signalfilepath: str, signals: list) -> pd.DataFrame:
        
        if (signalfilepath == "") and (not signals):
            return pd.DataFrame()
        
        if signalfilepath != "":
        
            if not os.path.exists(signalfilepath):
                logging.info(f"Unable to find TV signal file, given location: {signalfilepath}")
                return pd.DataFrame()
            
            signalDf = pd.read_excel(signalfilepath, sheet_name="List of trades")
            signalDf = signalDf[['Trade #', 'Type', 'Date/Time', 'Contracts']]
            signalDf.columns = ["tradeno", "signal", "datetime", "lots"]
        
        else:

            signalDf = pd.DataFrame(signals)
            signalDf = signalDf.drop(columns=['signal'])
            signalDf = signalDf.rename(columns={"trade": "tradeno", "contracts": "lots", "type": "signal"})
        
        return signalDf[["tradeno", "signal", "datetime", "lots"]].dropna(how="any").reset_index(drop=True)
    
    @staticmethod
    def getTVIntraSignals(rolloverIndex: str, uPara: dict, signalDf: pd.DataFrame) -> dict:

        if signalDf.empty:
            logging.error("No signal found.")
            return []
        
        if uPara['DoRollover']:
            
            rolloverInfo = Util.getDateInfoForRollver(indexTraded=rolloverIndex)
            if not rolloverInfo:
                logging.error("Unable to get expiry dates required for rollover. Hence, cann't run.")
                return []
            
            rolloverTime = str(int(uPara['RolloverTime']))
            
        else:
            rolloverInfo = {}
        
        signalDf['datetime'] = pd.to_datetime(signalDf['datetime'], format=uPara['SignalDateFormat'])
        
        entrySignalCount = signalDf[signalDf['signal'].str.contains("Entry ")]
        entrySignalCount['datetime'] = entrySignalCount['datetime'].dt.strftime("%y%m%d").astype(int)
        entrySignalCount = entrySignalCount[['datetime']]
        entrySignalCount = entrySignalCount['datetime'].value_counts().to_dict()
        
        signalDf = signalDf[
            (signalDf['datetime'].dt.date >= datetime.strptime(uPara['StartDate'], "%d_%m_%Y").date()) & 
            (signalDf['datetime'].dt.date <= datetime.strptime(uPara['EndDate'], "%d_%m_%Y").date())
        ]
        signalDf = signalDf.sort_values(by=['datetime'])
        signalDf = signalDf.reset_index(drop=True)
        signalDf['signal'] = signalDf['signal'].str.upper().apply(lambda x: x.split(" ")[1]).str.strip()

        if uPara['ManualTradeEntryTime'] != 0:

            starttradenofrom = signalDf['tradeno'].max()

            manualsignalentrytime = datetime.strptime(str(int(uPara['ManualTradeEntryTime'])), "%H%M%S").time()
            manualsignallasttime = datetime.strptime(str(int(uPara['IntradayExitTime'])), "%H%M%S").time()

            uniquedts = sorted(signalDf['datetime'].dt.date.unique())
            manipulatedsignalafterconsideringmanualsignal = []

            for udate in uniquedts:

                ckdf = signalDf[signalDf['datetime'].dt.date == udate]
                datewisesignals = ckdf.to_dict("records")

                if manualsignalentrytime < ckdf.iloc[0]['datetime'].time(): # creating manual signal incase signal is after manual signal entry time

                    starttradenofrom += 1
                    datewisesignals.insert(0, {
                        "tradeno": starttradenofrom, 
                        "signal": "MANUAL", 
                        "datetime": datetime(udate.year, udate.month, udate.day, manualsignalentrytime.hour, manualsignalentrytime.minute, manualsignalentrytime.second), 
                        "lots": uPara['ManualTradeLots']
                    })
                    datewisesignals.insert(1, {
                        "tradeno": starttradenofrom, 
                        "signal": "MANUAL", 
                        "datetime": datetime(udate.year, udate.month, udate.day, ckdf.iloc[0]['datetime'].hour, ckdf.iloc[0]['datetime'].minute, ckdf.iloc[0]['datetime'].second), 
                        "lots": uPara['ManualTradeLots']
                    })
                
                if manualsignallasttime > ckdf.iloc[-1]['datetime'].time(): # creating manual signal incase signal is exited before exit time

                    starttradenofrom += 1
                    datewisesignals.insert(len(datewisesignals), {
                        "tradeno": starttradenofrom, 
                        "signal": "MANUAL", 
                        "datetime": datetime(udate.year, udate.month, udate.day, ckdf.iloc[-1]['datetime'].hour, ckdf.iloc[-1]['datetime'].minute, ckdf.iloc[-1]['datetime'].second), 
                        "lots": uPara['ManualTradeLots']
                    })
                    datewisesignals.insert(len(datewisesignals), {
                        "tradeno": starttradenofrom, 
                        "signal": "MANUAL", 
                        "datetime": datetime(udate.year, udate.month, udate.day, manualsignallasttime.hour, manualsignallasttime.minute, manualsignallasttime.second), 
                        "lots": uPara['ManualTradeLots']
                    })
                
                manipulatedsignalafterconsideringmanualsignal += datewisesignals

            signalDf = pd.DataFrame(manipulatedsignalafterconsideringmanualsignal)
            del manipulatedsignalafterconsideringmanualsignal
            
        finalSignal = {"LONG": [], "SHORT": [], "MANUAL": []}

        for tradeno in signalDf['tradeno'].unique():
            signals = signalDf[signalDf['tradeno'] == tradeno]
            if (signals.shape[0] % 2 != 0):
                continue

            entrydate = int(signals['datetime'].iloc[0].date().strftime('%y%m%d'))
            entrytime = signals['datetime'].iloc[0].time().strftime("%H%M%S")

            if (entrydate in entrySignalCount) and (uPara['FirstTradeEntryTime'] != 0):
                entrytime = str(int(uPara['FirstTradeEntryTime']))
                entrySignalCount.pop(entrydate)
            
            exitdate = int(signals['datetime'].iloc[1].date().strftime('%y%m%d'))
            exittime = signals['datetime'].iloc[1].time().strftime("%H%M%S")

            if uPara['IncreaseEntrySignalTimeBy'] != 0:
                entrytime = (datetime.strptime(entrytime, "%H%M%S") + relativedelta(seconds=uPara['IncreaseEntrySignalTimeBy'])).strftime("%H%M%S")
            
            if uPara['IncreaseExitSignalTimeBy'] != 0:
                exittime = (datetime.strptime(exittime, "%H%M%S") + relativedelta(seconds=uPara['IncreaseExitSignalTimeBy'])).strftime("%H%M%S")

            addEntry = True

            if uPara['DoRollover']:

                currentexpiry = rolloverInfo['expirys'].get(entrydate)
                if currentexpiry is None:
                    continue

                currentexpiry = currentexpiry[0]
            
                if exitdate > currentexpiry: # exit date is after current expiry

                    addEntry = False
                    logging.info(f"Rollover required for tradeno: {tradeno}")

                    finalSignal[signals['signal'].iloc[0]].append({
                        "entrydate": entrydate, "entrytime": entrytime, "exitdate": currentexpiry, "exittime": rolloverTime, 
                        "lots": int(signals['lots'].iloc[0]), "ExpiryDayExitTime": rolloverTime, "isrollovertrade": False
                    })

                    loopTime = math.ceil((signals['datetime'].iloc[1].date() - signals['datetime'].iloc[0].date()).days / 5)
                    for __ in range(loopTime):

                        nexttradingdate = rolloverInfo['tradingdates'][rolloverInfo['tradingdates'].index(currentexpiry)+1]
                        nextexitdate = rolloverInfo['expirys'][nexttradingdate][0]

                        if nextexitdate >= exitdate:

                            finalSignal[signals['signal'].iloc[0]].append({
                                "entrydate": currentexpiry, "entrytime": rolloverTime, "exitdate": exitdate, "exittime": exittime, 
                                "lots": int(signals['lots'].iloc[0]), "ExpiryDayExitTime": exittime, "isrollovertrade": True
                            })
                            break

                        finalSignal[signals['signal'].iloc[0]].append({
                            "entrydate": currentexpiry, "entrytime": rolloverTime, "exitdate": nextexitdate, "exittime": rolloverTime, 
                            "lots": int(signals['lots'].iloc[0]), "ExpiryDayExitTime": rolloverTime, "isrollovertrade": True
                        })
                        currentexpiry = rolloverInfo['expirys'].get(nextexitdate)[0]

            if (not uPara['TvExitApplicable']) and uPara['IntradaySqOffApplicable']:

                if (exitdate != entrydate) or (int(exittime) > int(uPara['IntradayExitTime'])):
                    exittime = str(int(uPara['IntradayExitTime']))
                    exitdate = entrydate

            if not addEntry:
                continue

            finalSignal[signals['signal'].iloc[0]].append({
                "entrydate": entrydate, "entrytime": entrytime, "exitdate": exitdate, "exittime": exittime, "lots": int(signals['lots'].iloc[0]), 
                "ExpiryDayExitTime": str(int(uPara['ExpiryDayExitTime'])), "isrollovertrade": False
            })

        return finalSignal
    
    @staticmethod
    def getPortfolioJson(excelFilePath: str, tvSignalInfoo: dict={}, strategyNamePrefix: str="") -> tuple:

        toReturnPortJson, toReturnStgyParaDf = {}, {}
        isTvBasedPortfolio = len(tvSignalInfoo) != 0

        if not os.path.exists(excelFilePath):
            logging.error(f"Unable to find input file, location: {excelFilePath}")
            return toReturnPortJson, toReturnStgyParaDf
        
        portfolioShtDf = pd.read_excel(excelFilePath, sheet_name="PortfolioSetting")
        portfolioShtDf = portfolioShtDf[portfolioShtDf['Multiplier'] > 0]
        portfolioShtDf = portfolioShtDf.reset_index(drop=True)
        
        for colName in ["Enabled", "PortfolioName"]:
            portfolioShtDf[colName] = portfolioShtDf[colName].str.upper()
        
        portfolioShtDf = portfolioShtDf[portfolioShtDf['Enabled'] == "YES"]
        if portfolioShtDf.empty:
            return toReturnPortJson, toReturnStgyParaDf

        strategyShtDf = pd.read_excel(excelFilePath, sheet_name="StrategySetting")
        for colName in ["Enabled", "PortfolioName"]:
            strategyShtDf[colName] = strategyShtDf[colName].str.upper()
        
        strategyShtDf['fileExists'] = strategyShtDf['StrategyExcelFilePath'].apply(os.path.exists)
        strategyShtDf = strategyShtDf[(strategyShtDf['Enabled'] == "YES") & strategyShtDf['fileExists']]
        strategyShtDf = strategyShtDf.drop(columns=['fileExists', 'Enabled'])
        strategyShtDf['StrategyType'] = strategyShtDf['StrategyType'].str.upper()
        strategyShtDf['StrategyType'] = np.where(strategyShtDf['StrategyType'] == "IBS", "VWAP", strategyShtDf['StrategyType'])
        
        if strategyShtDf.empty:
            return toReturnPortJson, toReturnStgyParaDf
        
        for pIndex, pInfo in portfolioShtDf.iterrows():
            
            isTickBt = pInfo['IsTickBT'].lower() == "yes"
            checkfreq = 1 if isTickBt else 60

            pStrategyDf = strategyShtDf[strategyShtDf['PortfolioName'] == pInfo['PortfolioName']]
            if pStrategyDf.empty:
                continue

            if isTvBasedPortfolio:
                startDate, endDate = 0, 0
            else:
                startDate = int(datetime.strptime(pInfo["StartDate"], "%d_%m_%Y").strftime('%y%m%d'))
                endDate = int(datetime.strptime(pInfo["EndDate"], "%d_%m_%Y").strftime('%y%m%d'))

            strategiesLst = []
            for __, sInfo in pStrategyDf.iterrows():

                if sInfo['StrategyType'].upper() not in Util.VALID_BT_TYPE_FOR_USER:
                    logging.info(f"Invalid StrategyType received i.e. {sInfo['StrategyType']}. Valid options are: {Util.VALID_BT_TYPE_FOR_USER}")
                    continue

                strategyJsonn = Util.getStategyJson(
                    isTickBt=isTickBt, btType=sInfo['StrategyType'], excelFilePath=sInfo['StrategyExcelFilePath'], strategyNamePrefix=strategyNamePrefix, 
                    tvSignalInfoo=tvSignalInfoo, portfolioMultiplier=pInfo['Multiplier']
                )
                if len(strategyJsonn) == 0:
                    continue

                if isTvBasedPortfolio:
                    startDate = tvSignalInfoo['entrydate'] if startDate == 0 else min(startDate, tvSignalInfoo['entrydate'])
                    endDate = tvSignalInfoo['exitdate'] if endDate == 0 else max(endDate, tvSignalInfoo['exitdate'])

                strategiesLst += strategyJsonn

                if isTvBasedPortfolio: # for TV based signals
                    continue

                if pIndex not in toReturnStgyParaDf:
                    toReturnStgyParaDf[pIndex] = {
                        "PortfolioParameter": pd.DataFrame.from_dict(dict(pInfo), orient="index").reset_index().rename(columns={"index": "Head", 0: "Value"}), 
                        "GeneralParameter": pd.DataFrame(), "LegParameter": pd.DataFrame()
                    }

                for keyy in ["GeneralParameter", "LegParameter"]:
                    toReturnStgyParaDf[pIndex][keyy] = pd.concat([toReturnStgyParaDf[pIndex][keyy], pd.read_excel(sInfo['StrategyExcelFilePath'], sheet_name=keyy)])
                    toReturnStgyParaDf[pIndex][keyy] = toReturnStgyParaDf[pIndex][keyy].reset_index(drop=True)
            
            if len(strategiesLst) == 0:
                continue

            indicesForStgyJson = set([__settingDict['index'].split(".")[-1] for __settingDict in strategiesLst])

            isMcxSymbol = any([ss in Util.MCX_SYMBOLS for ss in indicesForStgyJson])
            isNonMcxSymbol = any([ss in Util.NON_MCX_SYMBOLS for ss in indicesForStgyJson])
            isUsSymbol = any([ss in Util.US_SYMBOLS for ss in indicesForStgyJson])
            
            if sum([isMcxSymbol, isNonMcxSymbol, isUsSymbol]) > 1:
                logging.info("Please run either US or MCX or NSE&BSE indices.")
                continue

            if isUsSymbol:
                exchange = "EXCHANGE.US"
            elif isMcxSymbol:
                exchange = "EXCHANGE.MCX"
            else:
                exchange = "EXCHANGE.NSE"
            
            toReturnPortJson[pIndex] = {
                "istickbt": isTickBt,
                "slippage_percent": pInfo['SlippagePercent']/100,
                "start_date": startDate,
                "end_date": endDate,
                "broker_details": {"broker": "BROKER.PAPER"}, 
                "exchange": exchange,
                "order_type": "ORDERTYPE.MARKET", 
                "product_type": "PRODUCTTYPE.NRML",
                "fix_vix": config.FIXED_VALUE_FOR_DYNAMIC_FACTOR.get("vix", 0), 
                "check_interval": checkfreq, 
                "feed_source": "FEEDSOURCE.HISTORICAL",
                "portfolio": {
                    "id": pIndex,
                    "name": pInfo['PortfolioName'],
                    "stop_loss": {
                        "type": "NUMBERTYPE.POINT", 
                        "value": float(pInfo["PortfolioStoploss"])*-1, 
                        "params": {
                            "check_frequency": checkfreq
                        }
                    },
                    "take_profit": {
                        "type": "NUMBERTYPE.POINT", 
                        "value": float(pInfo["PortfolioTarget"]), 
                        "params": {
                            "check_frequency": checkfreq
                        }
                    },
                    "trailing_stop_loss": {
                        "profit_move": {
                            "type": "NUMBERTYPE.POINT","value": 0
                        }, 
                        "stop_loss_move": {
                            "type": "NUMBERTYPE.POINT", "value": 0
                        }
                    },
                    "lock_and_trail": {
                        "Type": "LOCKTYPE.REGULAR", "lock": 0, "trail": 0
                    },
                    "strategies": strategiesLst
                }
            }

            if pInfo['PortfolioTrailingType'].lower() == 'trail profits':
                toReturnPortJson[pIndex]['portfolio'].update({
                    "trailing_stop_loss": {
                        "profit_move": {
                            "type": "NUMBERTYPE.POINT","value": pInfo['IncreaseInProfit']
                        },
                        "stop_loss_move": {
                            "type": "NUMBERTYPE.POINT", "value": pInfo['TrailMinProfitBy']
                        }
                    },
                    "lock_and_trail": {
                        "Type": "LOCKTYPE.REGULAR", "lock": pInfo['IncreaseInProfit'], "trail": pInfo['TrailMinProfitBy']
                    }
                })

            elif pInfo['PortfolioTrailingType'].lower() == 'lock minimum profit':
                toReturnPortJson[pIndex]['portfolio'].update({
                    "lock_and_trail": {
                        "Type": "LOCKTYPE.REGULAR", "lock": pInfo['ProfitReaches'], "trail": pInfo['LockMinProfitAt']
                    }
                })

            elif pInfo['PortfolioTrailingType'].lower() == 'lock & trail profits':
                toReturnPortJson[pIndex]['portfolio'].update({
                    "trailing_stop_loss": {
                        "profit_move": {
                            "type": "NUMBERTYPE.POINT","value": pInfo['IncreaseInProfit']
                        },
                        "stop_loss_move": {
                            "type": "NUMBERTYPE.POINT", "value": pInfo['TrailMinProfitBy']
                        }
                    },
                    "lock_and_trail": {
                        "Type": "LOCKTYPE.REGULAR", "lock": pInfo['ProfitReaches'], "trail": pInfo['LockMinProfitAt']
                    }
                })
            
            elif pInfo['PortfolioTrailingType'].lower() == 'portfolio lock trail':
                toReturnPortJson[pIndex]['portfolio'].update({
                    "lock_and_trail": {
                        "Type": "LOCKTYPE.MAX_TILL_TIME", "lock_time": Util.getSeconds(timesting=pInfo["PnLCalTime"]), 
                        "lock": float(pInfo['LockPercent']), "trail": float(pInfo['TrailPercent'])
                    }
                })
            
            elif pInfo['PortfolioTrailingType'].lower() == 'max possible profit':
                toReturnPortJson[pIndex]['portfolio'].update({
                    "lock_and_trail": {
                        "Type": "LOCKTYPE.MAX_POSSIBLE_PROFIT", "lock_time": Util.getSeconds(timesting=pInfo["PnLCalTime"]), 
                        "lock": 0, "next_check_time": Util.getSeconds(timesting=pInfo["SqOff1Time"]), "trail": float(pInfo['SqOff1Percent']),
                        "final_trail_time": Util.getSeconds(timesting=pInfo["SqOff2Time"]), "final_trail": float(pInfo['SqOff2Percent'])
                    }
                })
            
        return toReturnPortJson, toReturnStgyParaDf
    
    @staticmethod
    def getSeconds(timesting: str):
        """This function is used to convert human readable time to system required time"""

        todayy = datetime.now()
        timee = datetime.strptime(str(int(timesting)), "%H%M%S")

        secondss = datetime(todayy.year, todayy.month, todayy.day, timee.hour, timee.minute, timee.second) - datetime(todayy.year, todayy.month, todayy.day)
        return int(secondss.total_seconds())
    
    @staticmethod
    def getStrikeValueAndMethod(strikeValue: float, strikeMethod: str, premiumCondition: str, matchPremium: str) -> tuple:
        
        strikeMethodd, strikeValuee = "", float(strikeValue)

        if strikeMethod == "PREMIUM VARIABLE2":
            strikeValuee = f"{premiumCondition}_{strikeValuee}"

        if strikeMethod == "ATM":
            strikeMethodd = "BY_ATM_STRIKE"

        if strikeMethod in ["ATM WIDTH", "STRADDLE WIDTH"]:
            strikeMethodd = "BY_ATM_STRADDLE"
        
        elif strikeMethod == "PREMIUM VARIABLE2":
            strikeMethodd = "BY_DYNAMIC_FACTOR"

        elif strikeMethod in ["PREMIUM", "DELTA"]:

            if premiumCondition == "=":
                strikeMethodd = f"BY_CLOSEST_{strikeMethod}"
            elif premiumCondition == ">":
                strikeMethodd = f"BY_GE_{strikeMethod}"
            elif premiumCondition == "<":
                strikeMethodd = f"BY_LE_{strikeMethod}"
        
        elif strikeMethod == "ATM MATCH":
            strikeMethodd = "BY_MATCH_PREMIUM"
            if matchPremium == "HIGH":
                strikeValuee = f"{premiumCondition}_1"
            elif matchPremium == "LOW":
                strikeValuee = f"{premiumCondition}_-1"
        
        elif strikeMethod == "ATM DIFF":
            strikeMethodd = "BY_MIN_STRIKE_DIFF"

        return (strikeMethodd, strikeValuee)

    @staticmethod
    def getLegJson(isTickBt: bool, legExcelDf: pd.DataFrame, stgyParameters: dict, isRolloverTrade: bool) -> list:

        if legExcelDf.empty:
            return []
        
        legsInfo = []

        validLegIds = list(legExcelDf['LegID'].unique())
        validLegIds = [ii for ii in validLegIds if not pd.isnull(ii)]

        for __, __info in legExcelDf.iterrows():

            __info = dict(__info)

            if any(pd.isnull(ii) for ii in __info.values()):
                logging.info(f"Empty field for {__info['StrategyName']} {__info['LegID']} {__info['Instrument']} found. Hence, cann't backtest")
                return []
            
            legparaa = Util.getBackendLegJson(
                isTickBt=isTickBt, frontendLegParameters=__info.copy(), frontendStgyParameters=stgyParameters.copy(), isRolloverTrade=isRolloverTrade, 
                validLegIds=validLegIds
            )
            if len(legparaa) == 0:
                continue

            legsInfo.append(legparaa)
        
        return legsInfo
    
    @staticmethod
    def getExecuteParameters(legParaDict: dict, fieldName: str, validLegIds: list) -> list:

        if fieldName == "OnExit":
            if legParaDict.get("OnExit_OpenAllLegs", "NO") == "YES":
                return [{"id": legid, "delay": float(legParaDict[f'{fieldName}_OpenTradeDelay']), "new_spawn": "True"} for legid in validLegIds]
        
        if f"{fieldName}_OpenTradeOn" not in legParaDict:
            return []
        
        __legids = legParaDict[f"{fieldName}_OpenTradeOn"].split(",")
        __legids = [ii.strip() for ii in __legids]

        return [{"id": ii, "delay": float(legParaDict[f'{fieldName}_OpenTradeDelay'])} for ii in __legids if ii in validLegIds]
    
    @staticmethod
    def getSquareParameters(legParaDict: dict, fieldName: str, validLegIds: list) -> list:

        if f"{fieldName}_SqOffTradeOff" not in legParaDict:
            return []
        
        __legids = legParaDict[f"{fieldName}_SqOffTradeOff"].split(",")
        __legids = [ii.strip() for ii in __legids]

        return [{"id": ii, "delay": float(legParaDict[f'{fieldName}_SqOffDelay'])} for ii in __legids if ii in validLegIds]
    
    @staticmethod
    def getBackendLegJson(isTickBt: bool, frontendLegParameters: dict, frontendStgyParameters: dict, isRolloverTrade: bool, validLegIds: list) -> dict:

        if "StrikeMethod" not in frontendLegParameters:
            logging.info("Strike selection method is missing.")
            return {}

        if (frontendLegParameters['StrikeMethod'].upper() == "DELTA"):
            
            if (frontendStgyParameters['Index'] in Util.MCX_SYMBOLS):
                logging.info("Strike selection based on DELTA is not applicable for MCX.")
                return {}
            
            if (frontendStgyParameters['Index'] in Util.US_SYMBOLS):
                logging.info("Strike selection based on DELTA is not applicable for US.")
                return {}
        
        if ('Transaction' not in frontendLegParameters): # adding transaction type based on trader type

            if (frontendStgyParameters['StrategyType'] == "VWAP") and ('Tradertype' in frontendStgyParameters):
                frontendLegParameters['Transaction'] = "SELL" if frontendStgyParameters['Tradertype'] == "SELLER" else "BUY"
            elif ("HEIKIN" in frontendStgyParameters['StrategyType']) or ("EMA" in frontendStgyParameters['StrategyType']):
                frontendLegParameters['Transaction'] = "SELL"

        if (frontendLegParameters.get('SL_TrailAt', 0) != 0) or (frontendLegParameters.get('SL_TrailBy', 0) != 0):

            if ("DELTA" in frontendLegParameters['SLType']):
                logging.info("Stoploss cann't be trail when stoploss type is DELTA.")
                return {}

            if (("INDEX" not in frontendLegParameters['SLType']) and ("INDEX" in frontendLegParameters['TrailSLType'])) or (("INDEX" in frontendLegParameters['SLType']) and ("INDEX" not in frontendLegParameters['TrailSLType'])):
                logging.info("Stoploss type and trail stoploss type cann't be different. Hence, will not backtest.")
                return {}

        if "W&TValue" in frontendLegParameters:
            waitTradeValue = abs(float(frontendLegParameters['W&TValue'])) if frontendLegParameters['Transaction'] == "BUY" else float(frontendLegParameters['W&TValue']) * -1
        else:
            waitTradeValue = 0

        slreentryMethod = Util.RE_ENTRY_ALIAS.get(frontendLegParameters["SL_ReEntryType"], "") if "SL_ReEntryType" in frontendLegParameters else "IMMIDIATE_NC"
        tgtreentryMethod = Util.RE_ENTRY_ALIAS.get(frontendLegParameters["TGT_ReEntryType"], "") if "TGT_ReEntryType" in frontendLegParameters else "IMMIDIATE_NC"
        slType = Util.TGT_SL_ALIAS.get(frontendLegParameters['SLType'], "") if "SLType" in frontendLegParameters else "POINT"
        tgtType = Util.TGT_SL_ALIAS.get(frontendLegParameters['TGTType'], "") if "TGTType" in frontendLegParameters else "POINT"
        isidleVariantReEntryMethod = Util.RE_ENTRY_ALIAS.get(frontendLegParameters["ReEntryType"], "") if "ReEntryType" in frontendLegParameters else "IMMIDIATE_NC"

        strikeMethodd, strikeValuee = Util.getStrikeValueAndMethod(strikeValue=frontendLegParameters['StrikeValue'], strikeMethod=frontendLegParameters['StrikeMethod'], premiumCondition=frontendLegParameters['StrikePremiumCondition'], matchPremium=frontendLegParameters['MatchPremium'])
        hedgestrikeMethodd, hedgestrikeValuee = Util.getStrikeValueAndMethod(strikeValue=frontendLegParameters['HedgeStrikeValue'], strikeMethod=frontendLegParameters['HedgeStrikeMethod'], premiumCondition=frontendLegParameters['HedgeStrikePremiumCondition'], matchPremium=frontendLegParameters['MatchPremium'])

        if strikeMethodd == "":
            logging.info("Invalid leg strike selection method received.")
            return {}
        
        if hedgestrikeMethodd == "":
            logging.info("Invalid hedge leg strike selection method received.")
            return {}
        
        if tgtreentryMethod == "":
            logging.info("Invalid target re-entry method received.")
            return {}
        
        if slreentryMethod == "":
            logging.info("Invalid stoploss re-entry method received.")
            return {}
        
        if isidleVariantReEntryMethod == "":
            logging.info("Invalid is_idle re-entry method received.")
            return {}
        
        if slType == "":
            logging.info("Invalid stoploss method received.")
            return {}
        
        if tgtType == "":
            logging.info("Invalid target method received.")
            return {}
        
        checkfreq = 1 if isTickBt else 60
        
        triggered_renetry_count = float(frontendLegParameters.get('ReEnteriesCount', 0))
        if triggered_renetry_count != 0:
            triggered_renetry_count += 1

        legParaa = {
            "id": frontendLegParameters['LegID'],
            "option_type": f"OPTIONTYPE.{frontendLegParameters['Instrument']}",
            "side": f"SIDE.{frontendLegParameters['Transaction']}",
            "expiry_type": f"EXPIRYTYPE.{Util.EXPIRY_ALIAS['NEXT']}" if isRolloverTrade else f"EXPIRYTYPE.{Util.EXPIRY_ALIAS.get(frontendLegParameters['Expiry'])}",
            "waitin": {
                "type": f"NUMBERTYPE.{frontendLegParameters.get('W&Type', 'POINT')}", 
                "value": waitTradeValue,
                "should_trail": "False" if frontendLegParameters.get("TrailW&T", 'NO') == "NO" else "True"
            },
            "strike_selection": {
                "type": f"STRIKESELECTIONTYPE.{strikeMethodd}", 
                "value": strikeValuee
            },
            "stop_loss_reentry": {
                "type": f"REENTRYTYPE.{slreentryMethod}", 
                "value": {
                    "count": float(frontendLegParameters.get('SL_ReEntryNo', 0)), 
                    "cutoff_time": Util.getSeconds(timesting=frontendStgyParameters["LastEntryTime"]),
                    "check_frequency": int(frontendStgyParameters["ReEntryCheckingInterval"]*checkfreq),
                    "cool_off_time": checkfreq
                }
            },
            "take_profit_reentry": {
                "type": f"REENTRYTYPE.{tgtreentryMethod}", 
                "value": {
                    "count": float(frontendLegParameters.get('TGT_ReEntryNo', 0)), 
                    "cutoff_time": Util.getSeconds(timesting=frontendStgyParameters["LastEntryTime"]),
                    "check_frequency": int(frontendStgyParameters["ReEntryCheckingInterval"]*checkfreq),
                    "cool_off_time": checkfreq
                }
            },
            "triggered_reentry": {
                "type": f"REENTRYTYPE.{isidleVariantReEntryMethod}",
                "value": {
                    "count": triggered_renetry_count,
                    "cutoff_time": Util.getSeconds(timesting=frontendStgyParameters["LastEntryTime"]),
                    "check_frequency": checkfreq,
                    "cool_off_time": checkfreq
                }
            },
            "is_idle": "True" if frontendLegParameters.get("IsIdle", "NO") == "YES" else "False",
            "on_entry": {
                "squareoffall": [{"delay": 0}],
                "execute": Util.getExecuteParameters(legParaDict=frontendLegParameters, fieldName="OnEntry", validLegIds=validLegIds), 
                "squareoff": Util.getSquareParameters(legParaDict=frontendLegParameters, fieldName="OnEntry", validLegIds=validLegIds)
            },
            "on_exit": {
                "squareoffall": [{"delay": 0}],
                "execute": Util.getExecuteParameters(legParaDict=frontendLegParameters, fieldName="OnExit", validLegIds=validLegIds), 
                "squareoff": Util.getSquareParameters(legParaDict=frontendLegParameters, fieldName="OnExit", validLegIds=validLegIds)
            },
            "stop_loss": {
                "type": f"NUMBERTYPE.{slType}", 
                "value": float(frontendLegParameters.get('SLValue', 0)),
                "params": {
                    "check_frequency": int(frontendStgyParameters["StoplossCheckingInterval"]*checkfreq)
                } 
            },
            "take_profit": {
                "type": f"NUMBERTYPE.{tgtType}", 
                "value": float(frontendLegParameters.get('TGTValue', 0)),
                "params": {
                    "check_frequency": int(frontendStgyParameters["TargetCheckingInterval"]*checkfreq)
                }
            },
            "trailing_stop_loss": {
                "profit_move": {
                    "type": f"NUMBERTYPE.{Util.TGT_SL_ALIAS.get(frontendLegParameters.get('TrailSLType', 'POINT'))}", 
                    "value": float(frontendLegParameters.get('SL_TrailAt', 0))
                },
                "stop_loss_move": {
                    "type": f"NUMBERTYPE.{Util.TGT_SL_ALIAS.get(frontendLegParameters.get('TrailSLType', 'POINT'))}", 
                    "value": float(frontendLegParameters.get('SL_TrailBy', 0))
                }
            },
            "quantity": config.LOT_SIZE.get(frontendStgyParameters['Index'], 0),
            "multiplier": int(frontendLegParameters['Lots']),
            "recost_cascade": "True", #"False" if waitTradeValue != 0 else "True",
            "recost_entry_on_crossover": "True" if config.TRAIL_COST_RE_ENTRY else "False",
            "hedge_pnl_effect": "True" if frontendStgyParameters['ConsiderHedgePnLForStgyPnL'] == "YES" else "False",
            "next_expiry_select": "True" if (frontendStgyParameters['OnExpiryDayTradeNextExpiry'] == "YES") and (frontendStgyParameters['Index'] not in Util.MCX_SYMBOLS) else "False"
        }

        if ('OnEntry_SqOffAllLegs' in frontendLegParameters) and (frontendLegParameters['OnEntry_SqOffAllLegs'] == "YES"):
            pass
        else:
            legParaa['on_entry'].pop("squareoffall")

        if ('OnExit_SqOffAllLegs' in frontendLegParameters) and (frontendLegParameters['OnExit_SqOffAllLegs'] == "YES"):
            pass
        else:
            legParaa['on_exit'].pop("squareoffall")
        
        if (frontendLegParameters['Transaction'] == "SELL") and (frontendLegParameters['OpenHedge'] == "YES"):
            legParaa.update({
                "hedge": {
                    "option_type": f"OPTIONTYPE.{frontendLegParameters['Instrument']}",
                    "side": "SIDE.BUY",
                    "expiry_type": f"EXPIRYTYPE.{Util.EXPIRY_ALIAS.get(frontendLegParameters['Expiry'])}",
                    "strike_selection": {
                        "type": f"STRIKESELECTIONTYPE.{hedgestrikeMethodd}", 
                        "value": hedgestrikeValuee
                    },
                    "next_expiry_select": "True" if (frontendStgyParameters['OnExpiryDayTradeNextExpiry'] == "YES") and (frontendStgyParameters['Index'] not in Util.MCX_SYMBOLS) else "False"
                }
            })
        
        if frontendStgyParameters['StrategyType'] == "ORB":
            legParaa.update({
                "orb": {
                    "wait_start": Util.getSeconds(timesting=frontendStgyParameters["OrbRangeStart"]),  
                    "wait_till": Util.getSeconds(timesting=frontendStgyParameters["OrbRangeEnd"]), 
                    "entry_on": "ORBBREAKOUTTYPE.LOWBREAKOUT" if frontendLegParameters['Transaction'] == "SELL" else "ORBBREAKOUTTYPE.HIGHBREAKOUT"
                }
            })

            if 'TradeStrikeValue' in frontendLegParameters:
                legParaa['orb'].update({
                    "new_selection": int(frontendLegParameters['TradeStrikeValue'])
                })
        
        if frontendStgyParameters['StrategyType'] == "OI":
            legParaa.update({
                "oi_check": {
                    "check_interval": checkfreq * int(frontendStgyParameters['Timeframe']),
                    "value": frontendLegParameters['OiThreshold'], "recontracterized": "True"
                }
            })
        
        return legParaa

    @staticmethod
    def getBackendStrategyJson(isTickBt: bool, frontendStgyParameters: dict, parsedLegInfo: list) -> dict:

        if frontendStgyParameters['StrategyType'] == "ORB":
            
            isNewOrb = any(['new_selection' in __legsetting['orb'] for __legsetting in parsedLegInfo])

            frontendStgyParameters['StartTime'] = frontendStgyParameters['OrbRangeEnd'] if isNewOrb else frontendStgyParameters['OrbRangeStart']
            frontendStgyParameters['StrikeSelectionTime'] = frontendStgyParameters['OrbRangeEnd'] if isNewOrb else frontendStgyParameters['OrbRangeStart']
        
        elif frontendStgyParameters['StrategyType'] == "OI":

            if frontendStgyParameters['Timeframe'] % 3 != 0:
                logging.info("Can't run OI strategy as timeframe should be multiple of 3")
                return {}
        
        if frontendStgyParameters['Index'] in Util.US_SYMBOLS:
            underlyingToConsider = "UNDERLYINGTYPE.CASH"
        elif isTickBt or (frontendStgyParameters['Index'] in Util.MCX_SYMBOLS):
            underlyingToConsider = "UNDERLYINGTYPE.FUTURE"
        else:
            underlyingToConsider = f"UNDERLYINGTYPE.{Util.UNDERLYING_ALIAS.get(frontendStgyParameters['Underlying'])}"
        
        if frontendStgyParameters['Index'] in Util.MCX_SYMBOLS:
            # Remove hardcoded DTE = 10, allow user-specified DTE for MCX
            # frontendStgyParameters['DTE'] = 10  # Commented out
            secondLastExitTime = 232959 if isTickBt else 232900
            exitTime = 233000
        elif frontendStgyParameters['Index'] in Util.US_SYMBOLS:
            frontendStgyParameters['DTE'] = 10
            secondLastExitTime = 155959 if isTickBt else 155900
            exitTime = 160000
        else:
            secondLastExitTime = 152959 if isTickBt else 152900
            exitTime = 153000
        
        validweekdays = [ii.strip() for ii in str(frontendStgyParameters['Weekdays']).split(",")]
        validweekdays = [int(ii) for ii in validweekdays if len(ii) != 0]
        checkfreq = 1 if isTickBt else 60

        # All indices use NSEINDEX class regardless of exchange
        index_format = f"NSEINDEX.{frontendStgyParameters['Index']}"
        
        stgyParaa = {
            "index_base_price": config.FIXED_VALUE_FOR_DYNAMIC_FACTOR.get(frontendStgyParameters['Index'].lower(), 0),
            "name": frontendStgyParameters['StrategyName'], 
            "evaluator": frontendStgyParameters['evaluator'], "type": "STRATEGYTYPE.INTRADAY", "index": index_format,
            "underlying": underlyingToConsider, "indicator_candle_based_on": "option",
            "place_order_after": Util.getSeconds(timesting=frontendStgyParameters["StartTime"]), 
            "entry_time": Util.getSeconds(timesting=frontendStgyParameters["StrikeSelectionTime"]),
            "exit_time": Util.getSeconds(timesting=frontendStgyParameters["EndTime"]) if int(frontendStgyParameters["EndTime"]) < exitTime else Util.getSeconds(timesting=secondLastExitTime),
            "tv_expiry_day_exit_time": Util.getSeconds(timesting=frontendStgyParameters["ExpiryDayExitTime"]),
            "pnl_calculation_from": frontendStgyParameters["PnLCalculationFrom"],
            "multiplier": 1,
            "stop_loss": {
                "type": "NUMBERTYPE.POINT", 
                "value": float(frontendStgyParameters['StrategyLoss'])*-1,
                "params": {
                    "check_frequency": checkfreq
                } 
            },
            "take_profit": {
                "type": "NUMBERTYPE.POINT", 
                "value": float(frontendStgyParameters['StrategyProfit']),
                "params": {
                    "check_frequency": checkfreq
                }
            },
            "exit_price": {
                "take_profit_based_on": frontendStgyParameters['TgtTrackingFrom'], 
                "trade_file_exit_price_on_take_profit": frontendStgyParameters['TgtRegisterPriceFrom'],
                "stop_loss_based_on": frontendStgyParameters['SlTrackingFrom'], 
                "trade_file_exit_price_on_stop_loss": frontendStgyParameters['SlRegisterPriceFrom'],
                "trade_file_exit_price_on_trigger": "TICK"
            },
            "stop_loss_reentry": {
                "type": "REENTRYTYPE.IMMIDIATE", 
                "value": {
                    "count": int(frontendStgyParameters['StrategyLossReExecuteNo']), 
                    "cutoff_time": Util.getSeconds(timesting=exitTime),
                    "check_frequency": checkfreq,
                    "cool_off_time": checkfreq
                }
            },
            "take_profit_reentry": {
                "type": "REENTRYTYPE.IMMIDIATE",
                "value": {
                    "count": int(frontendStgyParameters['StrategyProfitReExecuteNo']), 
                    "cutoff_time": Util.getSeconds(timesting=exitTime),
                    "check_frequency": checkfreq,
                    "cool_off_time": checkfreq
                }
            },
            "trailing_stop_loss": {
                "profit_move": {
                    "type": "NUMBERTYPE.POINT","value": 0
                },
                "stop_loss_move": {
                    "type": "NUMBERTYPE.POINT", "value": 0
                }
            },
            "lock_and_trail": {
                "lock": 0, "trail": 0
            },
            "move_sl_to_cost": "False" if frontendStgyParameters.get("MoveSlToCost", "NO") == "NO" else "True"
        }

        if len(validweekdays) < 5:
            stgyParaa.update({
                "acceptable_weekdays": validweekdays
            })
        
        # Always pass DTE to backend - no restriction on DTE value
        stgyParaa.update({
            "dte": int(frontendStgyParameters['DTE'])
        })
        
        if frontendStgyParameters['StrategyTrailingType'] == 'trail profits':
            stgyParaa.update({
                "trailing_stop_loss": {
                    "profit_move": {
                        "type": "NUMBERTYPE.POINT","value": float(frontendStgyParameters['IncreaseInProfit'])
                    },
                    "stop_loss_move": {
                        "type": "NUMBERTYPE.POINT", "value": float(frontendStgyParameters['TrailMinProfitBy'])
                    }
                },
                "lock_and_trail": {
                    "lock": float(frontendStgyParameters['IncreaseInProfit']), "trail": float(frontendStgyParameters['TrailMinProfitBy'])
                }
            })

        elif frontendStgyParameters['StrategyTrailingType'] == 'lock minimum profit':
            stgyParaa.update({
                "lock_and_trail": {
                    "lock": float(frontendStgyParameters['ProfitReaches']), "trail": float(frontendStgyParameters['LockMinProfitAt'])
                }
            })

        elif frontendStgyParameters['StrategyTrailingType'] == 'lock & trail profits':
            stgyParaa.update({
                "trailing_stop_loss": {
                    "profit_move": {
                        "type": "NUMBERTYPE.POINT","value": float(frontendStgyParameters['IncreaseInProfit'])
                    },
                    "stop_loss_move": {
                        "type": "NUMBERTYPE.POINT", "value": float(frontendStgyParameters['TrailMinProfitBy'])
                    }
                },
                "lock_and_trail": {
                    "lock": float(frontendStgyParameters['ProfitReaches']), "trail": float(frontendStgyParameters['LockMinProfitAt'])
                }
            })
        
        if frontendStgyParameters['StrategyType'] in ["VWAP", "HEIKIN_RSI_EMA", "HEIKIN_RSI_ST", "5_EMA"]:

            if frontendStgyParameters['StrategyType'] in ["HEIKIN_RSI_EMA", "HEIKIN_RSI_ST", "5_EMA"]:
                stgyParaa['entry_time'] += (checkfreq * int(frontendStgyParameters['Timeframe']))
            
            if frontendStgyParameters['StrategyType'] in ["HEIKIN_RSI_EMA", "HEIKIN_RSI_ST"]:
                frontendStgyParameters.update({"ChangeStrikeForIndicatorBasedReEntry": "NO"})

            entryIndicators, exitIndicators = {}, {}
            noOfEntryIndicators, noofExitIndicators = 0, 0

            if frontendStgyParameters['StrategyType'] == "HEIKIN_RSI_EMA":
                entryIndicators.update({
                    "in1": {
                        "name": "ema", "condition": "ema > close", "length": int(frontendStgyParameters.get('EMAPeriod'))
                    },
                    "op1": "and",
                    "in2": {
                        "name": "rsi", "condition": frontendStgyParameters['RsiEntryCondition'], "length": int(frontendStgyParameters.get('RsiPeriod'))
                    }
                })

                exitIndicators.update({
                    "in1": {
                        "name": "ema", "condition": "ema < close", "length": int(frontendStgyParameters.get('EMAPeriod'))
                    }
                })

            elif frontendStgyParameters['StrategyType'] == "HEIKIN_RSI_ST":
                entryIndicators.update({
                    "in1": {
                        "name": "rsi", "condition": frontendStgyParameters['RsiEntryCondition'], "length": int(frontendStgyParameters.get('RsiPeriod'))
                    },
                    "op1": "and",
                    "in2": {
                        "name": "st", "condition": "st > close", "length": int(frontendStgyParameters['ST1_Period']), 
                        "multiplier": float(frontendStgyParameters['ST1_Multiplier'])
                    },
                    "op2": "and",
                    "in3": {
                        "name": "st", "condition": "st > close", "length": int(frontendStgyParameters['ST2_Period']), 
                        "multiplier": float(frontendStgyParameters['ST2_Multiplier'])
                    }
                })

                exitIndicators.update({
                    "in1": {
                        "name": "st", "condition": "st < close", "length": int(frontendStgyParameters['ST1_Period']), 
                        "multiplier": float(frontendStgyParameters['ST1_Multiplier'])
                    },
                    "op1": "or",
                    "in2": {
                        "name": "st", "condition": "st < close", "length": int(frontendStgyParameters['ST2_Period']), 
                        "multiplier": float(frontendStgyParameters['ST2_Multiplier'])
                    }
                })
            
            elif frontendStgyParameters['StrategyType'] == "5_EMA":

                entryIndicators.update({
                    "in1": {
                        "name": "ema", "condition": "ema < low", "length": int(frontendStgyParameters.get('EMAPeriod'))
                    }
                })
            
            if frontendStgyParameters.get('ConsiderVwapForEntry', "NO") == "YES":

                noOfEntryIndicators += 1

                entryIndicators.update({
                    f"in{noOfEntryIndicators}": {
                        "name": "vwap", "condition": frontendStgyParameters['VwapEntryCondition']
                    },
                    f"op{noOfEntryIndicators}": frontendStgyParameters['EntryCombination']
                })
            
            if frontendStgyParameters.get('ConsiderVwapForExit', "NO") == "YES":
                
                noofExitIndicators += 1

                exitIndicators.update({
                    f"in{noofExitIndicators}": {
                        "name": "vwap", "condition": frontendStgyParameters['VwapExitCondition']
                    },
                    f"op{noofExitIndicators}": frontendStgyParameters['ExitCombination']
                })
            
            if frontendStgyParameters.get('ConsiderEMAForEntry', "NO") == "YES":
                
                noOfEntryIndicators += 1

                entryIndicators.update({
                    f"in{noOfEntryIndicators}": {
                        "name": "ema", "condition": frontendStgyParameters['EmaEntryCondition'], "length": int(frontendStgyParameters.get('EMAPeriod'))
                    },
                    f"op{noOfEntryIndicators}": frontendStgyParameters['EntryCombination']
                })
            
            if frontendStgyParameters.get('ConsiderEMAForExit', "NO") == "YES":
                
                noofExitIndicators += 1

                exitIndicators.update({
                    f"in{noofExitIndicators}": {
                        "name": "ema", "condition": frontendStgyParameters['EmaExitCondition'], "length": int(frontendStgyParameters.get('EMAPeriod'))
                    },
                    f"op{noofExitIndicators}": frontendStgyParameters['ExitCombination']
                })
            
            if frontendStgyParameters.get('ConsiderSTForEntry', "NO") == "YES":

                noOfEntryIndicators += 1

                entryIndicators.update({
                    f"in{noOfEntryIndicators}": {
                        "name": "st", "condition": frontendStgyParameters['StEntryCondition'], "length": int(frontendStgyParameters['STPeriod']), 
                        "multiplier": float(frontendStgyParameters['STMultiplier'])
                    },
                    f"op{noOfEntryIndicators}": frontendStgyParameters['EntryCombination']
                })
            
            if frontendStgyParameters.get('ConsiderSTForExit', "NO") == "YES":
                
                noofExitIndicators += 1

                exitIndicators.update({
                    f"in{noofExitIndicators}": {
                        "name": "st", "condition": frontendStgyParameters['StExitCondition'], "length": int(frontendStgyParameters['STPeriod']), 
                        "multiplier": float(frontendStgyParameters['STMultiplier'])
                    },
                    f"op{noofExitIndicators}": frontendStgyParameters['ExitCombination']
                })
            
            if frontendStgyParameters.get('ConsiderRSIForEntry', "NO") == "YES":
                
                noOfEntryIndicators += 1

                entryIndicators.update({
                    f"in{noOfEntryIndicators}": {
                        "name": "rsi", "condition": frontendStgyParameters['RsiEntryCondition'], "length": int(frontendStgyParameters.get('RsiPeriod'))
                    },
                    f"op{noOfEntryIndicators}": frontendStgyParameters['EntryCombination']
                })
            
            if frontendStgyParameters.get('ConsiderRSIForExit', "NO") == "YES":
                
                noofExitIndicators += 1

                exitIndicators.update({
                    f"in{noofExitIndicators}": {
                        "name": "rsi", "condition": frontendStgyParameters['RsiExitCondition'], "length": int(frontendStgyParameters.get('RsiPeriod'))
                    },
                    f"op{noofExitIndicators}": frontendStgyParameters['ExitCombination']
                })
                            
            if frontendStgyParameters.get('ConsiderVolSmaForEntry', "NO") == "YES":

                noOfEntryIndicators += 1

                entryIndicators.update({
                    f"in{noOfEntryIndicators}": {
                        "name": "vol_sma", "condition": frontendStgyParameters['VolSmaEntryCondition'], "length": int(frontendStgyParameters['VolSMAPeriod'])
                    },
                    f"op{noOfEntryIndicators}": frontendStgyParameters['EntryCombination']
                })
            
            if frontendStgyParameters.get('ConsiderVolSmaForExit', "NO") == "YES":
                
                noofExitIndicators += 1

                exitIndicators.update({
                    f"in{noofExitIndicators}": {
                        "name": "vol_sma", "condition": frontendStgyParameters['VolSmaExitCondition'], "length": int(frontendStgyParameters['VolSMAPeriod'])
                    },
                    f"op{noofExitIndicators}": frontendStgyParameters['ExitCombination']
                })
                            
            stgyParaa.update({
                "checking_interval": checkfreq * int(frontendStgyParameters['Timeframe']),
                "entry_indicators": entryIndicators, 
                "exit_indicators": exitIndicators,
                "indicator_based_reentry": {
                    "type": "REENTRYTYPE.IMMIDIATE", 
                    "value": {
                        "count": int(frontendStgyParameters['IndicatorBasedReEntry']), 
                        "cutoff_time": Util.getSeconds(timesting=exitTime), 
                        "check_frequency": checkfreq, 
                        "cool_off_time": checkfreq
                    }
                }
            })

            if frontendStgyParameters['StrategyType'] == "5_EMA":
                rr = frontendStgyParameters['RiskReward'].strip().split(":")
                stgyParaa.update({
                    "rr": f"({float(rr[0])}, {float(rr[1])})", 
                    "entry_buffer": frontendStgyParameters['EntryBuffer'], 
                    "stoploss_buffer": frontendStgyParameters['StoplossBuffer'],
                })
        
        if frontendStgyParameters['StrategyType'] in ["VWAP", "HEIKIN_RSI_EMA", "HEIKIN_RSI_ST", "5_EMA"]:

            [
                leginfo.update({
                    "refresh_contract_on_reentry": "True" if frontendStgyParameters['ChangeStrikeForIndicatorBasedReEntry'] == "YES" else "False"
                }) for leginfo in parsedLegInfo
            ]
        
        if frontendStgyParameters['StrategyType'] == "OI":
            stgyParaa.update({
                'concurrent_legs': frontendStgyParameters['MaxOpenPositions']
            })
            
        stgyParaa.update({"legs": parsedLegInfo})
        
        return stgyParaa
                
    @staticmethod
    def getStategyJson(isTickBt: bool, btType: str, excelFilePath: str, strategyNamePrefix: str, tvSignalInfoo: dict, portfolioMultiplier: float) -> list:
        """This function is used to generate json file required for running strategy"""

        isTvBasedPortfolio = len(tvSignalInfoo) != 0

        stgysParaForBt = []

        userStgyParameters = pd.read_excel(excelFilePath, sheet_name="GeneralParameter")
        userLegParameters = pd.read_excel(excelFilePath, sheet_name="LegParameter")
        if isTvBasedPortfolio:
            userLegParameters['Lots'] = tvSignalInfoo['lots']

        for fieldName in Util.FIELDS_TO_MULTIPLY_BY_PORTFOLIO_MULTIPLIER["GeneralParameter"]:
            userStgyParameters[fieldName] *= portfolioMultiplier
        
        for fieldName in Util.FIELDS_TO_MULTIPLY_BY_PORTFOLIO_MULTIPLIER["LegParameter"]:
            userLegParameters[fieldName] *= portfolioMultiplier
            if fieldName not in ["Lots"]:
                continue

            userLegParameters[fieldName] = userLegParameters[fieldName].astype(int)

        userStgyParameters = userStgyParameters[~pd.isnull(userStgyParameters['StrategyName'])]

        for __col in userStgyParameters: # formating frontend input

            if __col in Util.STGY_STR_PARA_COLUMN_NAME_LOWER:
                userStgyParameters[__col] = userStgyParameters[__col].str.lower()
            
            if __col in Util.STGY_STR_PARA_COLUMN_NAME_UPPER:
                userStgyParameters[__col] = userStgyParameters[__col].str.upper()
        
        if isTvBasedPortfolio:

            timeCols = ['StrikeSelectionTime', 'StartTime', 'LastEntryTime', 'EndTime']
            for tcol in timeCols:
                if tcol not in userStgyParameters.columns:
                    continue
                userStgyParameters[tcol] = tvSignalInfoo['entrytime'] if tcol in ['StrikeSelectionTime', 'StartTime'] else tvSignalInfoo['exittime']

        userLegParameters = userLegParameters[~pd.isnull(userLegParameters['Instrument'])]
        for colNames in Util.LEG_STR_PARA_COLUMN_NAME:
            if colNames not in userLegParameters.columns:
                continue
            userLegParameters[colNames] = userLegParameters[colNames].astype(str).str.upper()
        
        for colName in Util.LEG_IDS_COLUMN_NAME:
            if colName not in userLegParameters.columns:
                continue
            userLegParameters[colName] = userLegParameters[colName].apply(Util.getFormattedId)
        
        for __, stgyParameters in userStgyParameters.iterrows():

            stgyParameters = dict(stgyParameters)

            if any(pd.isnull(ii) for ii in stgyParameters.values()):
                logging.info(f"Empty fields found for {stgyParameters['StrategyName']} strategy. Hence, will not backtest.")
                continue

            legParameters = userLegParameters[userLegParameters['StrategyName'] == stgyParameters['StrategyName']]
            if legParameters.empty:
                logging.info(f"Unable to get leg parameters for {stgyParameters['StrategyName']} strategy. Hence, will not backtest.")
                continue

            if legParameters.shape[0] != legParameters.drop_duplicates(subset=['LegID']).shape[0]:
                logging.info(f"LegID should be unique for all legs in {stgyParameters['StrategyName']} strategy. Hence, will not backtest.")
                continue

            if stgyParameters['ReEntryCheckingInterval'] < 1:
                logging.info("ReEntryCheckingInterval cann't be less than 1. Hence, will not backtest.")
                continue

            if stgyParameters['StoplossCheckingInterval'] < 1:
                logging.info("StoplossCheckingInterval cann't be less than 1. Hence, will not backtest.")
                continue

            if stgyParameters['TargetCheckingInterval'] < 1:
                logging.info("TargetCheckingInterval cann't be less than 1. Hence, will not backtest.")
                continue
                
            stgyParameters.update({
                "StrategyName": stgyParameters['StrategyName'] if len(strategyNamePrefix) == 0 else f"{strategyNamePrefix}_{stgyParameters['StrategyName']}", 
                "evaluator": Util.USER_BT_TYPE_ENGINE_MAPPING[btType.upper()], "StrategyType": btType.upper(), 
                "ExpiryDayExitTime": tvSignalInfoo['ExpiryDayExitTime'] if isTvBasedPortfolio else stgyParameters['EndTime'], "isTickBt": isTickBt
            })

            legsInfo = Util.getLegJson(isTickBt=isTickBt, legExcelDf=legParameters, stgyParameters=stgyParameters, isRolloverTrade=tvSignalInfoo.get('isrollovertrade', False))
            if len(legsInfo) == 0:
                continue

            stgyParaa = Util.getBackendStrategyJson(isTickBt=isTickBt, frontendStgyParameters=stgyParameters.copy(), parsedLegInfo=legsInfo)
            if not stgyParaa:
                continue
            
            if isTvBasedPortfolio:
                stgyParaa.update({"entry_date": tvSignalInfoo['entrydate'], "exit_date": tvSignalInfoo['exitdate']})
            
            stgysParaForBt.append(stgyParaa)

        return stgysParaForBt

    @staticmethod
    def getBacktestStats(tradesDf: pd.DataFrame, initialCapital: float):
        """This function is used to prepare backtesting stats"""
        
        number_of_trading_days_in_a_year = 252
        risk_free_interest_rate = 5

        intraday_trade_log = tradesDf[["entryDate", "bookedPnL"]].rename(columns={"entryDate": "Date", "bookedPnL": "PNL"})
        intraday_trade_log['Day'] = intraday_trade_log['Date'].apply(lambda x: x.strftime("%A"))
        intraday_trade_log['Month'] = intraday_trade_log['Date'].apply(lambda x: x.strftime("%b"))
        intraday_trade_log = intraday_trade_log[["Date", "Day", "Month", "PNL"]]

        monthly_df = intraday_trade_log.groupby(by=["Month"], as_index=False).sum(numeric_only=True)
        monthly_df.rename(columns={"bookedPnL":"PNL"}, inplace=True)
        
        # Convert PNL data to tensor
        pnl_tensor = Util.to_tensor(intraday_trade_log['PNL'].values)
        
        # Initialize tensors for equity and rate of return calculations
        equity_tensor = torch.zeros_like(pnl_tensor)
        rate_of_return_tensor = torch.zeros_like(pnl_tensor)
        
        # Calculate equity and rate of return using tensor operations
        equity_tensor[0] = initialCapital + pnl_tensor[0]
        rate_of_return_tensor[0] = (pnl_tensor[0]/initialCapital) * 100
        
        for i in range(1, len(pnl_tensor)):
            equity_tensor[i] = equity_tensor[i-1] + pnl_tensor[i]
            rate_of_return_tensor[i] = (pnl_tensor[i]/equity_tensor[i-1]) * 100
            
        # Convert results back to DataFrame columns
        intraday_trade_log['Equity'] = Util.from_tensor(equity_tensor)
        intraday_trade_log['Rate_of_Return'] = Util.from_tensor(rate_of_return_tensor)
        intraday_trade_log['Continuous_Wins'] = 0.0
        intraday_trade_log['Continuous_Losses'] = 0.0

        # Calculate win rate using tensor operations
        positive_pnl_mask = pnl_tensor > 0
        win_rate = torch.sum(positive_pnl_mask).item() / len(pnl_tensor)

        # Calculate mean win/loss using tensor operations
        mean_win = torch.mean(pnl_tensor[positive_pnl_mask]).item()
        mean_loss = torch.mean(pnl_tensor[~positive_pnl_mask]).item()
        risk_reward = abs(mean_win/mean_loss) if mean_loss != 0 else float('inf')
        expectancy = (win_rate*risk_reward) - ((1-win_rate)*1)
        
        # Calculate Sharpe and Sortino ratios using tensor operations
        mean = torch.mean(rate_of_return_tensor).item() * number_of_trading_days_in_a_year - risk_free_interest_rate
        sigma = torch.std(rate_of_return_tensor).item() * torch.sqrt(torch.tensor(number_of_trading_days_in_a_year)).item()
        sharpe_ratio = mean/sigma if sigma != 0 else 0
        
        negative_returns_mask = rate_of_return_tensor < 0
        downside_standard_deviation = torch.std(rate_of_return_tensor[negative_returns_mask]).item() * torch.sqrt(torch.tensor(number_of_trading_days_in_a_year)).item()
        sortino_ratio = mean/downside_standard_deviation if downside_standard_deviation != 0 else 0
        
        # Calculate drawdown using tensor operations
        cummax_pnl = torch.cummax(pnl_tensor, dim=0)[0]
        drawdown_tensor = pnl_tensor - cummax_pnl
        max_drawdown = torch.min(drawdown_tensor).item()
        
        max_drawdown_idx = torch.argmin(drawdown_tensor).item()
        max_drawdown_percent = max_drawdown/equity_tensor[max_drawdown_idx]*100

        # Calculate recovery days
        recovery_tensor = torch.zeros_like(drawdown_tensor)
        for i in range(1, len(drawdown_tensor)):
            if drawdown_tensor[i] < 0:
                recovery_tensor[i] = recovery_tensor[i-1] + 1
                
        intraday_trade_log['Recovery'] = Util.from_tensor(recovery_tensor)
        
        intraday_trade_log_equity_high = intraday_trade_log[intraday_trade_log['Recovery'] == 0]
        intraday_trade_log_equity_high['number_days_between_equity_highs'] = (intraday_trade_log_equity_high['Date'] - intraday_trade_log_equity_high['Date'].shift())
        recover = intraday_trade_log_equity_high['number_days_between_equity_highs'].apply(lambda x: x.days if not pd.isnull(x) else None).max()
        recovery_days = np.nan if pd.isnull(recover) else int(recover)
        
        # Calculate CAGR using tensor operations
        number_of_trading_days_for_this_backtest = (intraday_trade_log.iloc[-1]['Date'] - intraday_trade_log.iloc[0]['Date']).days
        if number_of_trading_days_for_this_backtest != 0:
            cagr = (((equity_tensor[-1]/initialCapital)**(1/(number_of_trading_days_for_this_backtest/365)))-1)*100
            cagr = cagr.item()
        else:
            cagr = 0
            
        calmar_ratio = 0 if max_drawdown_percent == 0 else abs(cagr/max_drawdown_percent)
        
        # Calculate trade statistics using tensor operations
        number_of_wins = torch.sum(positive_pnl_mask).item()
        number_of_losses = len(pnl_tensor) - number_of_wins
        average_profit_per_trade = torch.mean(pnl_tensor[positive_pnl_mask]).item()
        average_loss_per_trade = torch.mean(pnl_tensor[~positive_pnl_mask]).item()
        max_pnl = torch.max(pnl_tensor).item()
        min_pnl = torch.min(pnl_tensor).item()
        median_of_trade = torch.median(pnl_tensor).item()
        
        gross_profit = torch.sum(pnl_tensor[positive_pnl_mask]).item()
        gross_loss = torch.sum(pnl_tensor[~positive_pnl_mask]).item()
        
        if gross_loss != 0:
            profit_factor = abs(gross_profit/gross_loss)
            outlier_adjusted_profit_factor = abs((gross_profit-max_pnl)/gross_loss)
        else:
            profit_factor = 0.0
            outlier_adjusted_profit_factor = 0.0

        # Calculate continuous wins/losses
        for i in range(1, len(pnl_tensor)):
            if pnl_tensor[i-1] > 0:
                intraday_trade_log['Continuous_Wins'].iloc[i] = intraday_trade_log['Continuous_Wins'].iloc[i-1]+1
            if pnl_tensor[i-1] < 0:
                intraday_trade_log['Continuous_Losses'].iloc[i] = intraday_trade_log['Continuous_Losses'].iloc[i-1]+1

        consecutive_wins = intraday_trade_log['Continuous_Wins'].max()
        consecutive_losses = intraday_trade_log['Continuous_Losses'].max()

        metrics = {
            'Backtest Start Date': intraday_trade_log.iloc[0]['Date'], 
            'Backtest End Date': intraday_trade_log.iloc[-1]['Date'], 
            "Margin Required": initialCapital,
            'Number of Trading Days': intraday_trade_log.shape[0], 
            'Number of +ve days': number_of_wins, 
            'Number of -ve days': number_of_losses, 
            'Total PnL': round(float(Util.from_tensor(torch.sum(pnl_tensor))), 2),
            'Average Profit': round(float(average_profit_per_trade), 2),
            'Average Loss': round(average_loss_per_trade, 2),
            'Maximum Trade Profit': round(max_pnl, 2),
            'Maximum Trade Loss': round(min_pnl, 2),
            'Median Trade': round(median_of_trade, 2),
            'Consecutive Wins': consecutive_wins, 
            'Consecutive Losses': consecutive_losses, 
            'Win Rate': round(float(win_rate), 2),
            'Expectancy': round(float(expectancy), 2),
            'Sharpe Ratio': round(float(sharpe_ratio), 2),
            'Sortino Ratio': round(float(sortino_ratio), 2),
            'Calmar': round(float(calmar_ratio), 2),
            'CAGR': round(float(cagr), 2),
            'Max Drawdown': round(float(max_drawdown), 2),
            'Max Drawdown Percent': round(float(max_drawdown_percent), 2),
            'Days Taken to Recover From Drawdown': recovery_days, 
            'Profit Factor (Amount of Profit per unit of Loss)': round(profit_factor,2),
            'Outlier Adjusted Profit Factor': round(outlier_adjusted_profit_factor,2)
        }

        return metrics

    @staticmethod
    def getDayWiseStats(tradesDf: pd.DataFrame) -> pd.DataFrame:
        
        intraday_trade_log = tradesDf[["entryDate", "bookedPnL"]].copy()
        intraday_trade_log = intraday_trade_log.rename(columns={"entryDate": "Date", "bookedPnL": "PNL"})
        intraday_trade_log['year'] = intraday_trade_log['Date'].apply(lambda x: x.year)
        intraday_trade_log['day'] = intraday_trade_log['Date'].apply(lambda x: x.strftime("%A"))
        intraday_trade_log = intraday_trade_log.groupby(by=['year', 'day'], as_index=False).sum(numeric_only=True)

        years = sorted(intraday_trade_log['year'].unique())
        finalResult = []

        for yr in years:

            yrDf = intraday_trade_log[intraday_trade_log['year'] == yr]
            yrBifurcation = {"Year": yr}

            for dy in config.VALID_TRADING_WEEKDAYS:
                dyDf = yrDf[yrDf['day'] == dy]
                yrBifurcation[dy] = dyDf['PNL'].iloc[0] if not dyDf.empty else 0
            
            finalResult.append(yrBifurcation)

        finalResult = pd.DataFrame(finalResult)

        totalRecord = pd.DataFrame(finalResult.sum()).transpose()
        totalRecord['Year'] = 'Total'
        
        finalResult = pd.concat([finalResult, totalRecord])
        finalResult = finalResult.reset_index(drop=True)
        finalResult['Total'] = finalResult.drop(columns=['Year']).sum(axis=1)

        return finalResult

    @staticmethod
    def getMonthWiseStats(tradesDf: pd.DataFrame) -> pd.DataFrame:
        
        intraday_trade_log = tradesDf[["entryDate", "bookedPnL"]].copy()
        intraday_trade_log = intraday_trade_log.rename(columns={"entryDate": "Date", "bookedPnL": "PNL"})
        intraday_trade_log['year'] = intraday_trade_log['Date'].apply(lambda x: x.year)
        intraday_trade_log['month'] = intraday_trade_log['Date'].apply(lambda x: x.strftime("%B"))
        intraday_trade_log = intraday_trade_log.groupby(by=['year', 'month'], as_index=False).sum(numeric_only=True)

        years = sorted(intraday_trade_log['year'].unique())
        finalResult = []

        for yr in years:

            yrDf = intraday_trade_log[intraday_trade_log['year'] == yr]
            yrBifurcation = {"Year": yr}

            for mn in config.VALID_MONTHS:
                dyDf = yrDf[yrDf['month'] == mn]
                yrBifurcation[mn] = dyDf['PNL'].iloc[0] if not dyDf.empty else 0
            
            finalResult.append(yrBifurcation)

        finalResult = pd.DataFrame(finalResult)

        totalRecord = pd.DataFrame(finalResult.sum()).transpose()
        totalRecord['Year'] = 'Total'
        
        finalResult = pd.concat([finalResult, totalRecord])
        finalResult = finalResult.reset_index(drop=True)
        finalResult['Total'] = finalResult.drop(columns=['Year']).sum(axis=1)

        return finalResult

    @staticmethod
    def getBacktestResults(btPara: dict) -> dict:

        startTime = datetime.now()
        logging.info(f"{startTime}, Backtesting Portfolio: {btPara['portfolio']['id']}")

        urii = config.BT_URII['tick'] if btPara['istickbt'] else config.BT_URII['minute']
        
        try:
            btResp = requests.post(urii, json=btPara)
            respp = btResp.json()

            orderss = pd.DataFrame(respp['strategies']['orders'])
            orderss['portfolio_name'] = btPara['portfolio']['name']

            respp['strategies']['orders'] = orderss.to_dict("records")

        except Exception:
            logging.error(f"Error while running BT: {btResp.text}")
            respp = {}
        
        endTime = datetime.now()
        durationn = round((endTime-startTime).total_seconds(),2)
        logging.info(f"{endTime}, Completed backtesting portfolio: {btPara['portfolio']['id']}, Time taken: {durationn} \n")
        
        return respp
    
    @staticmethod
    def getMarginFor(position: list) -> float:

        for ii in range(1,3):

            try:

                r1 = requests.post(
                    url="https://margin-calc-arom-prod.angelbroking.com/margin-calculator/SPAN", headers=Util.MARGIN_REQ_HEADERS, json={"position": position}
                )
                if r1.status_code != 200:
                    logging.error(f"Unable to fetch margin, received following response: {r1.text}, {position}")
                    time.sleep(1)
                    continue

                resp = r1.json()['margin']
                return resp['netPremium'] if resp['totalMargin'] == 0 else resp['totalMargin']

            except Exception:
                logging.error(traceback.format_exc())
                time.sleep(ii)
        
        return 0
    
    @staticmethod
    def parseBacktestingResponse(btResponse: dict, slippagePercent: float) -> tuple:
        
        if len(btResponse['orders']) == 0:
            return pd.DataFrame(), {}, pd.DataFrame()
        
        orderdf = pd.DataFrame(btResponse['orders'])
        if orderdf.empty:
            return pd.DataFrame(), {}, pd.DataFrame()

        orderdf = orderdf.rename(columns={
            "entry_time": "entry_datetime", "exit_time": "exit_datetime", "option_type": "instrument_type", "qty": "filled_quantity", 
            "entry_number": "re_entry_no", "strategy_name": "strategy"
        })

        orderdf['entry_price_slippage'] = np.where(
            orderdf['side'] == "SELL", orderdf['entry_price'] * (1 - slippagePercent), orderdf['entry_price'] * (1 + slippagePercent)
        )

        orderdf['exit_price_slippage'] = np.where(
            orderdf['side'] == "SELL", orderdf['exit_price'] * (1 + slippagePercent), orderdf['exit_price'] * (1 - slippagePercent)
        )

        orderdf['pointsAfterSlippage'] = np.where(
            orderdf['side'] == "SELL", orderdf['entry_price_slippage'] - orderdf['exit_price_slippage'], orderdf['exit_price_slippage'] - orderdf['entry_price_slippage']
        )
        orderdf['pnlAfterSlippage'] = orderdf['pointsAfterSlippage'] * orderdf['filled_quantity']

        orderdf['points'] = np.where(
            orderdf['side'] == "SELL", orderdf['entry_price'] - orderdf['exit_price'], orderdf['exit_price'] - orderdf['entry_price']
        )
        
        if config.TAXES != 0:
            orderdf['expenses'] = orderdf['entry_price_slippage'] + orderdf['exit_price_slippage']
            orderdf['expenses'] *= orderdf['filled_quantity']
            orderdf['expenses'] *= config.TAXES
        else:
            orderdf['expenses'] = 0
        
        orderdf['netPnlAfterExpenses'] = orderdf['pnlAfterSlippage'] - orderdf['expenses']

        for columnName in ["entry", "exit"]:

            orderdf[f'{columnName}_datetime'] = pd.to_datetime(orderdf[f'{columnName}_datetime'], format="%a, %d %b %Y %H:%M:%S GMT")

            orderdf[f'{columnName}_date'] = orderdf[f'{columnName}_datetime'].dt.date
            orderdf[f'{columnName}_time'] = orderdf[f'{columnName}_datetime'].dt.time
            orderdf[f'{columnName}_day'] = orderdf[f'{columnName}_datetime'].dt.strftime("%A")
        
        orderdf['expiry'] = orderdf['expiry'].apply(lambda x: datetime.strptime(str(int(x)), "%y%m%d"))
        orderdf['expiry'] = orderdf['expiry'].dt.date
        orderdf['strike'] = orderdf['strike'].astype(float).astype(int)

        marginDf = orderdf[['strategy', 'leg_id', 'entry_datetime', 'filled_quantity', 'symbol', 'strike', 'instrument_type', 'side']]
        marginDf['entry_date'] = marginDf['entry_datetime'].dt.date
        marginDf = marginDf.sort_values(by=['entry_date'], ascending=False)
        marginDf = marginDf.drop_duplicates(subset=['strategy', 'leg_id'])

        stgyTransactionRecord = {}
        uniqueStgys = marginDf['strategy'].unique()

        for stgyName in uniqueStgys:
            stgyTransactionRecord[stgyName] = []
            stgyDf = marginDf[(marginDf['strategy'] == stgyName)]

            for info in stgyDf.itertuples():

                contractInfo = Util.MARGIN_INFO.get(info.symbol)
                if contractInfo is None:
                    continue

                contractInfo = contractInfo[0]

                stgyTransactionRecord[stgyName].append({
                    "contract": contractInfo['contract'], "exchange": contractInfo['exchange'], "product": "OPTION", "qty": info.filled_quantity, 
                    "strikePrice": info.strike, "tradeType": info.side.upper(), "optionType": info.instrument_type.upper()
                })
            
            if len(stgyTransactionRecord[stgyName]) == 0:
                del stgyTransactionRecord[stgyName]
        
        marginReqForEachStgy = {stgyName: Util.getMarginFor(position=stgyTransactionRecord[stgyName]) for stgyName in stgyTransactionRecord}
        tickpnldf = Util.convertTickPnlDictToDaywiseDf(toConvert=btResponse)

        return orderdf, marginReqForEachStgy, tickpnldf

    @staticmethod
    def convertTickPnlDictToDaywiseDf(toConvert: dict) -> pd.DataFrame:
        
        daymaxprofitloss = {}
        for __tradingdate in toConvert['strategy_profits']:
            
            daymaxprofitloss[__tradingdate] = {"max_profit": 0, "max_profit_time": 0, "max_loss": 0, "max_loss_time": 0}

            for __tradingtime in toConvert['strategy_profits'][__tradingdate]:

                if toConvert['strategy_profits'][__tradingdate][__tradingtime] <= 0:
                    continue

                if toConvert['strategy_profits'][__tradingdate][__tradingtime] > daymaxprofitloss[__tradingdate]['max_profit']:
                    daymaxprofitloss[__tradingdate].update({"max_profit": toConvert['strategy_profits'][__tradingdate][__tradingtime], "max_profit_time": __tradingtime})
                
            for __tradingtime in toConvert['strategy_losses'][__tradingdate]:

                if toConvert['strategy_losses'][__tradingdate][__tradingtime] >= 0:
                    continue

                if abs(toConvert['strategy_losses'][__tradingdate][__tradingtime]) > abs(daymaxprofitloss[__tradingdate]["max_loss"]):
                    daymaxprofitloss[__tradingdate].update({
                        "max_loss": toConvert['strategy_losses'][__tradingdate][__tradingtime],
                        "max_loss_time": __tradingtime
                    })

        daymaxprofitloss = pd.DataFrame.from_dict(daymaxprofitloss, orient="index").reset_index().rename(columns={
            "index": "Date", "max_profit": "Max Profit", "max_loss": "Max Loss", "max_profit_time": "Max Profit Time", "max_loss_time": "Max Loss Time"
        })
        if not daymaxprofitloss.empty:
            daymaxprofitloss['Date'] = daymaxprofitloss['Date'].apply(lambda x: datetime.strptime(str(int(x)), "%y%m%d").date())

            for tt in ['Max Profit Time', 'Max Loss Time']:
                daymaxprofitloss[tt] = daymaxprofitloss[tt].apply(lambda x: "" if x == 0 else (datetime(2021,1,1)+timedelta(seconds=int(x))).strftime("%H:%M:%S"))
        
        return daymaxprofitloss
    
    @staticmethod
    def getRecordsForOutputJson(responseDict: dict) -> list:

        toReturn = []
        
        for __key in responseDict:

            __df = responseDict[__key].copy()
            __df.columns = [__i.lower() for __i in __df.columns]

            if "year" in __df.columns:
                __df = __df[__df['year'] != "Total"]
                __df['strategy'] = __key
                toReturn += __df.to_dict("records")
        
        return toReturn
    
    @staticmethod
    def prepareOutputJson(btResultFile: str, btStatsTableData: pd.DataFrame, stgywiseTransactionDf: dict, stgyDayWiseStats: dict, stgyMonthWiseStats: dict, stgyMarginPercentageWiseStats: dict) -> None:

        __metricStats = btStatsTableData.copy()
        __metricStats['Particulars'] = __metricStats['Particulars'].apply(lambda x: Util.METRICS_KEY_NAME[x])
        __metricStats.columns = [__t.lower() for __t in __metricStats.columns]
        __metricStats = __metricStats.rename(columns={"particulars": "strategy"})
        __metricStats = __metricStats.set_index("strategy").transpose()
        for __dtCol in ["backteststartdate", "backtestenddate"]:
            __metricStats[__dtCol] = __metricStats[__dtCol].apply(lambda x : x.strftime("%y%m%d"))
        
        __metricStats = __metricStats.to_dict("index")

        __metrics = []
        for __stgy in __metricStats:
            __toappend = __metricStats[__stgy].copy()
            __toappend.update({"strategy": __stgy})
            __metrics.append(__toappend)
        
        transDf = stgywiseTransactionDf['portfolio'][Util.COLUMN_ORDER].copy()
        transDf["expiry"] = transDf["expiry"].apply(lambda x: x.strftime("%y%m%d"))

        for __tradeType in ["entry", "exit"]:
            transDf[f'{__tradeType}_date'] = transDf[f'{__tradeType}_date'].apply(lambda x: x.strftime("%y%m%d"))
            transDf[f'{__tradeType}_time'] = transDf[f'{__tradeType}_time'].apply(lambda x: x.strftime("%H%M%S"))

        outputJson = {
            "metrics": __metrics, "transactions": transDf.to_dict("records"), 
            "daywisestats": Util.getRecordsForOutputJson(responseDict=stgyDayWiseStats), 
            "monthwisestats": Util.getRecordsForOutputJson(responseDict=stgyMonthWiseStats), 
            "marginpercentwisestats": Util.getRecordsForOutputJson(responseDict=stgyMarginPercentageWiseStats)
        }

        with open(btResultFile, "+w") as ff:
            ff.write(simplejson.dumps(outputJson, ignore_nan=True, indent=4))

    @staticmethod
    def prepareOutputFile(btResultFile: str, btStatsTableData: pd.DataFrame, stgywiseTransactionDf: dict, stgyDayWiseStats: dict, stgyMonthWiseStats: dict, stgyMarginPercentageWiseStats: dict, onlyStgyResults: bool, excelFileExists: bool, dailyMaxProfitLossDf: pd.DataFrame) -> None:

        startTime = datetime.now()
        logging.info(f"{startTime}, Started writing stats to excel file.")

        if excelFileExists:
            excelObjj = pd.ExcelWriter(btResultFile, engine='openpyxl', mode="a", if_sheet_exists="overlay")
        else:
            excelObjj = pd.ExcelWriter(btResultFile, engine='openpyxl', mode="w")
        
        colOrder = Util.COLUMN_ORDER.copy()
        
        with excelObjj as writer: 

            btStatsTableData.to_excel(writer, sheet_name="Metrics", index=False)
            dailyMaxProfitLossDf.to_excel(writer, sheet_name="Max Profit and Loss", index=False)

            for stgyName in stgywiseTransactionDf:

                transactionDf = stgywiseTransactionDf[stgyName].copy()
                if transactionDf.empty:
                    continue

                transactionDf = transactionDf[colOrder].rename(columns=Util.COLUMN_RENAME_MAPPING)

                transactionDf.to_excel(writer, sheet_name=f"{stgyName.upper()} Trans", index=False)
                stgyDayWiseStats[stgyName].to_excel(writer, sheet_name=f"{stgyName.upper()} Results", index=False, startrow=0)
                stgyMonthWiseStats[stgyName].to_excel(writer, sheet_name=f"{stgyName.upper()} Results", index=False, startrow=stgyDayWiseStats[stgyName].shape[0]+ 3)
                stgyMarginPercentageWiseStats[stgyName].to_excel(writer, sheet_name=f"{stgyName.upper()} Results", index=False, startrow=stgyDayWiseStats[stgyName].shape[0]+stgyMonthWiseStats[stgyName].shape[0]+ 6)

                if not onlyStgyResults: # only portfolio stats required
                    break

        endTime = datetime.now()
        durationn = round((endTime-startTime).total_seconds(),2)
        
        logging.info(f"{endTime}, Excel file prepared, Time taken: {durationn} \n")